# ys_get_assets

- ysdb_internal.yml: the internal column data lookup file used by yspec
- analysis1.yml: an example yaml specification file
- analysis1.csv: an example data set that can be checked against 
  analysis1.yml
- ys_example.Rmd: an Rmd document that utilizes the assets listed above
