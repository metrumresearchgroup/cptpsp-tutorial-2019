# coverage: 86.07%

|file               | coverage|
|:------------------|--------:|
|R/help.R           |    69.23|
|R/class-yspec.R    |    75.64|
|R/lookup.R         |    79.49|
|R/class-yproject.R |    79.87|
|R/spec_validate.R  |    80.00|
|R/utils.R          |    80.33|
|R/define.R         |    83.33|
|R/md_outline.R     |    83.33|
|R/col_factor.R     |    85.71|
|R/fda_define.R     |    85.85|
|R/check_spec.R     |    91.20|
|R/class-ycol.R     |    91.67|
|R/load_spec.R      |    94.92|
|R/pander_table.R   |    97.44|
|R/axis_data.R      |   100.00|
|R/exspec.R         |   100.00|
|R/mrgtemmplate.R   |   100.00|
