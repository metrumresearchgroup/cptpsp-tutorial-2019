# texPreview 1.1.5

* fix viewer issue to keep new pages in internal viewer


# texPreview 1.1.4

* Added a `NEWS.md` file to track changes to the package.
* Added pagination of preview outputs in the `Rstudio` internal viewer.
