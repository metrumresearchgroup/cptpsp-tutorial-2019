library(bsplus)
library(texPreview)
library(magrittr)
library(xtable)
outDir='www'
sapply(list.files(outDir,full.names = T),file.remove)

