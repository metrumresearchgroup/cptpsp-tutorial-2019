nr <- 1000
x <- solve( matrix( rnorm(nr^2), nrow=nr, ncol=nr ) )
