citHeader("To cite qapply in publications, please use:")

bibentry(bibtype = "Manual",
         title = "qapply: Parallel R in Grid Engine environments",
         author = person("Daniel G.", "Polhamus"),
         year=2012,
         note="version 1.38",
         url = "https://bitbucket.org/metrumrg/qapply",
         key="qapply-package"
         # ,
         # textVersion = "D. Polhamus. qapply: Parallel R in Grid Engine environments. https://bitbucket.org/metrumrg/qapply"
)
