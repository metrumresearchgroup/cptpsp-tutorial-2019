#' @name qinternalize 
#' @title Aggregate the qapply output and return a list
 
#' @description 
#'  After evaluation of \code{\link{qapply}}, output is stored in the "out"
#'  folder of the specified working directory.  Upon completetion of all
#'  jobs (determined by \code{\link{qwait}}), \code{qinternalize}  is called
#'  to aggregate the output.  Alternatively, if "internalize" is set to
#'  \code{FALSE} in \code{\link{qapply}} then \code{qinternalize} may be
#'  called manually at a later time.
 
#' @usage 
#'  qinternalize(outDir)
 
#' @param outDir  The full path to the directory containing the output.
#' @return A list of values resulting from the \code{\link{qapply}} call.
#' @export

qinternalize <- function( outDir ){
  f <- list.files(outDir)  
  f <- f[ grep('.Robj',f) ]
  f <- f[ order(as.numeric(sapply(strsplit(f, "-"), function(l) l[2]))) ]
  results <- NULL
  for( getMe in f){
    load(file=file.path(outDir,getMe))
    results <- c(results, outVec, recursive=FALSE)
  }
  results
}
                            
