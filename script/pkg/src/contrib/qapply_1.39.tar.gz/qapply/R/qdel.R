#' @inherit qstat
#' @export
qdel <- function(jobs){
  system(paste("qdel", paste(jobs,collapse=',') ))
}