#' @name qsub
#' @title Submit a grid engine job from R
#' @description Provides a wrapper for submitting R jobs to grid engine.
#' @usage qsub(command, tag, q.workDir = NULL, q.binary = "y", q.pe = NULL, q.q = NULL, cmdArgs = NULL, ...)
#' @param command  A binary or script file to be executed through grid engine.
#' @param tag A job name.
#' @param q.workDir Working directory (current working directory by default).  
#' Output and logs will be placed here unless an
#'    alternative is specified.
#' @param q.binary Yes or no, is \code{command} a binary or a script?
#' @param q.pe Parallel environment.  E.g., "orte 16" for 16 slots
#' @param q.q Which queue to submit the job to.  \code{all.q} is the default.
#' @param cmdArgs A list of arguments for \code{command}
#' @details
#'  The utility of this function, as it is simply a wrapper, lies in the
#'  ability to request jobs from R concisely and without system calls.
#'  Example usage cases (outside of \code{\link{qapply}}):
#'    
#'    1: calling an R script that serves as a template, in which case
#'  \code{command="R --no-save"} with \code{cmdArgs="--args <some
#'  args to be passed into R < myScript.R"} and \code{q.binary="y"}.  Here, the user
#'  has written an R script (myScript.R) that takes some arguments (see
#'                                                                  the base help for
#'                                                                  \code{\link{commandArgs}}) and will be executed from within
#'  grid engine.
#'  
#'  2: calling a (bash) script with grid directives, in which case
#'  \code{q.binary="n"} and command is simply the file (and path to file)
#'  of the grid engine control script.
#' @seealso \code{\link{qapply}} \code{\link{commandArgs}}

qsub <- function(command, tag, q.workDir=NULL,
                 q.binary="y", 
                 q.pe=NULL, q.q=NULL, cmdArgs=NULL,
                 ...){
  dots <- list(...)
  if(is.null(q.workDir)){
    invisible(dir.create(file.path(getwd(), "err", tag),recursive=TRUE,showWarnings=FALSE))
    invisible(dir.create(file.path(getwd(), "log", tag),recursive=TRUE,showWarnings=FALSE))
    if( ('rowBegin'%in%names(dots))&('rowEnd'%in%names(dots)) ){
      q.e=file.path(getwd(), "err", tag, paste(tag,'-',dots$rowBegin,'-',dots$rowEnd,'.err',sep=''))
      q.o=file.path(getwd(), "log", tag, paste(tag,'-',dots$rowBegin,'-',dots$rowEnd,'.out',sep=''))
    }else{
      q.e=file.path(getwd(), "err", tag)
      q.o=file.path(getwd(), "log", tag)
    }
  }else{
    invisible(dir.create(file.path(q.workDir,"err", tag),recursive=TRUE,showWarnings=FALSE))
    invisible(dir.create(file.path(q.workDir,"log", tag),recursive=TRUE,showWarnings=FALSE))
    if( ('rowBegin'%in%names(dots))&('rowEnd'%in%names(dots)) ){    
      q.e=file.path(getwd(), "err", tag, paste(tag,'-',dots$rowBegin,'-',dots$rowEnd,'.err',sep=''))
      q.o=file.path(getwd(), "log", tag, paste(tag,'-',dots$rowBegin,'-',dots$rowEnd,'.out',sep=''))
    }else{
      q.e=file.path(getwd(), "err", tag)
      q.o=file.path(getwd(), "log", tag)
    }
    q.e=file.path(q.workDir, "err", tag)
    q.o=file.path(q.workDir, "log", tag)
  }

  qsubArgs <- list(wd=q.workDir, b=q.binary, 
                   e=q.e, o=q.o, pe=q.pe, q=q.q)
  qsubArgs <- qsubArgs[sapply(qsubArgs, function(a){
    !(is.null(a) | length(a)==0 )  } ) ]
  q.cwd=TRUE
  qsubArgs <- paste("-", names(qsubArgs), " ", qsubArgs , sep="")
  if(is.null(q.workDir)) qsubArgs <- c(qsubArgs, "-cwd")
  qsubArgs <- c(qsubArgs, paste("-N", tag), "-V")
  
  system(paste("qsub", 
               paste(qsubArgs, collapse=" "),
               paste("\""),
               command, 
               paste(cmdArgs, collapse=" "),
               paste("\"")
               ))
}
