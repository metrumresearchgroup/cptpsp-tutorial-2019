## Default behavior for packet building is to empty the queue
.nPerPacket <- function(nr, nc){
  standard <- floor(nr/nc)
  nBump <- nr-nc*standard 
  rep(standard, nc) + c(rep(1, nBump), rep(0, nc-nBump))
}

#' @name getResources
#' @title Get SGE resources
#' @details Find the number of (potentially) available slots to push to
#' @import stringr
.getResources <- function(){
  x <- system(" qstat -f", intern = T)
  if(length(x)==0) return(NULL)
  loc <- str_locate(x[1], "resv/used/tot.")
  y <- str_sub(x[-1], loc)
  y <- str_extract(str_trim(y[str_detect(y,"\\d/\\d/\\d")]),"\\d+$")
  return(as.numeric(sum(y)))
}
