#' @name qseed
#' @title Set the random number generator for the rlecuyer package
#' @description
#'   Set the random number stream given a parallel seed for the relecuyer package (6 integers), a number
#'   of total parallel streams, and the current parallel stream.
#' @usage qseed(jobNum = 1, jobTot = 1, parSeed = rep(1124, 6))
#' @param jobNum The index of the current stream, relative to the total number of streams
#'    to be requested.
#' @param jobTot The total number of streams to be requested. 
#' @param parSeed A vector of 6 integers.
#' @details The seed is set using \code{\link{.lec.SetPackageSeed}}.  The current
#'  stream is determined by \code{jobNum} and then stream \code{jobNum} is
#'  started using \code{\link{.lec.CreateStream}}, and \code{\link{.lec.CurrentStream}}.

qseed <- function(jobNum=1, jobTot=1, parSeed=rep(1124, 6)){
  require(rlecuyer)
  .lec.SetPackageSeed(parSeed)
  jobNames <- paste("jobNum", 1:jobTot, sep = "")
  .lec.CreateStream(jobNames)   # This sets the seed tables for jobNum jobs
  # This sets the current RNG stream
  .lec.CurrentStream(paste("jobNum", jobNum, sep=""))
}
  
  