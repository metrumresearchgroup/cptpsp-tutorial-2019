#' @name qwait
#' @title Wait for a named job in the queue to finish
#' @description 
#'  Passing in the job name (or tag), \code{qwait} ties up R until all jobs
#'  matching "tag" are finished before returning control to R.
#' @usage qwait(tag)
qwait <- function(tag){
  while( (length(qstat(paste("-j", tag)))!=0) ){
    system("sleep 1")
  }
}