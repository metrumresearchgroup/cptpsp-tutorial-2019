#' @name qstat
#' @title Wrappers for the grid CLI commands \code{qstat} and \code{qdel}
#' @description \code{qstat} will return the status of the queue and is a direct 
#' wrapper for the CLI command.  \code{qdel} takes only "jobs" as an argument and
#'  will request deletion of the listed jobs.
#' @usage
#'   qstat("-f", "-j <job>", "-u <user>", ...)
#'   qdel(jobs)
#' @details 
#'   A complete list of arguments for qstat is found in the appropriate 
#'    documentation (i.e., \code{system("man qstat")}), but some useful flags are shown in the parameters
#' @param "-f" "Full" format display of information, summary information on all
#'       queues is displayed along with the queued job list
#' @param "-U <user>" Displays all jobs requested by the system user, <user>
#' @param "-j <jobname>" When using \code{qapply}, <jobname> is the argument "tag"
#' @param jobs For qdel, a vector of jobs to be deleted
#' @return Output of the qstat system call
#' @export
qstat <- function(...){
  dots <- list(...)
  dots <- paste(unlist(dots), collapse=" ")
  suppressWarnings( system(paste("qstat", dots),intern=TRUE,ignore.stderr=TRUE) )
}
