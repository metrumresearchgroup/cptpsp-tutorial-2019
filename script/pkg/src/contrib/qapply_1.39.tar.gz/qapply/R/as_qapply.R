
##' Emulate a qapply call using lapply
##' 
##' @inheritParams qapply
##' 
##' @examples
##' 
##' myfun <- function(i) sqrt(i) + A + B
##' 
##' X <- c(1,2,3)
##' 
##' com <- list(A = 1)
##' 
##' B <- 2
##' 
##' as_qapply(X, myfun, commonData = com)
##' 
##' as_qapply(X, myfun, tag = "demo", commonData = com, 
##'           internalize = FALSE, workDir = tempdir())
##' 
##' qinternalize(file.path(tempdir(), "out", "demo"))

as_qapply <- function(X, FUN, fargs=NULL, commonData=NULL, workDir=getwd(),
                      nCores=NULL, global=FALSE,
                      all.names=FALSE, nPerPacket=NULL,
                      tag=deparse(substitute(X)), internalize=TRUE,
                      clearWd=TRUE, parSeed=NULL) {
  fun <- lapply
  if(!is.null(nCores)) {
    if(requireNamespace("parallel") & .Platform$OS.type=="unix" & nCores > 1) {
      fun <- parallel::mclapply
      if(!is.null(parSeed)) set.seed(parSeed, kind="L'Ecuyer-CMRG")
      fargs <- c(fargs, mc.cores=nCores)
    }
  }

  attach(commonData)
  on.exit(detach(commonData))
  outVec <- do.call(fun, c(list(X = X, FUN = FUN), fargs))
  if(internalize) return(outVec)
  outdir <- file.path(workDir,"out", tag)
  if(!dir.exists(outdir)) dir.create(outdir, recursive = TRUE)
  save("outVec", file = file.path(outdir,"outVec-1-1.Robj"))
  return(NULL)
}



