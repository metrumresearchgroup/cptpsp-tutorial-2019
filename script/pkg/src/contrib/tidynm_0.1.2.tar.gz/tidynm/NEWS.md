# tidynm 0.1.2

* Bug Fixes
   - Remove comment lines (i.e., lines only containing comments) from control stream
   - Fixed IOV implementation, introducing SAME column into `paramtbl`
   - Allow for mixture models / more than one subpop
* Refactor
   - Update NSE to use `!!` instead of `UQ`
   - **`table_series` renamed to `estimation_index`**, some potential for breaking old code here
   - More explicit code authoring with regard to `purrr` `FUN` calls to assist debugging

   

# tidynm 0.1.1

* Bug Fixes
   - Fix the mapping the off-diagonal indices from estimated covariance matrix and labels to parameter table, they were being mapped not consistently as are defined in the NONMEM documentation.
   - Change the default reported covariance parameter reported in `param_tbl` to `[A]`, as is stated in documentation. 
* API improvement
   - Add input arguments to `read_extensions` to allow for the more flexibility of the path the files are located at, to allow for generalized naming conventions.
   - Vignette improvements
   - Update the structure of the vignette `Rmd` files to render more efficiently with the new release of texPreview.
    
# tidynm 0.1.0

* Added a `NEWS.md` file to track changes to the package.

* Initial release of the package.
