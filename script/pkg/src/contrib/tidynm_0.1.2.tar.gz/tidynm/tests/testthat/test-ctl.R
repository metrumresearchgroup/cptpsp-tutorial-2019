library(testthat)
library(tidynm)

project <- system.file('extdata',package = 'tidynm')

run <- '510'

xml_raw   <- read_nmlist(run, project)

ctl_raw   <- xml_raw%>%
  xml2::xml_find_first('.//nm:control_stream')%>%
  xml2::xml_text()

x   <- xml_raw%>%
  xml2::xml_find_first('.//nm:control_stream')%>%
  xml2::xml_text()%>%
  tidynm:::clean_ctl()

testthat::context("Parsing CTL Elements")

  testthat::describe("Parse a ctl file",{
  
  ctl_510 <- ctl_parse(system.file("extdata/510.ctl",package="tidynm"))
  
  it('class',{
    testthat::expect_equal(class(ctl_510),"list")
  })
  
  it('elements',{
    testthat::expect_null(purrr::detect(ctl_510, is.null))
  })
})

  testthat::describe("theta",{
  
    THETA <- parse_theta(x$THETA)
    
    it('class',{
      testthat::expect_s3_class(THETA,'data.frame')
      })
    it('dimension',{
      testthat::expect_equal(nrow(THETA),length(x$THETA[[1]]))
      })
  })

  testthat::describe("matrix, comments not block",{
  
    it('full', {
      testthat::expect_equal("FIXED||[p]||Q",tidynm:::parse_mat_noblock('0 FIXED;[p] Q','comment')%>%as.character)
    })
  
    it('no fixed', {
      testthat::expect_equal("||[p]||Q",tidynm:::parse_mat_noblock('0 ;[p] Q','comment')%>%as.character)
    })
    
    it('no type', {
      testthat::expect_equal("FIXED||||Q",tidynm:::parse_mat_noblock('0 FIXED ; Q','comment')%>%as.character)
    })
    
    it('no label', {
      testthat::expect_equal("FIXED||||",tidynm:::parse_mat_noblock('0 FIXED','comment')%>%as.character)
    })
    
    it('only label', {
      testthat::expect_equal("||||Q",tidynm:::parse_mat_noblock('0 ; Q','comment')%>%as.character)
    })
  
    it('only type', {
      testthat::expect_equal("||[p]||",tidynm:::parse_mat_noblock('0 ; [p]','comment')%>%as.character)
    })
    
    it('empty', {
      testthat::expect_equal("||||||",tidynm:::parse_mat_noblock('0','comment')%>%as.character)
    })
    
    
  })
  
  testthat::describe("matrix, comments block",{
    
    test_block <- c("BLOCK(2) 0.830 ;CL", "0.0632 FIXED;[F] CL-V2","0.104 ;[P]")
    
    result_block <- tidynm:::parse_mat_block(test_block,'comment')
    
    expect_block <- matrix(c("||||CL","FIXED||[F]||CL-V2","","||[P]||"),ncol=2)
    
    it('full block', {
      testthat::expect_equal(expect_block,result_block)
    })
    
    test_block_diag <- c("BLOCK(2) 0.830 ;CL", "0.0632 FIXED;[F] CL-V2")
    
    result_block_diag <- tidynm:::parse_mat_block(test_block_diag,'comment')
    
    expect_block_diag <- matrix(c("||||CL","","","FIXED||[F]||CL-V2"),ncol=2)
    
    it('diag block', {
      testthat::expect_equal(expect_block_diag,result_block_diag)
    })
    
  })

  testthat::describe("matrix, numeric block",{
    test_block <- c("BLOCK(2) 0.830 ;CL", "0.0632 FIXED;[F] CL-V2","0.104 ;[P]")
    
    expect_block <- matrix(c(0.830,0.0632,0,0.104),ncol=2)
    result_block <- tidynm:::parse_mat_block(test_block,'numeric')
    
    it('full',{
      testthat::expect_equal(expect_block,result_block)
    })
  })
  
  testthat::describe("matrix, numeric not block",{
    
    it('1x1', {
      testthat::expect_equal(matrix(0,ncol=1,nrow=1),tidynm:::parse_mat_noblock('0 FIXED;[p] Q','numeric'))
    })
    
    
    test_noblock <- c("0 FIXED ;[P] Q","0 FIXED ;[P] V3","0.194 ;[P] KA","0 FIXED ;[P] F","0 FIXED  ;[P] KA2","0 FIXED   ;[P] KA3")
    expect_noblock <- matrix(0,nrow=6,ncol=6)
    expect_noblock[3,3] <- 0.194
    result_noblock <- tidynm:::parse_mat_noblock(test_noblock,'numeric')
    
    it('nxn', {
      testthat::expect_equal(expect_noblock,result_noblock)
    })
    
  })

  testthat::describe("matrix, list input",{

  x   <- read_nmlist('511', project)%>%
      xml2::xml_find_first('.//nm:control_stream')%>%
      xml2::xml_text()%>%
      tidynm:::clean_ctl()
    
    
  OMEGA <- tidynm:::ctl_to_mat(x$OMEGA)
  
  it('list of matrices', {
      testthat::expect_is(OMEGA,'list')
      testthat::expect_length(OMEGA,2)
      testthat::expect_equal(unique(sapply(OMEGA,'class')),'matrix')
  })
  
  OMEGA_COMMENT_BLOCK <- tidynm:::ctl_to_mat(x$OMEGA, type='comment')
  
  it('list of comment blocks', {
      testthat::expect_equal(length(OMEGA),length(OMEGA_COMMENT_BLOCK))
    })
  
  OMEGA_COMMENT <- tidynm:::combine_blocks(OMEGA_COMMENT_BLOCK)
  
  combine_nr <- nrow(OMEGA_COMMENT)
  combine_nc <- ncol(OMEGA_COMMENT)
  
  split_nr <- sum(sapply(OMEGA_COMMENT_BLOCK,nrow))
  split_nc <- sum(sapply(OMEGA_COMMENT_BLOCK,ncol))
  
  it('combine blocks', {
      testthat::expect_equal(combine_nr,split_nr)
      testthat::expect_equal(combine_nc,split_nc)
  })
  
})
  
  testthat::describe("matrix, BLOCK(3)",{
    
    x   <- read_nmlist('101', project)%>%
      xml2::xml_find_first('.//nm:control_stream')%>%
      xml2::xml_text()%>%
      tidynm:::clean_ctl()
    
    
    OMEGA <- tidynm:::ctl_to_mat(x$OMEGA)
    
    it('list of matrices', {
      testthat::expect_equal(class(OMEGA),'matrix')
    })
    
    OMEGA_COMMENT_BLOCK <- tidynm:::ctl_to_mat(x$OMEGA, type='comment')
    
    it('list of comment blocks', {
      testthat::expect_equal(length(OMEGA),length(OMEGA_COMMENT_BLOCK))
    })
    
    # build cov matix
    elems <- as.numeric(trimws(gsub('^BLOCK\\(3\\)|;(.*?)$','',x$OMEGA[[1]])))
    mat <- matrix(0,3,3)
    mat[upper.tri(mat,diag = TRUE)] <- elems
    
    it('verify indexation mapping',{
     testthat::expect_equal(t(mat),OMEGA) 
    })
    
  })

testthat::test_that('Parse complete control stream',{

  ctl_parsed <- ctl_raw%>%
    ctl_parse()
  
  testthat::expect_is(ctl_parsed,'list')
  
})

testthat::describe('sorting comments',{
  
  it('full single word', {
    testthat::expect_equal("FIXED||[p]||radio",tidynm:::parse_mat_noblock('0 FIXED;radio [p]','comment')%>%as.character)
  })
  
  it('full multiword', {
    testthat::expect_equal("FIXED||[p]||radio ga ga",tidynm:::parse_mat_noblock('0 FIXED;radio ga ga [p]','comment')%>%as.character)
  })
  
  it('no fixed', {
    testthat::expect_equal("||[p]||radio ga ga",tidynm:::parse_mat_noblock('0 ;radio ga ga [p]','comment')%>%as.character)
  })
  
  it('no type', {
    testthat::expect_equal("FIXED||||radio ga ga",tidynm:::parse_mat_noblock('0 FIXED ; radio ga ga','comment')%>%as.character)
  })
  
  it('only label', {
    testthat::expect_equal("||||radio ga ga",tidynm:::parse_mat_noblock('0 ; radio ga ga','comment')%>%as.character)
  })

  it('empty', {
    testthat::expect_equal("||||||",tidynm:::parse_mat_noblock('0','comment')%>%as.character)
  })
  
  test_block <- c("BLOCK(2) 0.830 ;CL", "0.0632 FIXED;CL-V2 [F]","0.104 ;[P]")
  
  result_block <- tidynm:::parse_mat_block(test_block,'comment')
  expect_block <- matrix(c("||||CL","FIXED||[F]||CL-V2","","||[P]||"),ncol=2)
  
  it('full block', {
    testthat::expect_equal(expect_block,result_block)
  })
})

testthat::describe('remove comment lines in ctl',{
  
  no_comment <- ctl_raw%>%
    tidynm:::ctl_rm_comments()

  it('find comment line from omega',{
    testthat::expect_true(grepl('; a comment',ctl_raw))
  })
    
  it('remove comment line from omega',{
    testthat::expect_false(grepl('; a comment',no_comment))
  })
})