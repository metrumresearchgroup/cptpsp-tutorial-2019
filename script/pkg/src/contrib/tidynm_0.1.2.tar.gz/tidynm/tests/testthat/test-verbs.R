library(testthat)
library(tidynm)

testthat::context("Nibble Verbs")

john_11 <- dplyr::as_tibble(mtcars)%>%dplyr::slice(1:2)
john_12 <- dplyr::as_tibble(iris)%>%dplyr::slice(1:2)

john_21 <- dplyr::as_tibble(mtcars)%>%dplyr::slice(1:5)
john_22 <- dplyr::as_tibble(iris)%>%dplyr::slice(1:5)

a  <- dplyr::tibble(x=list(
  john = list(bob=john_11,bobo=john_12),
  johnny = list(bob=john_21,'_bobo'=john_22))
)

testthat::describe("burrow noregex",{
  
  it('name',{
    testthat::expect_equal(john_21,a%>%burrow('x/johnny/bob'))  
  })
  
  it('name and index',{
    testthat::expect_equal(john_11,a%>%burrow('x/john/[1]'))  
  })
  
  it('index',{
    testthat::expect_equal(john_12,a%>%burrow('x/[1]/[2]'))
  })
  
  it('remove empty list parents', {
    testthat::expect_equal(
      list(list(john_11))%>%burrow('[1]'),
      john_11
    )
  })
  
})

testthat::describe("burrow regex",{
  
  it('open grep', {
    testthat::expect_equal(
      unlist(a$x,recursive = FALSE),
      a%>%burrow('x/john/bob',regex = TRUE)
    )
  })
  
  it('use $', {
    testthat::expect_equal(
      list(bob=john_11,bobo=john_12),
      a%>%burrow('x/john$/bob',regex = TRUE)
    )
  })
  
  it('use ^', {
    testthat::expect_equal(
      john_21,
      a%>%burrow('x/johnny/^bob',regex = TRUE)
    )
  })
  
})

x <- list(NULL,list(a=list(1,NULL)),list(b=list(list(3,NA),2)))

testthat::describe('purge single predicate', {
  
  it('NULL',{
    testthat::expect_true(length(purge(x,.p = is.null)) < length(x))
  })
  
})

testthat::describe('purge function predicate', {
  
  p <- purge(x,.p=function(y) is.null(y)||is.na(y))
  
  it('NULL and NA',{
    
    testthat::expect_true(length(p) < length(x))
    
    testthat::expect_true(length(unlist(p)) < length(unlist(x)))
    
  })
  
})

testthat::describe('purge nonlist input', {
  
  it('data.frame',{
    p <- purge(data.frame(x=1))
    
    testthat::expect_is(p,'data.frame')
    testthat::expect_equal(nrow(p),1)
  })
  
  it('numeric',{
    p <- purge(c(2))
    
    testthat::expect_is(p,'numeric')
    testthat::expect_equal(length(p),0)
  })
  
})

testthat::describe("pluck elements",{
  
  apluck <- tidynm:::mrg_pluck(purrr::pluck)
  
  base_id_1 <- letters[1:3]
  
  base_id_2 <- LETTERS[1:3]
  
  base_list <- list(c(1),c(2),c(3))
  
  x <- dplyr::data_frame(id_1=base_id_1,x=base_list)%>%
    ipluck('x',.id='id_1')
  
  x2 <- dplyr::data_frame(id_1=base_id_1,x=base_list)%>%
    dplyr::mutate(id_2=base_id_2)%>%
    ipluck('x',.id=c('id_1','id_2'))
  
  it('single column named', {
    expect_named(x)
  })
  
  it('single column correct name', {
    expect_equal(x%>%names(),
                 base_id_1)
  })
  
  it('multiple columns named', {
    expect_named(x2)
  })
  
  it('multiple columns correct names', {
    expect_equal(x2%>%names(),
                 paste(base_id_1,
                       base_id_2,
                       sep='_'))
  })
  
  it('bad input', {
    expect_error(
      dplyr::data_frame(id_1=base_id_1,x=base_list)%>%
        ipluck('x',.id='id')
    )
  })
  
  it('no names', {
    expect_null(
      dplyr::data_frame(id_1=base_id_1,x=base_list)%>%
        ipluck('x')%>%
        names()
    )
  })
  
})

x <- dplyr::data_frame(a = list(x=1, y=2),
                       b = list(x='a', y='y'),
                       c = list(x=TRUE,y=FALSE),
                       d = list(x=1,y='y'))%>%
  dplyr::mutate_all(flatten_auto)

testthat::describe('flatten_auto lists', {
  
  it("numeric",{
    expect_is(x$a,'numeric')
  })
  
  it("character",{
    expect_is(x$b,'character')
  })
  
  it("logical",{
    expect_is(x$c,'logical')
  })
  
  it("list",{
    expect_is(x$d,'list')
  })
  
})