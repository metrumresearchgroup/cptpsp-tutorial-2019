library(testthat)
library(tidynm)

project <- system.file('extdata',package = 'tidynm')

run <- '510'

xml_out <- read_nmlist(run = run,project = project)

testthat::context('nmlist functions')

testthat::test_that("read_nmlist", {
    
  node_names <- xml_out%>%
    xml2::xml_children()%>%
    xml2::xml_name()
  
  testthat::expect_s3_class(xml_out,'xml_document')
  
  testthat::expect_equal(node_names,expected = c("start_datetime",
                                       "control_stream",
                                       "nmtran",
                                       "nonmem",
                                       "stop_datetime",
                                       "total_cputime"))
})

testthat::describe("parse nmlist for mrgsolve",{
  
  p_xml <- xml_out%>%
    parse_nmlist(fields = 'mrgsolve')
  
  it('parent', {
    testthat::expect_length(p_xml,14)
    testthat::expect_is(p_xml,'list')
    testthat::expect_named(p_xml)
    })

  it('theta', {
    testthat::expect_is(p_xml$theta,'numeric')
    testthat::expect_named(p_xml$theta)    
  })
  
  it('matrix', {
    testthat::expect_is(p_xml$cov,'matrix')    
  })
 
})

testthat::describe("parse nmlist for subset of fields",{
  
  p_xml <- xml_out%>%
    parse_nmlist(fields = c('theta','covariance'))
  
  it('parent', {
    testthat::expect_length(p_xml,2)
    testthat::expect_is(p_xml,'list')    
    testthat::expect_named(p_xml)
  })
  
  it('children', {
    testthat::expect_is(p_xml$theta,'numeric')
    testthat::expect_named(p_xml$theta)
    testthat::expect_is(p_xml$cov,'matrix')      
  })
  
})

testthat::describe("parse nmlist with attributes",{
  
  p_xml <- xml_out%>%
    parse_nmlist(attach_attr = TRUE)
  
  it('theta', {
      testthat::expect_is(p_xml$theta,'matrix')
    })
  
  it('cov', {
    testthat::expect_is(p_xml$cov,'matrix')
    testthat::expect_length(colnames(p_xml$cov),6)
    })
  
  it('cor', {
    testthat::expect_is(p_xml$cor,'matrix')
    testthat::expect_length(colnames(p_xml$cor),6)
    })
  
})

testthat::test_that("parse nmlist with all estimations in run",{

  p_xml <- xml_out%>%
    parse_nmlist(fields = 'all',index='all')
  
  testthat::expect_length(p_xml,4)
  
})

testthat::test_that("parse nmlist with subset of estimations in run",{
  
  p_xml <- xml_out%>%
    parse_nmlist(fields = 'all',index=c(1,3))
  
  testthat::expect_length(p_xml,2)
  
})

testthat::context('nmlog functions')  

testthat::describe("create nmlog output",{
    
  x <- nmlog(run,project)
  
  it('names', {
    testthat::expect_named(x)
    })
  
  it('length', {
    testthat::expect_equal(ncol(x),13)
    })
  
  it('class', {
    testthat::expect_s3_class(x,'data.frame')
    })
})


testthat::describe('verify values of xml to output files',{
  
  ext <- read_extensions(path = system.file('extdata/510',package = 'tidynm'),
                         exts = c('ext','cov','cor'))
  
  nbl <- xml_out%>%parse_nmlist(fields = 'all',attach_attr = TRUE)
  
  THETA <- ext$ext[[1]]%>%
    dplyr::filter(ITERATION==-1000000000)%>%
    dplyr::select(dplyr::contains('THETA'))
  
  THETASE <- ext$ext[[1]]%>%
    dplyr::filter(ITERATION==-1000000001)%>%
    dplyr::select(dplyr::contains('THETA'))  
  
  OMEGA <- ext$ext[[1]]%>%
    dplyr::filter(ITERATION==-1000000000)%>%
    dplyr::select(dplyr::contains('OMEGA'))
  
  OMEGASE <- ext$ext[[1]]%>%
    dplyr::filter(ITERATION==-1000000001)%>%
    dplyr::select(dplyr::contains('OMEGA'))
  
  SIGMA <- ext$ext[[1]]%>%
    dplyr::filter(ITERATION==-1000000000)%>%
    dplyr::select(dplyr::contains('SIGMA'))
  
  SIGMASE <- ext$ext[[1]]%>%
    dplyr::filter(ITERATION==-1000000001)%>%
    dplyr::select(dplyr::contains('SIGMA'))
  
  OBJ <- ext$ext[[1]]%>%
    dplyr::filter(ITERATION==-1000000000)%>%
    dplyr::select(dplyr::contains('OBJ'))
  
  COV <- as.matrix(ext$cov[[1]][,-1])
  
  
  NBL_COV <- nbl$covariance
  
  
  COV_SUMS <- signif(apply(COV,2,sum),3)
  NBL_COV_SUMS <- signif(apply(NBL_COV,2,sum),3)

  names(COV_SUMS) <- gsub('\\.$','',names(COV_SUMS))
  names(COV_SUMS) <- gsub('A\\.','A',names(COV_SUMS))

  idx <- intersect(names(COV_SUMS),names(NBL_COV_SUMS))

  COR <- as.matrix(ext$cor[[1]][,-1])  
  NBL_COR <- nbl$correlation
  COR_SUMS <- signif(apply(COR,2,sum),3)
  NBL_COR_SUMS <- signif(apply(NBL_COR,2,sum),3)
  
  names(COR_SUMS) <- gsub('\\.$','',names(COR_SUMS))
  names(COR_SUMS) <- gsub('A\\.','A',names(COR_SUMS))
  
  idx_cor <- intersect(names(COR_SUMS),names(NBL_COR_SUMS))
  
  it('theta',{
    testthat::expect_true(all(signif(nbl$theta,3)==signif(THETA,3)))
  })
  
  it('thetase',{
    testthat::expect_true(all(signif(nbl$thetase,3)==signif(THETASE,3)))
  })
  
  it('omega',{
    testthat::expect_true(all(signif(nbl$omega[lower.tri(nbl$omega,diag = TRUE)],3)==signif(OMEGA,3)))
  })
  
  it('omegase',{
    testthat::expect_true(all(signif(nbl$omegase[lower.tri(nbl$omegase,diag = TRUE)],3)==signif(OMEGASE,3)))
  })  
  
  it('sigma',{
    testthat::expect_true(all(signif(nbl$sigma,3)==signif(SIGMA,3)))
  })
  
  it('sigmase',{
    testthat::expect_true(all(signif(nbl$sigmase,3)==signif(SIGMASE,3)))
  })
  
  it('final objective value',{
    testthat::expect_equal(signif(as.numeric(nbl$final_objective_function),3),signif(OBJ$OBJ,3))
  })
  
  it('covariance',{
    testthat::expect_equal(COV_SUMS[idx],NBL_COV_SUMS[idx])
  })
  
  it('correlation',{
    testthat::expect_equal(COR_SUMS[idx_cor],NBL_COR_SUMS[idx_cor])
  })
})

testthat::describe('mixture models',{
  
  mixture <- tidynm::nibble(
    project = system.file('extdata',package = 'tidynm'),
    run = 2,
    include_tabs = FALSE
    )
  
  x <- mixture$etabar[[1]]
  
  it('multiple subpopulations in etabar dim',{
    testthat::expect_equal(dim(x),c(3,4))
  })
  
  it('multiple subpopulations in etabar rownames',{
    testthat::expect_equal(as.character(rownames(x)),sprintf('SUBPOP%s',1:3))
  })
  
  it('multiple subpopulations in etabar colnames',{
    testthat::expect_equal(as.character(colnames(x)),sprintf('ETA%s',1:4))
  })
})