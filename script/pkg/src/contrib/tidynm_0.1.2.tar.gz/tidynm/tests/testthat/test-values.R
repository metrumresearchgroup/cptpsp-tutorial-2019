library(testthat)
library(tidynm)

project <- system.file('extdata',package = 'tidynm')

run <- '510'

xml_out <- read_nmlist(run = run,project = project)

testthat::context('verify xml values')

testthat::describe('verify values of xml to output files',{
  
  ext <- read_extensions(path = system.file('extdata/510',package = 'tidynm'),
                          exts = c('ext','cov','cor'))
  
  nbl <- xml_out%>%parse_nmlist(fields = 'all',attach_attr = TRUE)
  
  THETA <- ext$ext[[1]]%>%
    dplyr::filter(ITERATION==-1000000000)%>%
    dplyr::select(dplyr::contains('THETA'))
  
  THETASE <- ext$ext[[1]]%>%
    dplyr::filter(ITERATION==-1000000001)%>%
    dplyr::select(dplyr::contains('THETA'))  
  
  OMEGA <- ext$ext[[1]]%>%
    dplyr::filter(ITERATION==-1000000000)%>%
    dplyr::select(dplyr::contains('OMEGA'))
  
  OMEGASE <- ext$ext[[1]]%>%
    dplyr::filter(ITERATION==-1000000001)%>%
    dplyr::select(dplyr::contains('OMEGA'))
  
  SIGMA <- ext$ext[[1]]%>%
    dplyr::filter(ITERATION==-1000000000)%>%
    dplyr::select(dplyr::contains('SIGMA'))
  
  SIGMASE <- ext$ext[[1]]%>%
    dplyr::filter(ITERATION==-1000000001)%>%
    dplyr::select(dplyr::contains('SIGMA'))
  
  OBJ <- ext$ext[[1]]%>%
    dplyr::filter(ITERATION==-1000000000)%>%
    dplyr::select(dplyr::contains('OBJ'))
  
  COV <- as.matrix(ext$cov[[1]][,-1])
  
  NBL_COV <- nbl$covariance
  
  COV_SUMS <- signif(apply(COV,2,sum),3)
  NBL_COV_SUMS <- signif(apply(NBL_COV,2,sum),3)
  
  names(COV_SUMS) <- gsub('\\.$','',names(COV_SUMS))
  names(COV_SUMS) <- gsub('A\\.','A',names(COV_SUMS))
  
  idx <- intersect(names(COV_SUMS),names(NBL_COV_SUMS))
  
  COR <- as.matrix(ext$cor[[1]][,-1])  
  NBL_COR <- nbl$correlation
  COR_SUMS <- signif(apply(COR,2,sum),3)
  NBL_COR_SUMS <- signif(apply(NBL_COR,2,sum),3)
  
  names(COR_SUMS) <- gsub('\\.$','',names(COR_SUMS))
  names(COR_SUMS) <- gsub('A\\.','A',names(COR_SUMS))
  
  idx_cor <- intersect(names(COR_SUMS),names(NBL_COR_SUMS))
  
  it('theta',{
    testthat::expect_true(all(signif(nbl$theta,3)==signif(THETA,3)))
  })
  
  it('thetase',{
    testthat::expect_true(all(signif(nbl$thetase,3)==signif(THETASE,3)))
  })
  
  it('omega',{
    testthat::expect_true(all(signif(nbl$omega[lower.tri(nbl$omega,diag = TRUE)],3)==signif(OMEGA,3)))
  })
  
  it('omegase',{
    testthat::expect_true(all(signif(nbl$omegase[lower.tri(nbl$omegase,diag = TRUE)],3)==signif(OMEGASE,3)))
  })  
  
  it('sigma',{
    testthat::expect_true(all(signif(nbl$sigma,3)==signif(SIGMA,3)))
  })
  
  it('sigmase',{
    testthat::expect_true(all(signif(nbl$sigmase,3)==signif(SIGMASE,3)))
  })
  
  it('final objective value',{
    testthat::expect_equal(signif(as.numeric(nbl$final_objective_function),3),signif(OBJ$OBJ,3))
  })
  
  it('covariance',{
    testthat::expect_equal(COV_SUMS[idx],NBL_COV_SUMS[idx])
  })

  it('correlation',{
    testthat::expect_equal(COR_SUMS[idx_cor],NBL_COR_SUMS[idx_cor])
  })
})