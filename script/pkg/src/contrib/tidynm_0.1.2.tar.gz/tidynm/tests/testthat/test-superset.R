library(testthat)
library(tidynm)

test_nbl <- nibble(project = system.file('extdata',package = 'tidynm'),run = c('510'),include_tabs = TRUE)

test_nbl$table[[1]][[1]] <- test_nbl$table[[1]][[1]]%>%dplyr::mutate(index__ = 1:n())

test_dat <- readr::read_csv(system.file('extdata/poppk_wcovs.csv',package = 'tidynm'))

test_dat <- test_dat%>%dplyr::mutate(index__ = 1:n())

testthat::context("merge estimation output tables with input data")

  testthat::describe("df to tbl_df", {
  
    xtab <- test_nbl$table[[1]][[1]]
    
    it('nibble reads in a tibble', {
      testthat::expect_s3_class(xtab,'tbl_df')
    })
    
    # join data_frame to data_frame
    new_dat <- xtab%>%
      superset(test_dat)
    
    it('join returns a tibble', {
      testthat::expect_s3_class(new_dat,'tbl_df')
    })
  
    it('number of intersecting names joined', {
      testthat::expect_length(grep('\\.x',names(new_dat)),3)
    })
    
})
  
  testthat::describe("list to tbl_df", {
  
    # join list to data_frame
    new_dat <- test_nbl$table[[1]]%>%
      superset(test_dat)
    
    it('join returns a tibble', {
      testthat::expect_s3_class(new_dat,'tbl_df')
    })
    
    it('number of intersecting names joined', {
      testthat::expect_length(grep('\\.x',names(new_dat)),3)
    })
    
})
  
  testthat::describe("tbl_df to tbl_df", {
    
    # join tbl column to data_frame
    new_dat <- test_nbl%>%
      dplyr::mutate(newdat = purrr::map(table,superset,test_dat))%>%
      purrr::pluck('newdat')%>%
      purrr::flatten_df()
    
    it('join returns a tibble', {
      testthat::expect_s3_class(new_dat,'tbl_df')
    })
    
    it('number of intersecting names joined', {
      testthat::expect_length(grep('\\.x',names(new_dat)),3)
    })
    
})

  testthat::describe("nibble to tbl_df", {
  
  new_dat <- test_nbl%>%
    superset()%>%
    purrr::flatten_df()
  
  it('join returns a tibble', {
    testthat::expect_s3_class(new_dat,'tbl_df')
  })
  
  it('number of intersecting names joined', {
    testthat::expect_length(grep('\\.x',names(new_dat)),3)
  })
  
  test_nbl <- nibble(project = system.file('extdata',package = 'tidynm'),run = c('510'))
  
  new_dat <- test_nbl%>%
    superset()%>%
    purrr::flatten_df()
  
  it('join returns a tibble', {
    testthat::expect_s3_class(new_dat,'tbl_df')
  })
  
  it('number of intersecting names joined', {
    testthat::expect_length(grep('\\.x',names(new_dat)),3)
  })
  
})
  