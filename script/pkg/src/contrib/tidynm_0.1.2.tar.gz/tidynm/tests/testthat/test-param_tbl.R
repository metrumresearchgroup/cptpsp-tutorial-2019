library(testthat)
library(tidynm)

project <- system.file('extdata',package = 'tidynm')

nbl <- nibble(run = "510",project = project)
nbl_fixed <- nibble(run = "510_fixed",project = project)
nbl_101 <- nibble(run = "101",project = project)

# These are validated versions of the control streams with the following timestamps

# > system("ls -al tidynm/inst/extdata/510/510.xml")
# -rw-r--r--  1 danp  staff  75418 Jul 19 11:35 tidynm/inst/extdata/510/510.xml
# > system("ls -al tidynm/inst/extdata/510_fixed/510_fixed.xml")
# -rw-r--r--  1 danp  staff  27464 Jul 19 15:35 tidynm/inst/extdata/510_fixed/510_fixed.xml
# > system("ls -al tidynm/inst/extdata/101/101.xml")
# -rw-r--r--  1 yonis  staff  47059 Sep 17 11:04 inst/extdata/101/101.xml

# saveRDS(nbl$PARAMTBL, file="tests/benchmark/510_PARAMTBL.rds")
# saveRDS(nbl_fixed$PARAMTBL, file="tests/benchmark/510_fixed_PARAMTBL.rds")
# saveRDS(nbl_101$PARAMTBL, file="tests/benchmark/101_PARAMTBL.rds")

testthat::context('verify parameter table values')

testthat::describe('Test against 510.xml, no FIXED or SAME',{
  
  it('Benchmark test to saved object',{
    testthat::expect_equal(readRDS("../benchmark/510_PARAMTBL.rds"), nbl$PARAMTBL)
  })
    
})

testthat::describe('Test against 510_fixed.xml, many variations of FIX, FIXED, SAME',{
  
  it('Benchmark test to saved object',{
    testthat::expect_equal(readRDS("../benchmark/510_fixed_PARAMTBL.rds"), nbl_fixed$PARAMTBL)
  })
  
})

testthat::describe('Test against 101.xml, BLOCK(3)',{
  
  it('Benchmark test to saved object',{
    testthat::expect_equal(readRDS("../benchmark/101_PARAMTBL.rds"), nbl_101$PARAMTBL)
  })
  
})
