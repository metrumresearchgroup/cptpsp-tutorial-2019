library(testthat)
library(tidynm)

testthat::context('read additional extensions')

path <- system.file('extdata/510',package = 'tidynm')

testthat::describe('all extensions all estimations',{
  
  x <- read_extensions(path = path)
  
  it('dimension',{
    testthat::expect_equal(nrow(x),4)
  })
  
  it('object class',{
    testthat::expect_is(x,
                        'tbl_df')
  })
  
  it('column class',{
    testthat::expect_is(x%>%
                          purrr::pluck('coi'),
                        'list')
  })
  
  it('column element class',{
    testthat::expect_is(x%>%
                          purrr::pluck('coi')%>%
                          purrr::discard(is.null)%>%
                          purrr::flatten_df(),
                        'tbl_df')
  })
  
  it('non null element',{
    testthat::expect_equal(x%>%
                             purrr::pluck('ext')%>%
                             purrr::map_lgl(.f = function(xx) !is.null(xx))%>%
                             which(),4)
  })
  
})

testthat::describe('all extensions all estimations',{
  
  x <- read_extensions(path = path,est_ind = identity)
  
  it('dimension',{
    testthat::expect_equal(nrow(x),4)
  })
  
  it('non null element',{
    testthat::expect_equal(x%>%
                             purrr::pluck('ext')%>%
                             purrr::map_lgl(.f = function(xx) !is.null(xx))%>%
                             which(),1:4)
  })
  
})

testthat::describe('subset of extensions last estimation',{
  
  x <- read_extensions(path = path,exts = c('ext','cov'))
  
  it('dimension',{
    testthat::expect_equal(dim(x),c(1,3))
  })
  
  it('column names',{
    testthat::expect_equal(names(x),c('estimation_index','cov','ext'))
  })
  
})

testthat::describe('subset of extensions all estimations',{
  
  x <- read_extensions(path = path,exts = c('ext','cov'),est_ind = identity)
  
  it('dimension',{
    testthat::expect_equal(dim(x),c(4,3))
  })
  
  it('column names',{
    testthat::expect_equal(names(x),c('estimation_index','cov','ext'))
  })
  
})

testthat::describe('user defined estimation filter',{
  
  x <- read_extensions(path = path,
                        est_ind = function(x) x[names(x)%in%c(1,3)],
                        exts = c('ext','cov'))
  
  it('dimension',{
    testthat::expect_equal(dim(x),c(2,3))
  })
  
  it('column names',{
    testthat::expect_equal(names(x),c('estimation_index','cov','ext'))
  })
  
})

testthat::describe('bad extension',{
  
  x <- read_extensions(path = path,exts = c('xml'))
  
  it('ask for xml',{
    testthat::expect_null(x)
  })
  
})

testthat::describe('different root name',{

  file.copy(path,tempdir(),recursive = TRUE)
  
  td <- file.path(tempdir(),'510')
  
  invisible(
    sapply(list.files(td),
         function(x,td){
           file.rename(from = file.path(td,x), to = file.path(td,gsub('510','AAA',x)))
           },td = td)
  )
  
  x <- read_extensions(path = td,root = 'AAA', est_ind = identity)
  
  it('dimension',{
    testthat::expect_equal(nrow(x),4)
  })
  
  it('object class',{
    testthat::expect_is(x,
                        'tbl_df')
  })
  
  unlink(td,recursive = TRUE,force = TRUE)

})