library(testthat)
library(tidynm)

test_check("tidynm")
