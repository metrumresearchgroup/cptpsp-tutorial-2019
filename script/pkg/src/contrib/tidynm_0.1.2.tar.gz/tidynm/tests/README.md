Tests and Coverage
================
30 November, 2018 11:21:56

This output is created by
[covrpage](https://github.com/yonicd/covrpage).

## Coverage

Coverage summary is created using the
[covr](https://github.com/r-lib/covr) package.

| Object                                         | Coverage (%) |
| :--------------------------------------------- | :----------: |
| tidynm                                         |    97.61     |
| [R/superset.R](../R/superset.R)                |    92.86     |
| [R/ctl\_parse.R](../R/ctl_parse.R)             |    94.55     |
| [R/param\_tbl.R](../R/param_tbl.R)             |    96.72     |
| [R/burrow.R](../R/burrow.R)                    |    96.88     |
| [R/nibble.R](../R/nibble.R)                    |    97.10     |
| [R/nm\_list.R](../R/nm_list.R)                 |    97.63     |
| [R/ctl\_to\_mat.R](../R/ctl_to_mat.R)          |    98.02     |
| [R/ipluck.R](../R/ipluck.R)                    |    100.00    |
| [R/nm\_dat.R](../R/nm_dat.R)                   |    100.00    |
| [R/nm\_tab.R](../R/nm_tab.R)                   |    100.00    |
| [R/nmlog.R](../R/nmlog.R)                      |    100.00    |
| [R/parse\_theta.R](../R/parse_theta.R)         |    100.00    |
| [R/purge.R](../R/purge.R)                      |    100.00    |
| [R/read\_extensions.R](../R/read_extensions.R) |    100.00    |
| [R/utils.R](../R/utils.R)                      |    100.00    |

<br>

## Unit Tests

Unit Test summary is created using the
[testthat](https://github.com/r-lib/testthat)
package.

| file                                           |  n |  time | error | failed | skipped | warning |
| :--------------------------------------------- | -: | ----: | ----: | -----: | ------: | ------: |
| [test-ctl.R](testthat/test-ctl.R)              | 35 | 0.120 |     0 |      0 |       0 |       0 |
| [test-nmlist.R](testthat/test-nmlist.R)        | 36 | 0.425 |     0 |      0 |       0 |       0 |
| [test-param\_tbl.R](testthat/test-param_tbl.R) |  3 | 0.008 |     0 |      0 |       0 |       0 |
| [test-read\_exts.R](testthat/test-read_exts.R) | 16 | 0.024 |     0 |      0 |       0 |       0 |
| [test-superset.R](testthat/test-superset.R)    | 11 | 0.020 |     0 |      0 |       0 |       0 |
| [test-values.R](testthat/test-values.R)        |  9 | 0.016 |     0 |      0 |       0 |       0 |
| [test-verbs.R](testthat/test-verbs.R)          | 24 | 0.225 |     0 |      0 |       0 |       0 |

<details closed>

<summary> Show Detailed Test Results
</summary>

| file                                                     | context                                        | test                                                                                             | status | n |  time |
| :------------------------------------------------------- | :--------------------------------------------- | :----------------------------------------------------------------------------------------------- | :----- | -: | ----: |
| [test-ctl.R](testthat/test-ctl.R#L26)                    | Parsing CTL Elements                           | Parse a ctl file: class                                                                          | PASS   | 1 | 0.002 |
| [test-ctl.R](testthat/test-ctl.R#L30)                    | Parsing CTL Elements                           | Parse a ctl file: elements                                                                       | PASS   | 1 | 0.013 |
| [test-ctl.R](testthat/test-ctl.R#L39)                    | Parsing CTL Elements                           | theta: class                                                                                     | PASS   | 1 | 0.005 |
| [test-ctl.R](testthat/test-ctl.R#L42)                    | Parsing CTL Elements                           | theta: dimension                                                                                 | PASS   | 1 | 0.003 |
| [test-ctl.R](testthat/test-ctl.R#L49)                    | Parsing CTL Elements                           | matrix, comments not block: full                                                                 | PASS   | 1 | 0.003 |
| [test-ctl.R](testthat/test-ctl.R#L53)                    | Parsing CTL Elements                           | matrix, comments not block: no fixed                                                             | PASS   | 1 | 0.003 |
| [test-ctl.R](testthat/test-ctl.R#L57)                    | Parsing CTL Elements                           | matrix, comments not block: no type                                                              | PASS   | 1 | 0.002 |
| [test-ctl.R](testthat/test-ctl.R#L61)                    | Parsing CTL Elements                           | matrix, comments not block: no label                                                             | PASS   | 1 | 0.006 |
| [test-ctl.R](testthat/test-ctl.R#L65)                    | Parsing CTL Elements                           | matrix, comments not block: only label                                                           | PASS   | 1 | 0.003 |
| [test-ctl.R](testthat/test-ctl.R#L69)                    | Parsing CTL Elements                           | matrix, comments not block: only type                                                            | PASS   | 1 | 0.002 |
| [test-ctl.R](testthat/test-ctl.R#L73)                    | Parsing CTL Elements                           | matrix, comments not block: empty                                                                | PASS   | 1 | 0.004 |
| [test-ctl.R](testthat/test-ctl.R#L88)                    | Parsing CTL Elements                           | matrix, comments block: full block                                                               | PASS   | 1 | 0.003 |
| [test-ctl.R](testthat/test-ctl.R#L98)                    | Parsing CTL Elements                           | matrix, comments block: diag block                                                               | PASS   | 1 | 0.002 |
| [test-ctl.R](testthat/test-ctl.R#L110)                   | Parsing CTL Elements                           | matrix, numeric block: full                                                                      | PASS   | 1 | 0.002 |
| [test-ctl.R](testthat/test-ctl.R#L117)                   | Parsing CTL Elements                           | matrix, numeric not block: 1x1                                                                   | PASS   | 1 | 0.008 |
| [test-ctl.R](testthat/test-ctl.R#L127)                   | Parsing CTL Elements                           | matrix, numeric not block: nxn                                                                   | PASS   | 1 | 0.001 |
| [test-ctl.R](testthat/test-ctl.R#L143)                   | Parsing CTL Elements                           | matrix, list input: list of matrices                                                             | PASS   | 3 | 0.005 |
| [test-ctl.R](testthat/test-ctl.R#L151)                   | Parsing CTL Elements                           | matrix, list input: list of comment blocks                                                       | PASS   | 1 | 0.001 |
| [test-ctl.R](testthat/test-ctl.R#L163)                   | Parsing CTL Elements                           | matrix, list input: combine blocks                                                               | PASS   | 2 | 0.002 |
| [test-ctl.R](testthat/test-ctl.R#L180)                   | Parsing CTL Elements                           | matrix, BLOCK(3): list of matrices                                                               | PASS   | 1 | 0.001 |
| [test-ctl.R](testthat/test-ctl.R#L186)                   | Parsing CTL Elements                           | matrix, BLOCK(3): list of comment blocks                                                         | PASS   | 1 | 0.002 |
| [test-ctl.R](testthat/test-ctl.R#L195)                   | Parsing CTL Elements                           | matrix, BLOCK(3): verify indexation mapping                                                      | PASS   | 1 | 0.002 |
| [test-ctl.R](testthat/test-ctl.R#L205)                   | Parsing CTL Elements                           | Parse complete control stream                                                                    | PASS   | 1 | 0.026 |
| [test-ctl.R](testthat/test-ctl.R#L212)                   | Parsing CTL Elements                           | sorting comments: full single word                                                               | PASS   | 1 | 0.002 |
| [test-ctl.R](testthat/test-ctl.R#L216)                   | Parsing CTL Elements                           | sorting comments: full multiword                                                                 | PASS   | 1 | 0.002 |
| [test-ctl.R](testthat/test-ctl.R#L220)                   | Parsing CTL Elements                           | sorting comments: no fixed                                                                       | PASS   | 1 | 0.002 |
| [test-ctl.R](testthat/test-ctl.R#L224)                   | Parsing CTL Elements                           | sorting comments: no type                                                                        | PASS   | 1 | 0.004 |
| [test-ctl.R](testthat/test-ctl.R#L228)                   | Parsing CTL Elements                           | sorting comments: only label                                                                     | PASS   | 1 | 0.002 |
| [test-ctl.R](testthat/test-ctl.R#L232)                   | Parsing CTL Elements                           | sorting comments: empty                                                                          | PASS   | 1 | 0.003 |
| [test-ctl.R](testthat/test-ctl.R#L241)                   | Parsing CTL Elements                           | sorting comments: full block                                                                     | PASS   | 1 | 0.001 |
| [test-ctl.R](testthat/test-ctl.R#L251)                   | Parsing CTL Elements                           | remove comment lines in ctl: find comment line from omega                                        | PASS   | 1 | 0.001 |
| [test-ctl.R](testthat/test-ctl.R#L255)                   | Parsing CTL Elements                           | remove comment lines in ctl: remove comment line from omega                                      | PASS   | 1 | 0.002 |
| [test-nmlist.R](testthat/test-nmlist.R#L18)              | nmlist functions                               | read\_nmlist                                                                                     | PASS   | 2 | 0.004 |
| [test-nmlist.R](testthat/test-nmlist.R#L34)              | nmlist functions                               | parse nmlist for mrgsolve: parent                                                                | PASS   | 3 | 0.008 |
| [test-nmlist.R](testthat/test-nmlist.R#L40)              | nmlist functions                               | parse nmlist for mrgsolve: theta                                                                 | PASS   | 2 | 0.010 |
| [test-nmlist.R](testthat/test-nmlist.R#L45)              | nmlist functions                               | parse nmlist for mrgsolve: matrix                                                                | PASS   | 1 | 0.002 |
| [test-nmlist.R](testthat/test-nmlist.R#L56)              | nmlist functions                               | parse nmlist for subset of fields: parent                                                        | PASS   | 3 | 0.005 |
| [test-nmlist.R](testthat/test-nmlist.R#L62)              | nmlist functions                               | parse nmlist for subset of fields: children                                                      | PASS   | 3 | 0.004 |
| [test-nmlist.R](testthat/test-nmlist.R#L75)              | nmlist functions                               | parse nmlist with attributes: theta                                                              | PASS   | 1 | 0.001 |
| [test-nmlist.R](testthat/test-nmlist.R#L79)              | nmlist functions                               | parse nmlist with attributes: cov                                                                | PASS   | 2 | 0.002 |
| [test-nmlist.R](testthat/test-nmlist.R#L84)              | nmlist functions                               | parse nmlist with attributes: cor                                                                | PASS   | 2 | 0.002 |
| [test-nmlist.R](testthat/test-nmlist.R#L95)              | nmlist functions                               | parse nmlist with all estimations in run                                                         | PASS   | 1 | 0.180 |
| [test-nmlist.R](testthat/test-nmlist.R#L104)             | nmlist functions                               | parse nmlist with subset of estimations in run                                                   | PASS   | 1 | 0.181 |
| [test-nmlist.R](testthat/test-nmlist.R#L115)             | nmlog functions                                | create nmlog output: names                                                                       | PASS   | 1 | 0.002 |
| [test-nmlist.R](testthat/test-nmlist.R#L119)             | nmlog functions                                | create nmlog output: length                                                                      | PASS   | 1 | 0.002 |
| [test-nmlist.R](testthat/test-nmlist.R#L123)             | nmlog functions                                | create nmlog output: class                                                                       | PASS   | 1 | 0.002 |
| [test-nmlist.R](testthat/test-nmlist.R#L188)             | nmlog functions                                | verify values of xml to output files: theta                                                      | PASS   | 1 | 0.002 |
| [test-nmlist.R](testthat/test-nmlist.R#L192)             | nmlog functions                                | verify values of xml to output files: thetase                                                    | PASS   | 1 | 0.003 |
| [test-nmlist.R](testthat/test-nmlist.R#L196)             | nmlog functions                                | verify values of xml to output files: omega                                                      | PASS   | 1 | 0.001 |
| [test-nmlist.R](testthat/test-nmlist.R#L200)             | nmlog functions                                | verify values of xml to output files: omegase                                                    | PASS   | 1 | 0.001 |
| [test-nmlist.R](testthat/test-nmlist.R#L204)             | nmlog functions                                | verify values of xml to output files: sigma                                                      | PASS   | 1 | 0.002 |
| [test-nmlist.R](testthat/test-nmlist.R#L208)             | nmlog functions                                | verify values of xml to output files: sigmase                                                    | PASS   | 1 | 0.002 |
| [test-nmlist.R](testthat/test-nmlist.R#L212)             | nmlog functions                                | verify values of xml to output files: final objective value                                      | PASS   | 1 | 0.002 |
| [test-nmlist.R](testthat/test-nmlist.R#L216)             | nmlog functions                                | verify values of xml to output files: covariance                                                 | PASS   | 1 | 0.001 |
| [test-nmlist.R](testthat/test-nmlist.R#L220)             | nmlog functions                                | verify values of xml to output files: correlation                                                | PASS   | 1 | 0.002 |
| [test-nmlist.R](testthat/test-nmlist.R#L235)             | nmlog functions                                | mixture models: multiple subpopulations in etabar dim                                            | PASS   | 1 | 0.001 |
| [test-nmlist.R](testthat/test-nmlist.R#L239)             | nmlog functions                                | mixture models: multiple subpopulations in etabar rownames                                       | PASS   | 1 | 0.002 |
| [test-nmlist.R](testthat/test-nmlist.R#L243)             | nmlog functions                                | mixture models: multiple subpopulations in etabar colnames                                       | PASS   | 1 | 0.001 |
| [test-param\_tbl.R](testthat/test-param_tbl.R#L28)       | verify parameter table values                  | Test against 510.xml, no FIXED or SAME: Benchmark test to saved object                           | PASS   | 1 | 0.003 |
| [test-param\_tbl.R](testthat/test-param_tbl.R#L36)       | verify parameter table values                  | Test against 510\_fixed.xml, many variations of FIX, FIXED, SAME: Benchmark test to saved object | PASS   | 1 | 0.003 |
| [test-param\_tbl.R](testthat/test-param_tbl.R#L44)       | verify parameter table values                  | Test against 101.xml, BLOCK(3): Benchmark test to saved object                                   | PASS   | 1 | 0.002 |
| [test-read\_exts.R](testthat/test-read_exts.R#L13)       | read additional extensions                     | all extensions all estimations: dimension                                                        | PASS   | 1 | 0.001 |
| [test-read\_exts.R](testthat/test-read_exts.R#L17_L18)   | read additional extensions                     | all extensions all estimations: object class                                                     | PASS   | 1 | 0.001 |
| [test-read\_exts.R](testthat/test-read_exts.R#L22_L24)   | read additional extensions                     | all extensions all estimations: column class                                                     | PASS   | 1 | 0.001 |
| [test-read\_exts.R](testthat/test-read_exts.R#L28_L32)   | read additional extensions                     | all extensions all estimations: column element class                                             | PASS   | 1 | 0.002 |
| [test-read\_exts.R](testthat/test-read_exts.R#L36_L39)   | read additional extensions                     | all extensions all estimations: non null element                                                 | PASS   | 1 | 0.001 |
| [test-read\_exts.R](testthat/test-read_exts.R#L49)       | read additional extensions                     | all extensions all estimations: dimension                                                        | PASS   | 1 | 0.001 |
| [test-read\_exts.R](testthat/test-read_exts.R#L53_L56)   | read additional extensions                     | all extensions all estimations: non null element                                                 | PASS   | 1 | 0.002 |
| [test-read\_exts.R](testthat/test-read_exts.R#L66)       | read additional extensions                     | subset of extensions last estimation: dimension                                                  | PASS   | 1 | 0.002 |
| [test-read\_exts.R](testthat/test-read_exts.R#L70)       | read additional extensions                     | subset of extensions last estimation: column names                                               | PASS   | 1 | 0.001 |
| [test-read\_exts.R](testthat/test-read_exts.R#L80)       | read additional extensions                     | subset of extensions all estimations: dimension                                                  | PASS   | 1 | 0.001 |
| [test-read\_exts.R](testthat/test-read_exts.R#L84)       | read additional extensions                     | subset of extensions all estimations: column names                                               | PASS   | 1 | 0.002 |
| [test-read\_exts.R](testthat/test-read_exts.R#L96)       | read additional extensions                     | user defined estimation filter: dimension                                                        | PASS   | 1 | 0.002 |
| [test-read\_exts.R](testthat/test-read_exts.R#L100)      | read additional extensions                     | user defined estimation filter: column names                                                     | PASS   | 1 | 0.002 |
| [test-read\_exts.R](testthat/test-read_exts.R#L110)      | read additional extensions                     | bad extension: ask for xml                                                                       | PASS   | 1 | 0.002 |
| [test-read\_exts.R](testthat/test-read_exts.R#L131)      | read additional extensions                     | different root name: dimension                                                                   | PASS   | 1 | 0.002 |
| [test-read\_exts.R](testthat/test-read_exts.R#L135_L136) | read additional extensions                     | different root name: object class                                                                | PASS   | 1 | 0.001 |
| [test-superset.R](testthat/test-superset.R#L19)          | merge estimation output tables with input data | df to tbl\_df: nibble reads in a tibble                                                          | PASS   | 1 | 0.001 |
| [test-superset.R](testthat/test-superset.R#L27)          | merge estimation output tables with input data | df to tbl\_df: join returns a tibble                                                             | PASS   | 1 | 0.001 |
| [test-superset.R](testthat/test-superset.R#L31)          | merge estimation output tables with input data | df to tbl\_df: number of intersecting names joined                                               | PASS   | 1 | 0.002 |
| [test-superset.R](testthat/test-superset.R#L43)          | merge estimation output tables with input data | list to tbl\_df: join returns a tibble                                                           | PASS   | 1 | 0.001 |
| [test-superset.R](testthat/test-superset.R#L47)          | merge estimation output tables with input data | list to tbl\_df: number of intersecting names joined                                             | PASS   | 1 | 0.006 |
| [test-superset.R](testthat/test-superset.R#L61)          | merge estimation output tables with input data | tbl\_df to tbl\_df: join returns a tibble                                                        | PASS   | 1 | 0.001 |
| [test-superset.R](testthat/test-superset.R#L65)          | merge estimation output tables with input data | tbl\_df to tbl\_df: number of intersecting names joined                                          | PASS   | 1 | 0.001 |
| [test-superset.R](testthat/test-superset.R#L77)          | merge estimation output tables with input data | nibble to tbl\_df: join returns a tibble                                                         | PASS   | 1 | 0.002 |
| [test-superset.R](testthat/test-superset.R#L81)          | merge estimation output tables with input data | nibble to tbl\_df: number of intersecting names joined                                           | PASS   | 1 | 0.002 |
| [test-superset.R](testthat/test-superset.R#L91)          | merge estimation output tables with input data | nibble to tbl\_df: join returns a tibble                                                         | PASS   | 1 | 0.002 |
| [test-superset.R](testthat/test-superset.R#L95)          | merge estimation output tables with input data | nibble to tbl\_df: number of intersecting names joined                                           | PASS   | 1 | 0.001 |
| [test-values.R](testthat/test-values.R#L70)              | verify xml values                              | verify values of xml to output files: theta                                                      | PASS   | 1 | 0.002 |
| [test-values.R](testthat/test-values.R#L74)              | verify xml values                              | verify values of xml to output files: thetase                                                    | PASS   | 1 | 0.002 |
| [test-values.R](testthat/test-values.R#L78)              | verify xml values                              | verify values of xml to output files: omega                                                      | PASS   | 1 | 0.002 |
| [test-values.R](testthat/test-values.R#L82)              | verify xml values                              | verify values of xml to output files: omegase                                                    | PASS   | 1 | 0.002 |
| [test-values.R](testthat/test-values.R#L86)              | verify xml values                              | verify values of xml to output files: sigma                                                      | PASS   | 1 | 0.002 |
| [test-values.R](testthat/test-values.R#L90)              | verify xml values                              | verify values of xml to output files: sigmase                                                    | PASS   | 1 | 0.001 |
| [test-values.R](testthat/test-values.R#L94)              | verify xml values                              | verify values of xml to output files: final objective value                                      | PASS   | 1 | 0.002 |
| [test-values.R](testthat/test-values.R#L98)              | verify xml values                              | verify values of xml to output files: covariance                                                 | PASS   | 1 | 0.002 |
| [test-values.R](testthat/test-values.R#L102)             | verify xml values                              | verify values of xml to output files: correlation                                                | PASS   | 1 | 0.001 |
| [test-verbs.R](testthat/test-verbs.R#L20)                | Nibble Verbs                                   | burrow noregex: name                                                                             | PASS   | 1 | 0.002 |
| [test-verbs.R](testthat/test-verbs.R#L24)                | Nibble Verbs                                   | burrow noregex: name and index                                                                   | PASS   | 1 | 0.002 |
| [test-verbs.R](testthat/test-verbs.R#L28)                | Nibble Verbs                                   | burrow noregex: index                                                                            | PASS   | 1 | 0.003 |
| [test-verbs.R](testthat/test-verbs.R#L32_L35)            | Nibble Verbs                                   | burrow noregex: remove empty list parents                                                        | PASS   | 1 | 0.002 |
| [test-verbs.R](testthat/test-verbs.R#L43_L46)            | Nibble Verbs                                   | burrow regex: open grep                                                                          | PASS   | 1 | 0.004 |
| [test-verbs.R](testthat/test-verbs.R#L50_L53)            | Nibble Verbs                                   | burrow regex: use $                                                                              | PASS   | 1 | 0.003 |
| [test-verbs.R](testthat/test-verbs.R#L57_L60)            | Nibble Verbs                                   | burrow regex: use ^                                                                              | PASS   | 1 | 0.004 |
| [test-verbs.R](testthat/test-verbs.R#L70)                | Nibble Verbs                                   | purge single predicate: NULL                                                                     | PASS   | 1 | 0.002 |
| [test-verbs.R](testthat/test-verbs.R#L81)                | Nibble Verbs                                   | purge function predicate: NULL and NA                                                            | PASS   | 2 | 0.003 |
| [test-verbs.R](testthat/test-verbs.R#L94)                | Nibble Verbs                                   | purge nonlist input: data.frame                                                                  | PASS   | 2 | 0.003 |
| [test-verbs.R](testthat/test-verbs.R#L101)               | Nibble Verbs                                   | purge nonlist input: numeric                                                                     | PASS   | 2 | 0.003 |
| [test-verbs.R](testthat/test-verbs.R#L125)               | Nibble Verbs                                   | pluck elements: single column named                                                              | PASS   | 1 | 0.001 |
| [test-verbs.R](testthat/test-verbs.R#L129_L130)          | Nibble Verbs                                   | pluck elements: single column correct name                                                       | PASS   | 1 | 0.002 |
| [test-verbs.R](testthat/test-verbs.R#L134)               | Nibble Verbs                                   | pluck elements: multiple columns named                                                           | PASS   | 1 | 0.001 |
| [test-verbs.R](testthat/test-verbs.R#L138_L141)          | Nibble Verbs                                   | pluck elements: multiple columns correct names                                                   | PASS   | 1 | 0.002 |
| [test-verbs.R](testthat/test-verbs.R#L145_L148)          | Nibble Verbs                                   | pluck elements: bad input                                                                        | PASS   | 1 | 0.180 |
| [test-verbs.R](testthat/test-verbs.R#L152_L156)          | Nibble Verbs                                   | pluck elements: no names                                                                         | PASS   | 1 | 0.002 |
| [test-verbs.R](testthat/test-verbs.R#L170)               | Nibble Verbs                                   | flatten\_auto lists: numeric                                                                     | PASS   | 1 | 0.002 |
| [test-verbs.R](testthat/test-verbs.R#L174)               | Nibble Verbs                                   | flatten\_auto lists: character                                                                   | PASS   | 1 | 0.002 |
| [test-verbs.R](testthat/test-verbs.R#L178)               | Nibble Verbs                                   | flatten\_auto lists: logical                                                                     | PASS   | 1 | 0.001 |
| [test-verbs.R](testthat/test-verbs.R#L182)               | Nibble Verbs                                   | flatten\_auto lists: list                                                                        | PASS   | 1 | 0.001 |

</details>

<details>

<summary> Session Info </summary>

| Field    | Value                               |
| :------- | :---------------------------------- |
| Version  | R version 3.4.1 (2017-06-30)        |
| Platform | x86\_64-apple-darwin15.6.0 (64-bit) |
| Running  | macOS Sierra 10.12.6                |
| Language | en\_US                              |
| Timezone | America/New\_York                   |

| Package  | Version |
| :------- | :------ |
| testthat | 2.0.1   |
| covr     | 3.2.1   |
| covrpage | 0.0.67  |

</details>

<!--- Final Status : pass --->
