[![Build Status](https://travis.metrumrg.com/software/tidynm.svg?token=tfrDuc83e84K9CqJKyCs&branch=master)](https://travis.metrumrg.com/software/tidynm)
[![Covrpage Summary](https://img.shields.io/badge/covrpage-Last_Build_2018_11_30-brightgreen.svg)](https://ghe.metrumrg.com/software/tidynm/blob/master/tests/README.md)

tidynm
======

NONMEM + Tidyverse


## Installation

```r

repos <- c("https://metrumresearchgroup.github.io/r_validated", options()$repos)

install.packages("tidynm", repos = unique(repos), type = "source", destdir = NULL)

```

### Release Candidate

```r
repos <- c("https://metrumresearchgroup.github.io/rpkgs/rc", options()$repos)

install.packages("tidynm", repos = unique(repos), type = "source", destdir = "pkg")
```

### Development

```r
remotes::install_github('software/tidynm',host = 'ghe.metrumrg.com/api/v3',auth_token = Sys.getenv('GHE_PAT'))
```

## News

News can be found [here](https://ghe.metrumrg.com/pages/software/tidynm/news/index.html)

## Current Issues

  - [Bugs](http://tinyurl.com/ybykw25k)
  - [Current Milestone for next Change Request](http://tinyurl.com/y9sww4ku)

## Vignettes

  - [Basic Usage](https://ghe.metrumrg.com/pages/software/tidynm/articles/usage.html)

  - [{tidynm} verbs](https://ghe.metrumrg.com/pages/software/tidynm/articles/verbs.html)

  - [Integration with other metrum packages](https://ghe.metrumrg.com/pages/software/tidynm/articles/integration.html)
  
  
## Training

Training video for initial release can be found [here](http://metrumrg-video.s3.amazonaws.com/training/2018-08-15%2012.02%20Lab%20Meeting.mp4)
