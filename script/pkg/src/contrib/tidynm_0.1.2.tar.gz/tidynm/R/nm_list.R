parse_cov_status <- function(x){
  lapply(attributes(x[[1]]),as.numeric)
}

strp_pars <- function(lab){
  gsub('\\(|\\)','',gsub('\\,','\\.',lab))
}

add_attr <- function(x,y){
  
  this_name <- unique(names(x))
  
  if(is.null(this_name)||this_name=='obj')
    return(y)
  
  which_name <- ifelse(this_name=='val','name','rname')
  
  this_class <- class(y)
  
  labs <- strp_pars(sapply(x,attr,which=which_name))
  
  if(this_class=='numeric'){
    y <- matrix(y,ncol=1)
    
    rownames(y) <- labs
  }
  
  if(this_class=='matrix')
    rownames(y) <- colnames(y) <- labs
  
  y
}

is_subpop <- function(x){
  all(grepl('^SUBPOP',sapply(x,attr,'rname',simplify = TRUE)))
}

extract_eta <- function(x,attach_attr){
  
  data <- unlist(x,use.names=FALSE) %>% as.numeric
  clbl <- sapply(x[[1]],attr,'cname',simplify = TRUE)
  rlbl <- sapply(x,attr,'rname',simplify = TRUE)
  
  m  <- matrix(data,nrow=length(x),byrow=TRUE)
  
  if(attach_attr){
    dimnames(m) <- list(rlbl,clbl)
  }
  
  m
}

extract_cov <- function(x,attach_attr){
  
  ncol <- nrow <- length(x)
  
  m <- matrix(0, nrow = nrow, ncol = ncol)
  
  for(row in seq_along(x)) {
    for(col in seq_along(x[[row]])) {
      value <- as.numeric(x[[row]][[col]])
      m[row,col] <- value
      m[col,row] <- value
    }
  }
  
  if(attach_attr){
    m <- add_attr(x,m)
  }
  
  m
}

extract_matrix <- function(x,attach_attr) {
  
  f <- extract_cov
  
  if( is_subpop(x) ){
    f <- extract_eta
  }
  
  f(x,attach_attr)
}

extract_vector <- function(x,attach_attr) {
  
  v <- as.numeric(unlist(x, use.names=FALSE))
  
  if(attach_attr){
    v <- add_attr(x,v)
  }
  
  v
}

extract_theta <- function(x,attach_attr) {
  if(is.null(x)) return(list())
  labels <- sapply(x, attr, which = "name")
  values <- as.numeric(unlist(x, use.names=FALSE))
  
  if(attach_attr){
    values <- add_attr(x,values)
  }else{
    names(values) <- paste0("THETA",labels)
  }
  
  values
}

#' @importFrom purrr set_names
extract_shrink <- function(x) {
  if(is.null(x)) return(list())
  x <- x$row
  out <- vector("numeric", length(x))
  name <- vector("character", length(x))
  for(i in seq_along(x)) {
    out[i] <- as.numeric(x[[i]])
    name[i] <- attr(x[[i]], which = "cname")
  }
  purrr::set_names(out,name)
}


#' @title Parse NONMEM XML output
#' @description Parse NONMEM run results from read_nmlist
#' @param nmdat raw nmlist object
#' @param fields character, fields to return, Default: 'mrgsolve'
#' @param index which estimation to extract, can be 'all','last', or a sequence
#'  Default: 'last'
#' @param attach_attr add nonmem column/row attributes, Default: FALSE
#' @return list
#' @details
#' \itemize{
#'   \item status: misc run information
#'   \item theta: list of theta values
#'   \item omega: omega matrix
#'   \item sigma: sigma matrix
#'   \item par: theta estimates with standard errors
#'   \item etashk: eta shrinkage values (percent)
#'   \item epsshk: epsilon shrinkage values (percent)
#'   \item etabar: mean eta
#'   \item etabarp: etabar p-value
#' }
#' @examples
#' run <- 510
#' project <- system.file("extdata", package="tidynm")
#' x <- read_nmlist(run, project)%>%
#' parse_nmlist()
#' 
#' names(x)
#'
#' x$theta
#'
#' x$omega
#'
#' x$cov
#'
#' @rdname parse_nmlist
#' @export
#' @importFrom xml2 xml_find_all xml_text as_list
#' @importFrom purrr set_names
parse_nmlist <- function(nmdat, fields='mrgsolve',index='last',attach_attr=FALSE) {
  
  # dt <- nmdat%>%
  #   xml2::xml_find_all('.//nm:stop_datetime')%>%
  #   xml2::xml_text()
  
  prob <- nmdat%>%
    xml2::xml_find_all('.//nm:problem_information')%>%
    xml2::xml_text()
  
  prob  <- strsplit(prob, "\n")[[1]]
  
  recs  <- grep("TOT. NO. OF", prob)
  drecs <- grep("NO. OF DATA RECS", prob)
  
  recs  <- prob[c(recs,drecs)]
  recs  <- strsplit(recs, ":", fixed = TRUE)
  recs  <- as.list(as.numeric(sapply(recs,'[',2)))%>%
    purrr::set_names(nm=c('OBS_RECS','INDIVIDUALS','DATA_RECS'))
  
  nm_version <- nmdat%>%
    xml2::xml_child(search = 'nm:nonmem')%>%
    xml2::xml_attr('version')
  
  nmdat_list <- nmdat%>%
    xml2::xml_find_all('.//nm:estimation')%>%
    xml2::as_list()
  
  xl <- lapply(nmdat_list,function(this_nmdat){
    
    out <- sapply(names(this_nmdat),function(nmx,attach_attr){
      
      y <- this_nmdat[[nmx]]
      nm <- names(y)[1]
      
      if(is.null(nm)) return(unlist(y))
      
      out <- switch(nm,
                    row = {
                      if(length(y)==1){
                        extract_shrink(y)
                      }else{
                        extract_matrix(y,attach_attr=attach_attr)
                      }
                    },
                    {
                      if(grepl('^theta',nmx)){
                        extract_theta(y,attach_attr=attach_attr)
                      }else{
                        extract_vector(y,attach_attr=attach_attr)
                      }
                    })
      out
      
    },attach_attr=attach_attr,simplify = FALSE)
    
    names(recs) <- tolower(names(recs))
    
    out <- append(out,recs)
    
    out <- append(list(nm_version = nm_version),out)
    
    out <- out%>%nm_version_mapping()
    
    out <- out%>%tweak_table_series()
    
    out
    
  })
  
  if(all(fields=='all')){
    
    xl_out <- xl
    
  }
  
  if(all(fields=='mrgsolve')){
    
    xl_out <- lapply(xl,function(this){
      
      fov <- as.numeric(this$final_objective_function)
      term <- as.integer(this$termination_status)
      
      th <- this$theta
      thse <- this$thetase
      par <- data.frame(THETA = as.numeric(th))
      se <- as.numeric(thse)
      
      if(length(se)==nrow(par)){
        par$SE <- se
      }
      
      if(!is.null(this$covariance)){
        if(nrow(this$covariance) > 0) {
          sth <- seq_along(this$theta)
          covar <- this$covariance[sth,sth]
          corr <- this$correlation[sth,sth]
        }
      }else{
        covar <- matrix(0,0,0)
        corr <- matrix(0,0,0)
      }
      
      om <- this$omega
      #omc <- this$omegac
      
      sg <- this$sigma
      #sgc <- this$sigmac
      
      
      
      etash <- this$etashrink
      epssh <- this$epsshrink
      etab  <- this$etabar
      etabp <- this$etabarpval
      eigen <- this$eigenvalues
      eigen <- as.numeric(unname(eigen))
      
      cond_number <- NA
      if(length(eigen) > 0) {
        cond_number <- max(eigen)/min(eigen)
      }
      
      this_nmdat <- list(
        theta     = th, 
        omega     = om, 
        sigma     = sg,
        par       = par,
        etashk    = etash, 
        epsshk    = epssh,
        etabar    = etab, 
        etabarp   = etabp,
        eigen     = eigen, 
        condition = cond_number,
        cov       = covar, 
        cor       = corr,
        fov       = fov,
        term      = term
      )
      
      return(this_nmdat)
      
    })
    
  }
  
  
  if(all(!fields%in%c('all','mrgsolve'))){
    
    xl_out <- lapply(xl,function(this_xl) this_xl[fields])
    
  }
  
  if(length(index)==1){
    if(index=='all'){
      index <- seq_along(xl_out)
    }else{
      if(index=='last') index <- length(xl_out)
    }
  }
  
  xl_out <- xl_out[index]
  
  
  if(length(index)==1){
    xl_out <- unlist(xl_out,recursive = FALSE)
  }
  
  return(xl_out)
  
}

tweak_table_series <- function(obj){
  idx <- which(names(obj)%in%'table_series')
  if(length(idx)>0){
    names(obj)[idx] <- 'estimation_index'
  }
  
  obj
}


#' @title Import Utility for NONMEM xml files
#' @description Converts xml files to xml_document class
#' @param run character, run number(s) to parse
#' @param project character, root path of the NONMEM run(s)
#' @param rundir character, path containing the project, Default: file.path(project, run)
#' @return xml_document class
#' @examples 
#' read_nmlist(run = c('510'), project = system.file('extdata',package = 'tidynm'))
#' @seealso 
#'  \code{\link[xml2]{read_xml}}
#' @rdname read_nmlist
#' @export 
#' @importFrom xml2 read_xml
read_nmlist <- function(run, project, rundir = file.path(project,run)) {
  xmlfile <- file.path(rundir, paste0(run, ".xml"))
  xml2::read_xml(xmlfile)
}
