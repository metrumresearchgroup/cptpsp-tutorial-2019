#' @title Parse CTL blocks into matrices
#' @description Convert CTL blocks into matrices or matrices fo comments
#' @param x clean_ctl object
#' @param type character, extract numeric of comment from x, Default: c("numeric", "comment")
#' @return matrix or list containing matrices
#' @details expected format for comment in CTL is "VALUE [FIXED,SAME] ;  [COVTYPE] LABEL"
#' @examples 
#' \dontrun{
#' project <- system.file('extdata',package = 'tidynm')
#' 
#' run <- '101'
#' 
#' xml_raw   <- read_nmlist(run, project)
#' 
#' x   <- xml_raw%>%
#'   xml2::xml_find_first('.//nm:control_stream')%>%
#'   xml2::xml_text()%>%
#'   tidynm:::clean_ctl()
#' 
#' ctl_to_mat(x$OMEGA)
#' ctl_to_mat(x$OMEGA,type='comment')
#' }
#' @export
#' @importFrom purrr map2
#' @importFrom stringi stri_split_fixed
#' @rdname ctl_to_mat
ctl_to_mat <- function(x,type=c('numeric','comment')){
  
  if(inherits(x,'character'))
    x <- list(x)

    y <- iov_locf(x)

  out <- purrr::map(y,function(.y){
    
    type <- match.arg(type,c('numeric','comment'))
    
    if(grepl('BLOCK',.y[1])){

      ret <- parse_mat_block(.y, type)      
      
    }else{
      
      ret <- parse_mat_noblock(.y, type)
      
    }
    return(ret)
  })
  
  # flatten if length of 1
  
  if(length(out)==1) out <- out[[1]]
  
  out
}

parse_mat_block <- function(x,type){
  
  dimn <- gsub('^(.*?)\\(|\\)(.*?)$','',x[1])%>%
    as.numeric()
  
  x[1] <- gsub('^(.*?)\\s+','',x[1])  
  
  mat  <- diag(dimn)
  
  x_num <- parse_mat_numeric(x)
  x_str <- parse_mat_comment(x)
  
  if(type=='numeric'){
    
    mat[upper.tri(mat,diag = TRUE)] <- x_num
    
  }
  
  if(type=='comment'){
    
    if(length(x_str)==dimn[1]){
      
      diag(mat) <- x_str
      
    }else{
      
      mat[upper.tri(mat,diag = TRUE)] <- x_str  
      
    }
    
    mat[mat=='0'] <- ''
    
  }
  
  #reset to lower triangle indexation
  mat <- t(mat)
  
  mat
  
}

parse_mat_noblock <- function(x,type){
  
  x_num <- parse_mat_numeric(x)
  x_str <- parse_mat_comment(x)
  
  if(type=='numeric'){
    
    if(length(x_num)>1){
      
      mat <- diag(x_num)
      
    }else{
      
      mat <- matrix(x_num,nrow = 1,ncol = 1)
      
    }
    
  }
  
  if(type=='comment'){
    
    mat <- diag(length(x_num))
    diag(mat) <- x_str
    mat[mat=='0'] <- ''
    
  }
  
  mat
}


#' @importFrom stringi stri_count_regex
parse_mat_comment <- function(x){
  
  x_fixed <- grepl('FIX|SAME',gsub(';(.*?)$|\\(|\\)','',x))
  
  x[!grepl('\\;',x)] <- sprintf('%s;',x[!grepl('\\;',x)])
  
  x_str <- gsub('^\\s+|\\s+$','',gsub('^(.*?);','',x))
 
  x_str <- sapply(x_str,function(x){
  
    x_fixed_i <- grepl('FIX|SAME',gsub(';(.*?)$|\\(|\\)','',x))
    
    if(!nzchar(x)){
      if(x_fixed_i){
        x <- ' '
      }else{
        x <- '  '  
      }
      
    }else{
      if(!grepl('\\s',x)){
        if(grepl('\\[|\\]',x)){
          x <- sprintf('%s ',x)
        }else{
          x <- sprintf(' %s',x)
        }
      }  
    }
      
    x
    
  },
  USE.NAMES = FALSE,
  simplify = TRUE) 

  x_str <- sprintf('%s %s',c('NOFIXED','FIXED')[as.numeric(x_fixed)+1],x_str)
  x_str <- gsub('\\s','||',x_str)
  x_str <- gsub('NOFIXED','',x_str)
  
  one_col <- stringi::stri_count_regex(x_str,'||')==1
  x_str[one_col] <- sprintf('||%s',x_str[one_col])
  
  sort_comment(x_str)
  
}

parse_mat_numeric <- function(x){
  
  x_num   <- gsub(';(.*?)$|\\(|\\)','',x)
  
  x_num   <- gsub("FIXED|FIX|SAME",'',x_num)
  x_num   <- gsub('^\\s+|\\s+$','',x_num)

  x_num   <- strsplit(x_num,'\\s+')%>%
    unlist()%>%
    as.numeric()
  
  x_num
}

#' @importFrom dplyr mutate group_by ungroup pull tibble
#' @importFrom purrr map_dbl
#' @importFrom rlang .data
iov_locf <- function(x){
  dplyr::tibble(
    raw=x) %>%
    dplyr::mutate(
      SAME = purrr::map_dbl(.data[['raw']],.f=function(x) {
        as.numeric(!any(grepl('\\bSAME\\b',x)))
      })%>%
        cumsum()
    )%>%
    dplyr::group_by(.data[['SAME']]) %>%
    dplyr::mutate(new = list(dplyr::nth(.data[['raw']], 1)),
                  id=1:n()) %>%
    dplyr::mutate(new = dplyr::if_else(id>1,purrr::map(.data[['new']],.f=function(x){
      purrr::map_chr(x,.f=function(x){ 
        
        if(!grepl('FIX',x)){
          if(!grepl('[;]',x)){
            x <- sprintf('%s ;',x)
          }
          x <- gsub(';','FIXED ;',x) 
        }
        
        x
      })
      
      }),.data[['new']]))%>%
    dplyr::ungroup()%>%
    dplyr::pull(.data[['new']])
}