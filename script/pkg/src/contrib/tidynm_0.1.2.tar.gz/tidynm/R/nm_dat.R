#' @title Import data from paths stored in nibble
#' @description Import csv file used in NONMEM run from information within a nibble object
#' @param project character, project path
#' @param run character, run number
#' @param data character, data file name
#' @param add_index_col boolean, add an index column to faciliatate merging to tab output files, Default: FALSE
#' @param \dots arguments to pass to \code{\link[data.table]{fread}}
#' @return data_frame
#' @details csv file extension is assumed
#' @examples 
#' nbl <- tidynm::nibble(project = system.file('extdata',package = 'tidynm'),run = c('510'))
#' 
#' nbl%>%
#' dplyr::mutate(new_dat = purrr::pmap(list(project,run,DATA),nm_dat))%>%
#' purrr::pluck('new_dat')
#' 
#' @seealso 
#'  \code{\link[data.table]{fread}}
#' @rdname nm_dat
#' @export 
#' @import dplyr
#' @importFrom data.table fread
nm_dat <- function(project,run,data,add_index_col = FALSE, ...){
  
  if(inherits(data,'list')) data <- unlist(data)[1]
  
  out <- data.table::fread(
    file = file.path(project,run,data),
    check.names = TRUE,
    header = TRUE,
    data.table = FALSE, ...)%>%
    dplyr::as_tibble()

  if(add_index_col & !'index__'%in%names(out))
    out$index__ <- 1:nrow(out)
  
  out
}
