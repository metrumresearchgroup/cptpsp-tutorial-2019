#' @title Create estimation parameter table
#' @description Create a parameter table from NONMEM outputs
#' @param ... arguments to pass in
#' @param params_in character, arguments to set to null if missing from ...
#' @return nibble_param object
#' @details The return object will parse the XML file to get the following variables to return to the nibble in tabular format:
#'
#' * PARAM: Theta, Omega, or Sigma
#' * FIXED: Was this parameter fixed in estimation?
#' * LABEL, UNIT, TYPE: Parsed from the control stream (or more specifically, the copy of the control stream held in the XML file).  For variance components TYPE will always default to \code{[R]}, i.e., just report the correlation matrix by default.
#' * Var1 and Var2: Used for parameter math labeling, will correspond to \code{THETA[Var1]}, \code{OMEGA[Var1,Var2]}, and \code{SIGMA[Var1,Var2]}
#' * value: Parameter estimate, corresponding to the fixed effect for THETA and variance for random effect parameters
#' * c: Standard deviation (\code{Var1==Var2}) or correlation estimate for random effects
#' * se: Asymptotic standard error of \code{value}
#' * cse: Aysmptotic standard error of \code{c}
#' @rdname param_tbl
#' @export 
#' @import dplyr
#' @importFrom tidyr separate
#' @importFrom rlang .data !! sym
param_tbl <- function(..., 
                     params_in = c( 'theta',
                                    'sigma',
                                    'sigmac',
                                    'omega',
                                    'omegac',
                                    'thetase',
                                    'omegase',
                                    'sigmase',
                                    'omegacse',
                                    'sigmacse',
                                    'THETA',
                                    'SIGMA_COMMENT',
                                    'OMEGA_COMMENT')
                     ){

  
  
  theta         <- NULL
  sigma         <- NULL
  sigmac        <- NULL
  omega         <- NULL
  omegac        <- NULL
  thetase       <- NULL
  omegase       <- NULL
  sigmase       <- NULL
  omegacse      <- NULL
  sigmacse      <- NULL
  THETA         <- NULL
  SIGMA_COMMENT <- NULL
  OMEGA_COMMENT <- NULL
  
  l <- list(...)
  list2env(l[[1]],envir = environment())
  
  params_internal <- lapply(c('join','lbl'),function(x){
    sprintf('%s_%s',c('theta','omega','sigma'),x) 
  })%>%unlist()

  for(p in c(params_in,params_internal)){
    if(!exists(p)){
      assign(x = p,value = NULL,envir = environment())
    }
  }

  if(!is.null(theta)){
    
    theta_join <- theta%>%
      as.matrix()%>%
      gather()
    
    if(!is.null(thetase)){
      thetase_est <- thetase%>%
        as.matrix()%>%
        gather()%>%
        dplyr::rename(se=.data[['value']])
      
      theta_join <- theta_join%>%
        dplyr::left_join(thetase_est, by = c("Var1", "Var2"))
    }
    
    theta_join <- theta_join%>%
      dplyr::mutate_at(dplyr::vars(.data[['Var1']],.data[['Var2']]),
                       dplyr::funs(as.integer))%>%
      dplyr::mutate(PARAM='THETA')
    
    theta_lbl <- THETA%>%
      dplyr::mutate(PARAM='THETA')%>%
      dplyr::select(.data[['Var1']],
                    .data[['Var2']],
                    .data[['FIXED']],
                    .data[['LABEL']],
                    .data[['PARAM']],
                    .data[['UNIT']])
    
  }
  
  if(!is.null(omega)){
    
    omega_est <- omega%>%
      as.matrix()%>%
      gather()%>%
      dplyr::mutate_at(dplyr::vars(.data[['Var1']],.data[['Var2']]),
                       dplyr::funs(as.integer))
    
    omegac_est <- omegac%>%
      as.matrix()%>%
      gather()%>%
      dplyr::rename(c=.data[['value']])%>%
      dplyr::mutate_at(dplyr::vars(.data[['Var1']],.data[['Var2']]),
                       dplyr::funs(as.integer))
    
    omega_join  <- omega_est%>%
      dplyr::left_join(omegac_est, by = c("Var1", "Var2"))
    
    if(!is.null(omegase)){
      
      omegase_est <- omegase%>%
        as.matrix()%>%
        gather()%>%
        dplyr::rename(se=.data[['value']])%>%
        dplyr::mutate_at(dplyr::vars(.data[['Var1']],.data[['Var2']]),
                         dplyr::funs(as.integer))
      
      omegacse_est <- omegacse%>%
        as.matrix()%>%
        gather()%>%
        dplyr::rename(cse=.data[['value']])%>%
        dplyr::mutate_at(dplyr::vars(.data[['Var1']],.data[['Var2']]),
                         dplyr::funs(as.integer))
      
      omega_join  <- omega_join%>%
        dplyr::left_join(omegase_est, by = c("Var1", "Var2"))%>%
        dplyr::left_join(omegacse_est, by = c("Var1", "Var2"))
    }
    
    omega_join <- omega_join%>%
      dplyr::mutate_at(dplyr::vars(.data[['Var1']],.data[['Var2']]),
                       dplyr::funs(as.integer))%>%
      dplyr::mutate(PARAM='OMEGA')
    
    omega_lbl <- OMEGA_COMMENT%>%
      gather()%>%
      tidyr::separate(!!(rlang::sym('value')),
                      c('FIXED','TYPE','LABEL'),
                      sep='\\|\\|',
                      fill='left',
                      extra='drop')%>%
      dplyr::mutate(
        PARAM = 'OMEGA',
        TYPE = ifelse(is.na(!!(rlang::sym('TYPE')))|!nzchar(!!(rlang::sym('TYPE'))), "[A]", !!(rlang::sym('TYPE')))
        )
  }
  
  if(!is.null(sigma)){
    
    sigma_est <- sigma%>%
      as.matrix()%>%
      gather()%>%
      dplyr::mutate_at(dplyr::vars(.data[['Var1']],.data[['Var2']]),
                       dplyr::funs(as.integer))
    
    sigmac_est <- sigmac%>%
      as.matrix()%>%
      gather()%>%
    dplyr::rename(c=.data[['value']])%>%
    dplyr::mutate_at(dplyr::vars(.data[['Var1']],.data[['Var2']]),
                     dplyr::funs(as.integer))
    
    sigma_join  <- sigma_est%>%
      dplyr::left_join(sigmac_est,
                       by = c("Var1", "Var2"))
    
    if(!is.null(sigmase)){
      
      sigmase_est <- sigmase%>%
        as.matrix()%>%
        gather()%>%
        dplyr::rename(se=.data[['value']])%>%
        dplyr::mutate_at(dplyr::vars(.data[['Var1']],.data[['Var2']]),
                         dplyr::funs(as.integer))
      
      sigmacse_est <- sigmacse%>%
        as.matrix()%>%
        gather()%>%
        dplyr::rename(cse=.data[['value']])%>%
        dplyr::mutate_at(dplyr::vars(.data[['Var1']],.data[['Var2']]),
                         dplyr::funs(as.integer))
      
      sigma_join  <- sigma_join%>%
        dplyr::left_join(sigmase_est, by = c("Var1", "Var2"))%>%
        dplyr::left_join(sigmacse_est, by = c("Var1", "Var2"))
    }
    
    sigma_join <- sigma_join%>%
      dplyr::mutate_at(dplyr::vars(.data[['Var1']],.data[['Var2']]),
                       dplyr::funs(as.integer))%>%
      dplyr::mutate(PARAM='SIGMA')
    
    sigma_lbl <- SIGMA_COMMENT%>%
      gather()%>%
      tidyr::separate(!!(rlang::sym('value')),
                      c('FIXED','TYPE','LABEL'),
                      sep='\\|\\|',
                      fill='left',
                      extra='drop')%>%
      dplyr::mutate(
        PARAM = 'SIGMA',
        TYPE = ifelse(is.na(!!(rlang::sym('TYPE')))|!nzchar(!!(rlang::sym('TYPE'))), "[A]", !!(rlang::sym('TYPE')))
      )
  }
  
  est <- dplyr::bind_rows(theta_join,
                          omega_join,
                          sigma_join)
  
  lbl <- dplyr::bind_rows(theta_lbl,
                          omega_lbl,
                          sigma_lbl)
  
  lbl <- lbl%>%
    dplyr::mutate_at(dplyr::vars(.data[['Var1']],.data[['Var2']]),
                     dplyr::funs(as.integer))
  
  out <- est%>%
    dplyr::left_join(lbl,
                     by = c("Var1", "Var2",'PARAM')
                     )%>%
    dplyr::filter(.data[['value']]!=0)
  
  if(!'c'%in%names(out))
    out <- out%>%
    dplyr::mutate(TYPE=NA,c=NA)
  
  if(!'se'%in%names(out))
    out <- out%>%
    dplyr::mutate(se=NA)
  
  if(!'cse'%in%names(out))
    out <- out%>%
    dplyr::mutate(cse=NA)
  
  ret <- out%>%
    dplyr::filter(.data[['Var2']]<=.data[['Var1']]|.data[['PARAM']]=='THETA')
  
  ret$SAME <- duplicated(ret[,-c(1,2)]) & ret$PARAM != 'THETA'
  
  ret <- ret%>%
    dplyr::select(.data[['PARAM']],
                  .data[['FIXED']],
                  .data[['SAME']],
                  .data[['LABEL']],
                  .data[['UNIT']],
                  .data[['TYPE']],
                  .data[['Var1']],
                  .data[['Var2']],
                  .data[['value']],
                  .data[['c']],
                  .data[['se']],
                  .data[['cse']])
  
    ret <- ret%>%
    dplyr::mutate_at(vars(.data[['FIXED']],.data[['LABEL']],.data[['TYPE']],.data[['UNIT']]),
                     dplyr::funs(ifna)
              )%>%
      dplyr::mutate(FIXED = nzchar(.data[['FIXED']]),
           LABEL = trimws(.data[['LABEL']])
           )
    
    class(ret) <- c(class(ret),'nibble_param')
    
    ret
  
}
