#' @import dplyr
#' @importFrom data.table fread
fetch_ext <- function(path, root, ext, est_ind = identity, header = TRUE, check.names = FALSE){

  if(!nzchar(ext)){
    read_ext <- 'tab'
  }else{
    read_ext <- ext
  }
    
  file_name            <- paste0(c(root,read_ext),collapse = '.')
  x                    <- readLines(sprintf('%s/%s',path,file_name))
  x1                   <- rep(0,length(x))
  x1[grep('^TABLE',x)] <- 1
  x1                   <- cumsum(x1)
  
  RET_L <- lapply(split(x,x1),function(LINES){
        tf         <- tempfile(pattern = 'tmp',fileext = ext)
        
        cat(LINES,sep = '\n',file = tf)
        on.exit(unlink(tf),add = TRUE)
        
        RET        <- data.table::fread(input = tf,sep = ' ',data.table = FALSE,skip = 1,header = header,check.names = check.names)%>%dplyr::as_tibble()
        
        names(RET) <- names(RET)%>%fix_names()
        
        if('NAME'%in%names(RET)){
          RET$NAME <- RET$NAME%>%fix_names()
        }
        
        return(RET)
      })

  names(RET_L) <- sapply(split(x,x1),function(LINES) gsub('\\D','',gsub(':(.*?)$','',LINES[1])))
    
  RET_L        <- est_ind(RET_L)

  return(RET_L)
  
}

#' @title Read NONMEM outputs into a single tibble
#' @description Read NONMEM auxilary outputs from a run into a single tibble. Also can read
#'  all estimations defined in the control stream.
#' @param path character, path the NONMEME run output directory
#' @param root character, name attached to the exts, Default: basename(path)
#' @param exts a character vector of file extensions (excluding the leading dot),
#'  Default: NULL
#' @param est_ind function, which estmiation to return, Default: function(x) utils::tail(x, 1)
#' @return tibble
#' @details 
#' 
#' If root is NULL then basename(path) will be used to mimic the expected behavior when submitting 
#' NONMEM with metrumrg::NONR
#' 
#' If exts is NULL then the function will read all extensions it finds in the path.
#' Extensions that are ignored are c('cat','clt','ctl','lst','cpu','xml','log.xml','msf','INTER'),
#' which have a different structure than target output files.
#' 
#' The default estimation index that is returned is the last one defined in the control stream. 
#' 
#' tibble that is returned contains the column estimation_index, which can be joined
#'  with a \code{\link{nibble}} output.
#' @examples 
#' 
#' path <- system.file('extdata/510',package = 'tidynm')
#' 
#' # read last estimation of all extensions found in directory
#'  read_extensions(path = path)
#'  
#' # read last estimation from only ext and cov extensions
#'  read_extensions(path = path, exts = c('ext','cov'))
#'  
#' # read all estimations from only ext and cov extensions
#'  read_extensions(path = path, est_ind = identity, exts = c('ext','cov'))
#' 
#' @rdname read_extensions
#' @export 
#' @importFrom utils tail
#' @importFrom tools file_ext
#' @import dplyr
#' @importFrom purrr map
#' @importFrom tidyr unnest spread
read_extensions <- function(path, root = basename(path), exts = NULL, est_ind = function(x) utils::tail(x,1)){
  
  avail_ext <- unique(tools::file_ext(list.files(path)))

  if(is.null(exts))
    exts <- avail_ext

  ext <- setdiff(exts,c('cat','clt','ctl','lst','cpu','xml','log.xml','msf','INTER'))

  if(length(ext)==0)
    return(NULL)
  
  x <- dplyr::data_frame(ext=ext)%>%
    dplyr::mutate(output = purrr::map(ext,
                                      fetch_ext,
                                      path = path,
                                      root = root,
                                      est_ind = est_ind))
  
  x%>%
    tidyr::unnest()%>%
    dplyr::mutate(estimation_index=unlist(lapply(x$output,names)))%>%
    tidyr::spread(key=ext,value=.data[['output']])
}
