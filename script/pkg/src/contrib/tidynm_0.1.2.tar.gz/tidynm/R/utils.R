#' @inherit purrr::'%>%'
#' @importFrom purrr %>%
#' @name %>%
#' @rdname pipe
#' @export
NULL

#' @importFrom purrr %||%
#' @name %||%
#' @rdname pipe
#' @export
NULL

#' @inherit tidyr::gather
#' @examples
#' matrix(c(1:12),ncol=2)%>%
#' gather()
#' @importFrom tidyr gather
#' @name gather
#' @rdname gather
#' @export
NULL

#' @import dplyr
#' @importFrom tidyr gather
#' @importFrom rlang .data
#' @rdname gather
#' @export 
gather.matrix <- function(data, key = "key", value = "value", ..., na.rm = FALSE, 
                          convert = FALSE, factor_key = FALSE){
  
  s <- dim(data)
  nm <- dimnames(data)
  
  if(is.null(nm)){
    new_list <- lapply(s,seq,from=1)
  }else{
    new_list <- mapply(function(x,s){
      if(is.null(x)){
        seq(1,s)
      }else{
        x
      }
    },x=nm,s=s,SIMPLIFY = FALSE)
  }
  
  data%>%
    dplyr::as_data_frame()%>%
    tidyr::gather()%>%
    dplyr::bind_cols(expand.grid(new_list,stringsAsFactors = FALSE))%>%
    dplyr::select(.data[['Var1']],
                  .data[['Var2']],
                  .data[['value']])
}

#' @title Automatically flatten list columns by nested class
#' @description If a list column elements are length 1 and a unique class the column will 
#' automatically flatten to that class type 
#' @param x tibble
#' @return tibble
#' @details 
#' auto flattens chr,dbl,int,data.frame
#' @examples 
#' dplyr::data_frame(a = list(x=1, y=2),
#'                   b = list(x='a', y='y'))%>%
#' flatten_auto()
#' @seealso 
#'  \code{\link[purrr]{flatten}}
#' @rdname flatten_auto
#' @export 
#' @importFrom purrr map flatten_dbl flatten_chr flatten_int flatten_df
flatten_auto <- function(x){
  out <- x
  if(is.list(x)){
    if(all(purrr::map(x,length)%>%purrr::flatten_dbl() == 1)){
      
      this_class <- purrr::map(x,class)%>%
        purrr::flatten_chr()%>%
        unique()
      
      if(length(this_class)==1){
        out <- switch(this_class,
          'character' = x%>%purrr::flatten_chr(),
          'numeric' = x%>%purrr::flatten_dbl(),
          'integer' = x%>%purrr::flatten_int(),
          'logical' = x%>%purrr::flatten_lgl(),
          x
        )
      }
    }
  }
  return(out)
}

ifna <- function(x) ifelse(is.na(x),'',x)

#'@importFrom utils compareVersion
nm_version_mapping <- function(nmdat){
  
  if(utils::compareVersion(nmdat$nm_version,'7.4.2')==-1){

           old_names <- names(nmdat)
           
           names(nmdat)[grepl('shrink$',old_names)] <- sprintf('%ssd',
                                                               grep('shrink$',old_names,value = TRUE)
                                                               )
           
  }
  
  return(nmdat)

  
}

sort_comment <- function(x){
  
  sapply(strsplit(x,'\\|\\|'),function(y){
    
    fixed <- 1

    brackets <- which(grepl('\\[|\\]',y))
        
    comment <- paste0(y[-c(fixed,brackets)],collapse = ' ')

    if(length(brackets)==0){
      y <- c(y,'')
      brackets <- length(y)
    }
        
    new_str <- gsub('^\\s|\\s$','',c(y[fixed],y[brackets],comment))
    
    if(sum(!nzchar(new_str))==3){
      new_str <- c(new_str,'')
    }
    
    paste0(new_str,collapse ='||')  
  })
  
}

fix_names <- function(obj){
  
  idx <- grep('\\(',obj)
  
  obj[idx] <- sprintf('%s%s',gsub('\\((.*?)$','',obj[idx]),gsub(',','.',gsub('^(.*?)\\(|\\)','',obj[idx])))
  
  obj
  
}
