#' @title Parse $THETA into tabular form
#' @description Parse $THETA from the control stream.
#' @param x list of character vectors making up the $THETA section of a control stream
#' @return tibble containing: variable number (i.e., THETA_i, i=1,...,N); FIXED, indicating presence of FIX or FIXED in the initial condition; LB, INITITAL, and UB describing the initial condition itself; and UNIT and LABEL which are parsed from the comment.  
#' @details  Parse $THETA into a form that shows initial values and fixed or not fixed.  Units and labels will be parsed as well (see \code{mrgtable}'s \code{nm_tbl} function for details); they are created from the comment and follows the form \code{<init> ; [UNIT] LABEL}.
#' @seealso 
#'  \code{\link[stringi]{stri_count}},\code{\link[stringi]{stri_match_all}}
#' @rdname parse_theta
#' @export 
#' @import dplyr
#' 
#' @importFrom stringi stri_count stri_match
parse_theta <- function(x){
  if(inherits(x,'list'))
    x <- unlist(x)
  
  x1 <- strsplit(x,'\\;')
  
  bounds <- sapply(x1,'[',1)
  labels <- sapply(x1,'[',2)
  
  bounds <- gsub('\\s+|\\(|\\)','',bounds)
  
  fixed <- grepl('FIX',bounds)
  
  bounds <- gsub('FIXED|FIX','',bounds)
  
  count_bounds <- stringi::stri_count(bounds,regex=',')
  
  for(i in seq_along(count_bounds)){
    if(count_bounds[i]==0) bounds[i] <- sprintf(' ,%s, ',bounds[i])
    if(count_bounds[i]==1) bounds[i] <- sprintf('%s, ',bounds[i])
  }
  
  bounds <- strsplit(bounds,',')
  lb <- as.numeric(sapply(bounds,'[',1))
  initial <- as.numeric(sapply(bounds,'[',2))
  
  ub <- as.numeric(sapply(bounds,'[',3))
  
  lb[is.na(lb)] <- -Inf
  ub[is.na(ub)] <- Inf

  label <- gsub('^(.*?)\\]','',labels)
  
  unit <- stringi::stri_match(labels,regex = '\\[(.*?)\\]')
  
  unit <- unit[,ncol(unit)]
  
  out <- dplyr::data_frame(
    Var1=as.integer(1:length(lb)),
    Var2=1,
    FIXED=c('','FIXED')[as.numeric(fixed)+1],
    UNIT=unit,
    LABEL=label,
    LB=lb,
    INITIAL=initial,
    UB=ub
  )
  
  out
}
