#' @title NONMEM Tibble (nibble)
#' @description Tibble object that contains parsed data from NONMEM CTL, XML and TAB outputs
#' @param project character, root path of the NONMEM run(s)
#' @param run character, run number(s) to parse
#' @param estimation_index which estimation to extract, can be 'all','last', or a numeric vector, Default: 'last'
#' @param include_tabs boolean, to read the tab output files created by NONMEM $TABLE calls,
#'  Default: FALSE
#' @param flatten boolean, automatically flatten list columns of output by nested class, Default: FALSE
#' @return nibble class object, where rows are ordered by project/run/estimate
#' and columns are the raw forms of the xml and ctl,
#' the parsed elements of the CTL,XML,TAB and a generated PARAMTBL.
#'
#' \tabular{ll}{
#' \strong{Column} \tab \strong{Description}\cr
#' project                       \tab project path\cr
#' run                           \tab run number\cr
#' xml_raw                       \tab original xml (xml2)\cr
#' ctl_raw                       \tab original ctl (collapsed lines)\cr
#' ctl                           \tab parsed CTL (nmlist)     \cr
#' project_id                    \tab sequential number of project\cr
#' COV                           \tab $COV statments \cr
#' DATA                          \tab $DATA statments\cr
#' ERROR                         \tab $ERROR statments\cr
#' ESTIMATION                    \tab $ESTIMATION statements\cr
#' INPUT                         \tab $INPUT statments\cr
#' OMEGA                         \tab parsed $OMEGA statments converted to a block matrix \cr
#' PK                            \tab $PK statments     \cr
#' PROBLEM                       \tab $PROBLEM statments     \cr
#' SIGMA                         \tab parsed $SIGMA statments converted to a block matrix     \cr
#' SUB                           \tab $SUB statment     \cr
#' TABLE                         \tab $TABLE statments    \cr
#' THETA                         \tab parsed $THETA statments converted to matrix     \cr
#' FILE                          \tab $FILE statments\cr
#' IGNORE                        \tab $IGNORE statments (if in CTL) \cr
#' ACCEPT                        \tab $ACCEPT statments (if in CTL) \cr
#' OMEGA_BLOCK                   \tab parsed $OMEGA statments converted to list of matrices by block\cr
#' SIGMA_BLOCK                   \tab parsed $SIGMA statments converted to list of matrices by block     \cr
#' OMEGA_COMMENT_BLOCK           \tab parsed comments of $OMEGA statments converted to list of matrices by block \cr
#' SIGMA_COMMENT_BLOCK           \tab parsed comments of $SIGMA statments converted to list of matrices by block     \cr
#' OMEGA_COMMENT                 \tab parsed comments of $OMEGA statments converted to a block matrix     \cr
#' SIGMA_COMMENT                 \tab parsed comments of $SIGMA statments converted to a block matrix     \cr
#' estimation_index              \tab estimation number\cr
#' estimation_method             \tab estimation method used (short form)\cr
#' estimation_title              \tab estimation method used (long form)\cr
#' monitor                       \tab monitoring of search     \cr
#' termination_status            \tab termination status\cr
#' termination_nfuncevals        \tab number of function evaluations\cr
#' termination_sigdigits         \tab significant digits in estimate\cr
#' termination_information       \tab element from estimation output in XML\cr
#' termination_txtmsg            \tab element from estimation output in XML     \cr
#' etabar                        \tab Shrinkage statistics     \cr
#' etabarse                      \tab  \cr
#' etabarn                       \tab Shrinkage statistics     \cr
#' etabarpval                    \tab Shrinkage statistics      \cr
#' etashrink                     \tab Shrinkage statistics     \cr
#' ebvshrink                     \tab Shrinkage statistics     \cr
#' epsshrink                     \tab Shrinkage statistics  \cr
#' estimation_elapsed_time       \tab element from estimation output in XML\cr
#' covariance_information        \tab element from estimation output in XML\cr
#' covariance_status             \tab element from estimation output in XML (if present) \cr
#' covariance_elapsed_time       \tab element from estimation output in XML\cr
#' final_objective_function_text \tab element from estimation output in XML\cr
#' final_objective_function      \tab final objective function for specific estimation method\cr
#' theta                         \tab estimate of theta at convergence for specific estimation method \cr
#' omega                         \tab estimate of omega as covariance matrix for specific estimation method  \cr
#' sigma                         \tab estimate of sigma as covariance matrix for specific estimation method  \cr
#' omegac                        \tab estimate of omega as a correlation matrix for specific estimation method  \cr
#' sigmac                        \tab estimate of sigma as a correlation matrix for specific estimation method \cr
#' thetase                       \tab standard error of theta estimates for specific estimation method \cr
#' omegase                       \tab standard error of omega (cov) estimates for specific estimation method  \cr
#' sigmase                       \tab standard error of sigma (cov) estimates for specific estimation method   \cr
#' omegacse                      \tab standard error of omega (corr) estimates for specific estimation method \cr
#' sigmacse                      \tab standard error of sigma (corr) estimates for specific estimation method \cr
#' covariance                    \tab covariance matrix of parameter set \cr
#' correlation                   \tab correlation matrix of parameter set  \cr
#' invcovariance                 \tab inverse covariance matrix of parameter set \cr
#' obs_recs                      \tab number of observation in data\cr
#' individuals                   \tab number of individuals in data  \cr
#' data_recs                     \tab total number of records in data  \cr
#' PARAMTBL                      \tab parameter estimate table \cr
#' table                         \tab tab outputs created by $TABLE statment
#' }
#'
#' @details
#'
#' if project is of a single string it is assumed all the run are in the same folder,
#' if it is longer than one then project must be the length of run.
#'
#' if estimation_index is of a single string it is assumed that the value is applied to all runs.
#' if it is longer than one then estimation_index must be the list the length of run, with values
#' specifying what estimations to return.
#'
#' A generated column called PARAMTBL combines parsed elements of the
#' CTL and the XML. This column contains the data_frame form of parameter estimate table
#' used for LaTeX outputs.
#'
#'
#' @examples
#'
#' # one run
#'
#' nbl_1 <- nibble(project = system.file('extdata',package = 'tidynm'),
#' run = c('510'))
#'
#' nbl_1%>%
#'   head()
#'
#' nbl_1%>%
#'   dplyr::glimpse()
#'
#' # include $TABLE outputs as a column
#'
#' nbl_2 <- nibble(project = system.file('extdata',package = 'tidynm'),
#' run = c('510'),
#' include_tabs = TRUE)
#'
#' nbl_2$table
#'
#' # one run with multiple estimation calls
#'
#' nbl_3 <- nibble(project = system.file('extdata',package = 'tidynm'),
#' run = c('510'),estimation_index='all')
#'
#' nbl_3%>%
#'   head()
#'
#' nbl_3%>%
#'   dplyr::glimpse()
#'
#' # multiple runs in same project folder
#'
#' nbl_4 <- nibble(project = system.file('extdata',package = 'tidynm'),
#' run = c('510','511'))
#'
#' nbl_4%>%
#'   head()
#'
#' nbl_4%>%
#'   dplyr::glimpse()
#'
#' # multiple runs in same project folder, returning specific estimation indicies
#'
#' nbl_5 <- nibble(project = system.file('extdata',package = 'tidynm'),
#' run = c('510','511'),
#' estimation_index = list(c(1,3),c(1)))
#'
#' # automatically flatten list columns of output by nested class
#'
#' nbl_6 <- nibble(project = system.file('extdata',package = 'tidynm'),
#' run = c('510'),flatten = TRUE)
#'
#' nbl_6%>%
#'   dplyr::glimpse()
#'
#' @seealso
#'  \code{\link{parse_nmlist}}, \code{\link{flatten_auto}}
#' @rdname nibble
#' @export
#' @import dplyr
#' @importFrom purrr map2 map map_df transpose set_names
#' @importFrom xml2 xml_find_first xml_text
#' @importFrom rlang .data
nibble <- function(project,
                   run,
                   include_tabs = FALSE,
                   estimation_index = "last",
                   flatten=FALSE) {
  out_ctl <- dplyr::data_frame(project = project, run = run) %>%
    dplyr::mutate(
      xml_raw = purrr::map2(
        run,
        project,
        .f = read_nmlist
      )
    )
  
  out_ctl <- out_ctl%>%
    dplyr::mutate(
      ctl_raw = purrr::map(
        .data[["xml_raw"]],
        .f = function(x) {
          x %>%
            xml2::xml_find_first(".//nm:control_stream") %>%
            xml2::xml_text()
        }
  ))
      
  out_ctl <- out_ctl%>%
    dplyr::mutate(
      ctl = purrr::map(
        .data[["ctl_raw"]],
        .f = ctl_parse
      ))
  
  out_ctl <- out_ctl%>%
    dplyr::mutate(
      project_id = as.character(1:n())
    )

  out_ctl <- dplyr::bind_cols(
    out_ctl,
    out_ctl$ctl %>%
      purrr::transpose() %>%
      dplyr::as_tibble()
  )

  out_all <- purrr::map2(out_ctl$xml_raw, estimation_index, .f = function(x, y) {
    this_list <- parse_nmlist(x, fields = "all", attach_attr = TRUE, index = y)

    if ("estimation_index" %in% names(this_list)) {
      this_list <- list(this_list)
    }

    this_list
  })

  out_all <- out_all %>%
    purrr::map_df(function(x) {
      x %>%
        purrr::transpose() %>%
        dplyr::as_tibble()
    }, .id = "project_id")

  final <- out_ctl %>%
    dplyr::left_join(out_all, by = "project_id")

  nms <- names(final)[names(final) %in% eval(formals(param_tbl)[[2]])]

  final$l_in <- final[, nms] %>%
    purrr::transpose()

  final <- final %>%
    dplyr::mutate(PARAMTBL = purrr::map(
      .x = .data[["l_in"]],
      .f = param_tbl
    )) %>%
    dplyr::select(-.data[["l_in"]])

  if (include_tabs) {
    final <- final %>%
      dplyr::mutate(table = purrr::map2(
        file.path(project, run),
        .data[["TABLE"]],
        nm_tab
      ))
  }

  if (flatten) {
    final <- final %>%
      dplyr::mutate_all(flatten_auto)
  }
  
  final <- final%>%
    dplyr::mutate_all(function(x){
      if(is.null(names(x)) & inherits(x,what = 'list')){
        x <- x%>%purrr::set_names(seq_along(x))   
      }
      x
    })
  
  structure(final, class = c("nibble", class(final)))
}
