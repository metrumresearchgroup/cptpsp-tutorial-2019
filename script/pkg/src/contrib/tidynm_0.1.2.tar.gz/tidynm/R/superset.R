#' @title Join NONMEM input data to tab output
#' @description Join NONMEM input data to tab output by index column
#' @param x data_frame, tab output file.
#' @param y data_frame, data input that used for the NONMEM run.
#' @param index__ character, name of column(s) to join the two data_frames. 
#' Default: 'index__', created by the function as a simple row number index.
#' @return data_frame
#' @details The data sets are joined as tab_output%>%left_join(input_data, by=index__).  
#' This intentionally labels duplicate columns from the tab file with the .x suffix
#' and uses the .y suffix for the NONMEM dataset.
#' @examples 
#' 
#' nbl <- nibble(
#' project = system.file('extdata',package = 'tidynm'),
#' run = c('510'),
#' include_tabs = TRUE
#' )
#' 
#' dat <- data.table::fread(file       = system.file('extdata/poppk_wcovs.csv',package = 'tidynm'),
#'                          data.table = FALSE)%>%
#'        dplyr::as_tibble()
#'        
#' # readr is not imported by tidynm 
#' # dat <- readr::read_csv(system.file('extdata/poppk_wcovs.csv',package = 'tidynm'))
#' 
#' nbl$table[[1]][[1]] <- nbl$table[[1]][[1]]%>%dplyr::mutate(index__ = 1:n())
#' 
#' dat <- dat%>%dplyr::mutate(index__ = 1:n())
#' 
#' xtab <- nbl$table[[1]][[1]]
#' 
#' # join data_frame to data_frame
#' xtab%>%superset(dat)
#' 
#' # join list to data_frame
#' nbl$table[[1]]%>%superset(dat)
#'  
#' # join nibble column to data_frame  
#' nbl%>%
#'   dplyr::mutate(newdat = purrr::map(table,superset,dat))%>%
#'   purrr::pluck('newdat')%>%
#'   purrr::flatten_df()
#' 
#' @rdname superset
#' @export
superset <- function(x, y, index__){
  UseMethod("superset")
}


#' @rdname superset
#' @export 
#' @import dplyr
superset.default <- function(x, y, index__='index__'){

  if(inherits(x,'list')){
    nx <- names(x)
    nx <- nx[!grepl('par.tab',nx)]
    if(length(nx)>1)
      stop('more than one *.tab to choose from')
    
    x <- x[[nx]]
    
  }

  x%>%
    dplyr::left_join(y,by=index__) 
}


#' @title Join NONMEM input data to tab output directly from nibble
#' @description Join NONMEM input data to tab output by index column using information 
#' contained in a nibble object
#' @param x nibble
#' @param y ignored
#' @param index__ character, name of column(s) to join the two data_frames, Default: 'index__'
#' @return list the length of the number of rows in the input nibble object each containing a data_frame
#' @details The data sets are joined as tab_output%>%left_join(input_data), if the column 'index__'
#' is missing from either the tab_output or the input_data one will be created automatically.
#' @examples 
#' 
#' nbl <- nibble(project = system.file('extdata',package = 'tidynm'),run = c('510'))
#' 
#' nbl%>%
#'  superset()%>%
#'  purrr::flatten_df()
#' 
#' @rdname superset_nibble
#' @export 
#' @import dplyr
#' @importFrom purrr map map2
superset.nibble <- function(x, y=NULL, index__='index__'){

  if(!'table'%in%names(x)){
    table__ <- purrr::map2(file.path(x$project,x$run),x$TABLE,nm_tab)
  }else{
    table__ <- x$table
  }

  table__ <- purrr::map(table__,.f=function(x){
    if(inherits(x,'list')){
      nx <- names(x)
      nx <- nx[!grepl('par.tab',nx)]
      if(length(nx)>1)
        stop('more than one *.tab to choose from')
      
      x <- x[[nx]]
      
      if(!'index__'%in%names(x) & any(index__=='index__'))
        x$index__ <- 1:nrow(x)
      
      x
      
      }
    })
  
  y__ <- purrr::pmap(list(x$project,x$run,x$DATA),nm_dat, add_index_col = any(index__=='index__'))
  
  purrr::map2(table__,y__,.f=function(x,y,index__){
    x%>%dplyr::left_join(y,by = index__)
  },index__=index__) 
}
