#' @title Parse NONMEM CTL file into a list
#' @description Convert NONMEM CTL file into a list
#' @param ctl character, CTL file name or lines
#' @return list
#' @details The \code{ctl} argument may be specified as either a location on disk
#' of a control stream or a single string (i.e., via read_file). 
#' All non-empty lines in the THETA, OMEGA, and SIGMA blocks will be parsed for 
#' initial values and boundaries, and all text after the semicolon in these lines
#' will be tracked as comments.  
#' a format
#' @examples 
#'  run <- 510
#'  
#'  project <- system.file("extdata", package="tidynm")
#'  
#'  xml_raw   <- read_nmlist(run, project)
#'  
#'  ctl_raw   <- xml_raw%>%
#'                xml2::xml_find_first('.//nm:control_stream')%>%
#'                xml2::xml_text()
#'                
#'  ctl_parse <- ctl_raw%>%
#'                ctl_parse()
#'  
#'  str(ctl_parse)
#'  
#' @rdname ctl_parse
#' @export 
#' @importFrom stringi stri_split_regex
ctl_parse <- function(ctl){

  if(all(file.exists(ctl))) ctl <- paste0(c(readLines(ctl),''),collapse = '\n')
  ctl <- clean_ctl(ctl)
  
  ctl$DATA <- stringi::stri_split_regex(gsub('\t','',ctl$DATA[[1]][1]),pattern = '\\s',n = 2)
  
  ctl$FILE                <- ctl$DATA[[1]][1]
  
  ctl$IGNORE              <- gsub('IGNORE=|\\(|\\)','',ctl$DATA[[1]][2])

  ctl$THETA               <- parse_theta(ctl$THETA)
  
  ctl$OMEGA_BLOCK         <- ctl_to_mat(ctl$OMEGA)
  ctl$SIGMA_BLOCK         <- ctl_to_mat(ctl$SIGMA)

  ctl$OMEGA_COMMENT_BLOCK <- ctl_to_mat(ctl$OMEGA, type='comment')
  ctl$SIGMA_COMMENT_BLOCK <- ctl_to_mat(ctl$SIGMA, type='comment')
  
  if(inherits(ctl$OMEGA_COMMENT_BLOCK,'list')){
    ctl$OMEGA_COMMENT <- combine_blocks(ctl$OMEGA_COMMENT_BLOCK)
  }else{
    ctl$OMEGA_COMMENT <- ctl$OMEGA_COMMENT_BLOCK
  }
  
  if(inherits(ctl$SIGMA_COMMENT_BLOCK,'list')){
    ctl$SIGMA_COMMENT <- combine_blocks(ctl$SIGMA_COMMENT_BLOCK)
  }else{
    ctl$SIGMA_COMMENT <- ctl$SIGMA_COMMENT_BLOCK
  }
  
  ctl$OMEGA <- ctl$OMEGA_BLOCK%>%Matrix::bdiag()%>%as.matrix()
  ctl$SIGMA <- ctl$SIGMA_BLOCK%>%Matrix::bdiag()%>%as.matrix()

  ctl
}

#' @importFrom purrr set_names
clean_ctl <- function(x){
  x0 <- ctl_rm_comments(x)
  x1 <- gsub('(\n\n|\n|\n;|\n\n;)$','',strsplit(x0,'\\$')[[1]])
  x2 <- sub('\n',' ',x1)
  x3 <- as.list(gsub('^(.*?)\\s+','',x2))
  names(x3) <- gsub('\\s+(.*?)$','',x2)
  
  x3 <- x3[sapply(x3,nzchar)]
  
  x3 <- split(x3,names(x3))
  
  x3 <- lapply(x3,purrr::set_names,nm=NULL)
  
  x4 <- lapply(x3,function(x){
    if(is.list(x)){
      out <- lapply(x,function(xx){
        out <- gsub('^\\s+|\\s+$','',strsplit(xx,'\n')[[1]])
        out[nzchar(out)]
      })
      list(out)
    }else{
      out <- gsub('^\\s+|\\s+$','',strsplit(x,'\n')[[1]])
      out[nzchar(out)]
    }
    
  })
  
  nc <- names(x4)[(!nzchar(gsub('[A-Z]','',names(x4))))]
  
  x4 <- x4[nc[nchar(nc)>1]]
  
  unlist(x4,recursive = FALSE)
}

#' @import dplyr
combine_blocks <- function(COMMENT_BLOCK){
  
  COMMENT <- lapply(COMMENT_BLOCK,dplyr::as_data_frame)
  
  for(i in 2:length(COMMENT)){
    nc1 <- max(as.numeric(gsub('\\D','',names(COMMENT[[i-1]]))))
    nc2 <- ncol(COMMENT[[i]])
    names(COMMENT[[i]]) <- sprintf('V%s',(nc1+1):(nc1+nc2))  
  }
  
  COMMENT <- COMMENT%>%
    dplyr::bind_rows()%>%
    as.matrix()
  
  colnames(COMMENT) <- NULL
  
  COMMENT[is.na(COMMENT)] <- ''
  
  COMMENT
}

ctl_rm_comments <- function(x){
  x0 <- strsplit(x,'\n')[[1]]
  paste0(x0[!grepl('^\\s*;',x0)],collapse = '\n')
}
