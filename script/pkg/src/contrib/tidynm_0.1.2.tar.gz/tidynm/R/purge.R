#' @title remove elements by predicate from a nested list
#' @description recurvsive version of purrr::discard
#' @param x list
#' @param .p predicate, Default: identity
#' @return list
#' @examples 
#' 
#'  x <- list(NULL,list(a=list(1,NULL)),list(b=list(list(3,NA),2)))
#'  
#'  purge(x,.p = is.null)
#'  
#'  purge(x,.p=function(y) is.null(y)||is.na(y))
#'  
#' @rdname purge
#' @export 

purge <- function(x,.p = identity){
  
  x <- x[!sapply(x,.p)]
  
  if(inherits(x,'list')){
    lapply(x,purge,.p = .p)
  }else{
    x
  }

}
