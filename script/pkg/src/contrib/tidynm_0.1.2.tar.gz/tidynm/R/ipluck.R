#' @import dplyr 
#' @importFrom rlang dots_splice !!! syms
#' @importFrom tidyr unite
mrg_pluck <- function(this_pluck){
  
  #add formal for .id columns
  
    fpluck <- formals(this_pluck)
    
    fpluck <-  append(fpluck,list(.id=NULL))
    
    formals(this_pluck) <- fpluck
  
  #add to body new .id functionality
  
    bpluck <- body(this_pluck)
    
    bpluck[[2]] <- quote(out <- .Call(extract_impl, .x, rlang::dots_splice(...), .default))
    
    bpluck[[3]] <- quote(if(!is.null(.id)) names(out) <- .x[.id]%>%tidyr::unite(!!(rlang::sym('key')),!!!(rlang::syms(.id)))%>%dplyr::pull(!!(rlang::sym('key'))))

    bpluck[[4]] <- quote(return(out))
  
  #update new function body
  
    body(this_pluck) <- bpluck
    
    this_pluck
}

#' @inherit purrr::pluck
#' @param .id If not NULL the names of the plucked elements will be the column name specified, if more than one then 
#' they are concatenated using an underscore. 
#' @examples 
#' 
#' data <- dplyr::data_frame(id_1=letters[1:3],x=list(c(1),c(2),c(3)))%>%
#' dplyr::mutate(id_2=LETTERS[1:3])
#' 
#' data%>%
#' ipluck('x',.id=c('id_1'))
#' 
#' data%>%
#' ipluck('x',.id=c('id_1','id_2'))
#' 
#' @export
#' @seealso 
#' \code{\link[purrr]{pluck}}
#' @importFrom purrr pluck
ipluck <- mrg_pluck(purrr::pluck)
