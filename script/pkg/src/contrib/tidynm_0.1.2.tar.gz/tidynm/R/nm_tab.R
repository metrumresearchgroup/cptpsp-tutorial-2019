#' @import dplyr
#' @importFrom purrr map map2 set_names
#' @importFrom tools  file_path_sans_ext file_ext
nm_tab <- function(x,y){
  
    y         <- purrr::map(y, function(x) paste0(gsub(';(.*?)','',x),collapse = ' '))
    
    y         <- purrr::map(y, gsub , pattern = '\\s?([=])\\s?',replacement='=') # remove white spaces around '='
    
    FILE      <- purrr::map(y, gsub , pattern = '^(.*?)FILE=|\\s{1}(.*?)$', replacement = '')
    
    HEADER    <- purrr::map(y, grepl, pattern = 'ONEHEADER')
    
    FILE_PATH <- purrr::map2(x, FILE, file.path)

    out <- purrr::map2(FILE_PATH,HEADER,function(x, header, check.names = FALSE){
      fetch_ext(
        path = dirname(x),
        root = tools::file_path_sans_ext(basename(x)),
        ext  = tools::file_ext(basename(x)),
        header = header,
        check.names = check.names
      ) 
    }, check.names = TRUE)
    
    out <- lapply(out,'[[',1)%>%
      purrr::set_names(nm = FILE%>%
                         unlist()%>%
                         basename()
                       )
    
    return(out)
}
