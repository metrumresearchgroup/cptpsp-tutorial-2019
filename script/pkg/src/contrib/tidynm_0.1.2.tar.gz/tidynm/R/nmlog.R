#' @title Create a log of NONMEM runs
#' @description Create data.frame from NONMEM estimations in a run
#' @param run numeric, vector of run numbers
#' @param project characgter, project directory
#' @return data.frame
#' @rdname nmlog
#' @export
#' @importFrom dplyr bind_rows mutate select everything starts_with
#' @importFrom purrr set_names
nmlog <- function(run, project) {

  runl <- lapply(run, function(r,project){
    
    read_nmlist(r, project)%>%
      parse_nmlist()
    
  }, project = project)

  theta <- lapply(runl, function(x) {

    xx <- x$theta%>%
      t()%>%
      as.data.frame()

    yy <- x$omega[lower.tri(x$omega, diag=TRUE)]%>%
      as.list()

    names(yy) <- paste0("V",seq_along(yy))

    xx <- cbind(xx,as.data.frame(yy))

    yy <- x$sigma[lower.tri(x$sigma, diag=TRUE)]%>%
      as.list()

    names(yy) <- paste0("VV", seq_along(yy))

    xx <- cbind(xx,as.data.frame(yy))

    xx$OFV <- x$fov

    xx$TERM <- x$term

    xx
  })

  theta <- theta%>%
    purrr::set_names(nm=run)%>%
    dplyr::bind_rows(.id='run')


  theta%>%
    dplyr::select(.data[['run']],
                  .data[['OFV']],
                  .data[['TERM']],
                  dplyr::starts_with("THETA"),
                  dplyr::everything()
                  )
}
