## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----example,warning=FALSE,message=FALSE---------------------------------
library(dplyr)
library(purrr)
library(tidyr)
library(tidynm)

## ------------------------------------------------------------------------

#internal example projects and runs

nbl <- nibble(project = system.file('extdata',package = 'tidynm'),
              run = c('510'),include_tabs = TRUE)


nbl%>%dplyr::glimpse()


## ------------------------------------------------------------------------
nbl%>%
 dplyr::select(
   run,
   final_objective_function,
   covariance_status,
   termination_status)


## ------------------------------------------------------------------------
#theta is a list column ordered by run
nbl%>%
  dplyr::select(run,theta)

#to expose it use pluck (use id to name the list elements from other columns in the nibble)
nbl%>%
  ipluck('theta',.id='run')

#multiple id columns are pasted together with an '_'
nbl%>%
  ipluck('theta',.id=c('estimation_method','run'))

#or the estimated covariance matrix
nbl%>%
  ipluck('covariance')


## ------------------------------------------------------------------------
nbl$PARAMTBL[[1]]

## ----tabs----------------------------------------------------------------
nbl$table[[1]]

## ------------------------------------------------------------------------
nbl_2 <- nibble(project = system.file('extdata',package = 'tidynm'),
                run = c('510'),estimation_index = 'all')

nbl_3 <- nibble(project = system.file('extdata',package = 'tidynm'),
                run = c('510'),estimation_index = list(c(1,3)))

nbl_2%>%
  dplyr::select(run,estimation_method,final_objective_function)

nbl_3%>%
  dplyr::select(run,estimation_method,final_objective_function)

# combine nibbles

dplyr::bind_rows(nbl_2,nbl_3)

