## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----example,warning=FALSE,message=FALSE---------------------------------
library(dplyr)
library(purrr)
library(tidyr)
library(tidynm)

## ------------------------------------------------------------------------
nbl <- nibble(project = system.file('extdata',package = 'tidynm'),
              run = c('510'),include_tabs = TRUE)

## ------------------------------------------------------------------------

library(pmplots)

nbl%>%
  burrow('table/510par.tab')%>%
  pmplots::dv_pred()

nbl%>%
  burrow('table/510par.tab')%>%
  pmplots::dv_time() + 
  facet_wrap(~SEX)



## ------------------------------------------------------------------------
library(mrgtable)

## ------------------------------------------------------------------------
nbl$PARAMTBL[[1]]%>%nm_tbl(returndf = TRUE)

## ----eval=FALSE----------------------------------------------------------
#  nbl$PARAMTBL[[1]]%>%nm_tbl()

