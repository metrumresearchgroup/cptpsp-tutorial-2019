## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----example,warning=FALSE,message=FALSE---------------------------------
library(dplyr)
library(purrr)
library(tidyr)
library(tidynm)

## ------------------------------------------------------------------------

# read in a few runs

nbl_1 <- nibble(project = system.file('extdata',package = 'tidynm'),
                run = c('510','510_fixed'),include_tabs = TRUE)

nbl_2 <- nibble(project = system.file('extdata',package = 'tidynm'),
                run = c('510'),estimation_index = 'all')

## ------------------------------------------------------------------------

# names of tables created by each run
nbl_1$table%>%map(names)

#current purrr way to get to a single table ('510par.tab')

nbl_1%>%
  purrr::pluck('table')%>%
  purrr::flatten()%>%
  ipluck('510par.tab')

#burrow

# instead use a file.path type string to go down a list heirarchy and return the children

purrr::map(nbl_1$table,burrow,path='510par.tab')

# we can use indexes instead of names
# first table in each run
purrr::map(nbl_1$table,burrow,path='[1]')

# or use regular expressions to choose tables
# choose the tab (no par.tab) tables from runs 510 and 510_fixed
purrr::map(nbl_1$table,burrow,path='(510)\\.tab',regex=TRUE)


## ------------------------------------------------------------------------
## an .id column has been added to purrr::pluck so you can name the output elements directly from a different column in a tibble

#purrr pluck
nbl_2%>%
  purrr::pluck('theta')

#tidynm ipluck
nbl_2%>%
  ipluck('theta',.id=c('estimation_method','run'))

#this lets us combine elements more easily and continue working

# compare parameters estimations within the run

nbl_2%>%
  ipluck('theta',.id=c('estimation_method','run'))%>%
  bind_cols()

## ------------------------------------------------------------------------

x <- list(NULL,list(a=list(1,NULL)),list(b=list(list(3,NA),2)))
  
x

purge(x,.p = is.null)
  
purge(x,.p=function(y) is.null(y)||is.na(y))


