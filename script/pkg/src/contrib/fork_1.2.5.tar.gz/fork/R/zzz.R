.onLoad <- function(lib, pkg)
  {
    library.dynam("fork",pkg,lib)
  }
