# mrgtable 0.1.4

  * Bug Fixes:
    - `mrgtable::sig` now checks for integer class values and will not manipulate these
  * Refactors:
    - Replace `UQ` and `UQS` with `!!` and `!!!` per warnings from `rlang`
    - Parsing of `yml` directive file elements will now be attempted (e.g., for setting working directories)


# mrgtable 0.1.2.1

  * Bug Fixes
    - Fix typo in `nm_create` `"Type"` to `"TYPE"` which caused the OMEGA and SIGMA block types not to react properly in table creation.
    - Fix treatment of underscore in column labels that were being cut off after first underscore in label value. 
  * API improvment
    - Export function `preview_tex` to allow users to preview TeX tables not created by `mrgtable`.
    - Replace TeX `verb` command for tabular objects with `lstinline` from `listings` package to create a more robust mechanism to include verbatim elements in a TeX table.
    - Export function `sig` to allow it to be used with other packages within a workflow.
    - Set `verbatim` parameter to `FALSE` for `mrgtable` created tables to create a unified output format for all tables. 
    - Introduce autocompletion functionality for `mrgtable_opt$set` function to simplify usage within `RStudio` IDE. 
    - Rewrite wrap tabular to depend on `mrgtable_opts` `returnType` to simplify function API call, instead of user needing to set multiple arguments on function call.

# mrgtable 0.1.0

* Added a `NEWS.md` file to track changes to the package.

* Initial release of the package.
