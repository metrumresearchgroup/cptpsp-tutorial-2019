[![Build Status](https://travis.metrumrg.com/software/mrgtable.svg?token=tfrDuc83e84K9CqJKyCs&branch=master)](https://travis.metrumrg.com/software/mrgtable)
[![Covrpage Summary](https://img.shields.io/badge/covrpage-Last_Build_2018_11_30-brightgreen.svg)](https://ghe.metrumrg.com/software/mrgtable/blob/toggle_verbatim/tests/README.md)

# mrgtable

The MetrumRG table generation package

## Installation

### Validated

```r
repos <- c("https://metrumresearchgroup.github.io/r_validated", options()$repos)

install.packages("mrgtable", repos = unique(repos), type = "source", destdir = "pkg")
```

### Release Candidate

```r
repos <- c("https://metrumresearchgroup.github.io/rpkgs/rc", options()$repos)

install.packages("mrgtable", repos = unique(repos), type = "source", destdir = "pkg")
```

### Development

```r
remotes::install_github('software/mrgtable',host = 'ghe.metrumrg.com/api/v3',auth_token = Sys.getenv('GHE_PAT'))
```

## News

News can be found [here](https://ghe.metrumrg.com/pages/software/mrgtable/news/index.html)

## Usage

Examples of features can be found in the package usage vingette and [here](https://ghe.metrumrg.com/pages/software/mrgtable/articles/Usage.html)

## Options

List of options for use with `mrgtable` (set with `mrgtable_opts$set(option=<value>)`):

* `returnType ("tex")`: What should return from the function?  By default, a tex character object is returned.  When `viewer` is selected, the return object will be NULL with a rendering of the table in the Rstudio viewer as a side effect.  
* `srcAdd (TRUE)`: Should a footer be added to tables with location of script and tex sources?
* `srcName ("script")`: Name of the source script
* `srcPath (".")`: Path to the source script
* `objPath ("../deliv/table")`: Path to the object location on disk
* `table_position ("!htbp")` : value that `wrap_tabular` and the `wrap_tabular` addin use for tex table potisition. see `?wrap_tabular` for details.

Use `?mrgtable_opts` for more details.
