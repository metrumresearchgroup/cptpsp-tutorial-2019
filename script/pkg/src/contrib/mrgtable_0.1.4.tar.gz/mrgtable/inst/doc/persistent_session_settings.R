## ----setup, include=FALSE------------------------------------------------
library(mrgtable)
knitr::opts_chunk$set(echo = TRUE,warning = FALSE,message = FALSE)

mrgtable_opts$set(list(objPath=tempdir(), srcAdd = FALSE, returnType= 'html'))
texPreview::tex_opts$append(list(cleanup='tex'))

