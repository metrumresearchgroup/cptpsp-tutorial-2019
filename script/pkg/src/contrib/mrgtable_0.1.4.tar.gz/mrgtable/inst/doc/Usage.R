## ----setup, include=FALSE------------------------------------------------
library(mrgtable)
library(texPreview)

knitr::opts_chunk$set(echo = TRUE,warning = FALSE,message = FALSE)

## ------------------------------------------------------------------------
mrgtable_opts$set(list(objPath=tempdir(), returnType= 'html'))

## ------------------------------------------------------------------------

labelled::var_label(mi210$STUDY) <- 'Study ID'
labelled::var_label(mi210$CLCRF) <- 'Clearance'
labelled::var_label(mi210$SEX) <- 'Gender'
labelled::var_label(mi210$HT) <- 'Height'
labelled::var_label(mi210$WT) <- 'Weight'

## ------------------------------------------------------------------------
mi210%>%
  cat_tbl(formula = STUDY ~ CLCRF + SEX,
          stem    = "demogTabCat1",
          idVar   = "ID")

## ------------------------------------------------------------------------
mi210%>%
  cat_tbl(formula = STUDY ~ CLCRF + SEX,
          idVar   = "ID",
          returndf = TRUE
  )


## ---- results="asis"-----------------------------------------------------
mi210%>%
  cat_tbl(formula = STUDY ~ CLCRF | SEX,
          stem    = "demogTabCat2",
          idVar   = "ID")

## ---- results="asis"-----------------------------------------------------
mi210%>%
  cat_tbl(formula = STUDY ~ CLCRF | SEX,
          stem    = "demogTabCat7",
          idVar   = "ID",
          total   = FALSE)

## ---- results="asis",message=FALSE---------------------------------------
mi210%>%
  cat_tbl(formula = STUDY ~ CLCRF + SEX,
          stem    = "demogTabCat3",
          idVar   = "ID",
          wide    = FALSE)

## ---- results="asis",message=FALSE---------------------------------------
mi210%>%
  cat_tbl(formula = STUDY ~ CLCRF | SEX,
          idVar   = "ID",
          wide    = FALSE, 
          stem    = "demogTabCat4")

## ---- results="asis"-----------------------------------------------------
mi210%>%
  cat_tbl(formula = STUDY ~ CLCRF | SEX,
          stem    = "demogTabCat8", 
          idVar   = "ID",
          total   = FALSE,
          wide    = FALSE)

## ---- echo=FALSE, results="asis", message=FALSE, include=FALSE-----------

mi210 <- mi210%>%
  labelled::set_value_labels(SEX = c('Male' = 0, 'Female' = 1))

mi210%>%
  cat_tbl(formula = STUDY ~ CLCRF | SEX,
          idVar   = "ID",
          stem    = "demogTabCat5")

## ---- results="asis"-----------------------------------------------------

mi210%>%
  cont_tbl(formula = STUDY ~ AGE + HT + WT,
           stem="demogTabCont1",
           idVar="ID")

## ------------------------------------------------------------------------
mi210%>%
  cont_tbl(formula  = STUDY ~ AGE + HT + WT,
           idVar    = "ID",
           returndf = TRUE)

## ---- results="asis"-----------------------------------------------------
mi210%>%
  cont_tbl(formula = STUDY ~ AGE + HT + WT | CLCRF,
           stem="demogTabCont2",
           idVar="ID")

## ---- results="asis"-----------------------------------------------------
mi210%>%
cont_tbl(formula = STUDY ~ AGE + HT + WT | CLCRF,
         stem="demogTabCont3",
         idVar="ID",
         total=FALSE)

## ---- results="asis"-----------------------------------------------------
mi210%>%
  cont_tbl(formula = STUDY ~ AGE + HT + WT,
           stem="demogTabCont4",
           idVar="ID",
           wide=FALSE)

## ---- results="asis"-----------------------------------------------------
mi210%>%
  cont_tbl(formula = STUDY ~ AGE + HT + WT | CLCRF,
           stem="demogTabCont5",
           idVar="ID",
           wide=FALSE)

## ---- results="asis"-----------------------------------------------------
mi210%>%
cont_tbl(formula = STUDY ~ AGE + HT + WT | CLCRF,
         stem="demogTabCont6",
         total=FALSE,
         idVar="ID",
         wide=FALSE)

## ---- results="asis"-----------------------------------------------------
mi210%>%
  cont_tbl(formula = STUDY ~ AGE + HT + WT | CLCRF,
           stem="demogTabCont7",
           template = '{mean} <{sd}> [{min} {max}]',
           total=FALSE,
           idVar="ID",
           wide=FALSE)

## ---- results="asis"-----------------------------------------------------
mi210%>%
  cont_tbl(formula = STUDY ~ AGE + HT + WT | CLCRF,
           stem="demogTabCont8",
           template = '{mean} mmHg <{sd}> [{min} {max}]',
           total=FALSE,
           idVar="ID",
           wide=FALSE)

## ---- results="asis"-----------------------------------------------------
mi210%>%
  cont_tbl(formula = STUDY ~ AGE + HT + WT | CLCRF,
           stem="demogTabCont9",
           template = '{mean} \\{{{sd}\\}} [{min} {max}]',
           total=FALSE,
           idVar="ID",
           wide=FALSE)

## ---- results="asis"-----------------------------------------------------
mi210%>%
  cont_tbl(formula = STUDY ~ AGE + HT + WT | SEX,
           stem="demogTabCont10",
           template = '{mean} $\\beta$ \\{{{sd}\\}} [{min} {max}]',
           total=FALSE,
           idVar="ID",
           wide=FALSE,sanitize.math = FALSE)


## ---- results="asis"-----------------------------------------------------
mi210%>%
  cont_tbl(formula = STUDY ~ AGE + HT + WT | CLCRF,
           stem="demogTabCont11",
           template = '{mean} ({cv})',
           total=FALSE,
           idVar="ID",
           wide=FALSE)

## ---- results="asis"-----------------------------------------------------
# Create own summary statistics
q25=function(x) quantile(x,probs=.25)
q75=function(x) quantile(x,probs=.75)

mi210%>%
  cont_tbl(
    formula = STUDY ~ AGE + HT + WT | SEX,
    idVar='ID',
    template='{mean} {sd} [{q25} - {q75}]',
    stem="demogTabCont12")

## ------------------------------------------------------------------------
library(tidynm)

## ------------------------------------------------------------------------
nbl <- nibble(project = system.file('extdata',package = 'tidynm'), 
              run = c('510'),include_tabs = TRUE)

## ---- results="asis"-----------------------------------------------------
nbl$PARAMTBL[[1]]%>%nm_tbl()

## ------------------------------------------------------------------------
nbl$PARAMTBL[[1]]%>%nm_tbl(returndf = TRUE)

## ------------------------------------------------------------------------
data <- mi210%>%
  dplyr::filter(EVID==0)%>%
  dplyr::mutate(BLQ=(DV<=4&DV>0))

set.seed(123)
data$rndGroup <- sample(1:5,size = nrow(data),replace = TRUE)

data$NODOSE <- data$DV==0

labelled::var_label(data$rndGroup) <- 'Randomized Group'
labelled::var_label(data$NODOSE) <- 'No Dose Administered'


## ---- results="asis"-----------------------------------------------------
data%>%
  count_tbl(formula = STUDY + rndGroup ~ BLQ[TRUE] + NODOSE[TRUE],
            stem = "demogTabCount1")

## ---- results="asis"-----------------------------------------------------
data%>%
  count_tbl(formula = STUDY + rndGroup ~ .,
            stem = "demogTabCount2")

## ------------------------------------------------------------------------
set0 <- mrgtable_opts$get()
mrgtable_opts$set(list(returnType="tex"))

## ------------------------------------------------------------------------
mi210$row <- 1:nrow(mi210)
tex <- mi210%>%
  cat_tbl(formula = STUDY ~ ID,
          total = FALSE,
          idVar = "row",
          wide  = FALSE)

writeLines(table_to_longtable(tex))

## ------------------------------------------------------------------------
mrgtable_opts$set(set0)

## ---- eval=FALSE---------------------------------------------------------
#  mrgtable_opts$set(srcAdd=FALSE)
#  
#  mi210%>%
#    cat_tbl(formula = STUDY ~ SEX | CLCRF,
#            stem="tagging1",
#            idVar="ID")

## ----include=FALSE-------------------------------------------------------
mrgtable_opts$restore()

## ------------------------------------------------------------------------
mrgtable_opts$get()

#set options instead of default settings
mrgtable_opts$set(list(objPath="./inst/NEWS", srcName="NEWS.Rmd", returnType= 'html'))

mrgtable_opts$get(c('objPath','srcName','returnType'))

#return to default
mrgtable_opts$restore()

## ------------------------------------------------------------------------
myopts <- mrgtable_opts$get()
#change footer setting
myopts$srcAdd <- FALSE
myopts

mi210%>%
  cat_tbl(formula = STUDY ~ CLCRF + SEX ,
          stem="demogTabCat1",
          idVar="ID",
          table_opts = myopts)

## ------------------------------------------------------------------------
tex_opts$get()

