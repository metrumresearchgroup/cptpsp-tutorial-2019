testthat::context('Input objects')

testthat::describe('check inherit function', {

  it('data.frame',{
    testthat::expect_silent(mrgtable:::check_class(data.frame()))
  })
  
  it('tbl_df',{
    testthat::expect_silent(mrgtable:::check_class(dplyr::tibble()))
  })

  it('nibble',{
    x <- data.frame()
    class(x) <- c(class(x),'nibble')
    testthat::expect_silent(mrgtable:::check_class(x,c('nibble')))
  })
    
  it('wrong class',{
    testthat::expect_error(mrgtable:::check_class(list()))
  })
  
})

