testthat::context('Count table')

data(mi210)

data <- mi210%>%
  dplyr::filter(EVID==0)%>%
  dplyr::mutate(BLQ=(DV<=4&DV>0))

set.seed(123)
data$rndGroup <- sample(1:5,size = nrow(data),replace = TRUE)

data$NODOSE <- data$DV==0

labelled::var_label(data$STUDY) <- 'Study Phase'
labelled::var_label(data$rndGroup) <- 'Randomization Group'
labelled::var_label(data$NODOSE) <- 'No Dose'

testthat::describe('count_tbl',{

  x <- data%>%
    count_tbl(formula = STUDY + rndGroup ~ BLQ[TRUE] + NODOSE[TRUE],returndf = TRUE)

  
  it('class', {
    testthat::expect_s3_class(x,'tbl_df')
  })
  it('dimension', {
    testthat::expect_equal(dim(x),c(5,6))
  })
  it('no dose value', {
    testthat::expect_equal(x$`No Dose`,c(0,1,1,0,0))
  })
  it('value', {
    truth <- 
      data %>% 
      dplyr::group_by(STUDY,rndGroup) %>% 
      dplyr::summarise(N=length(unique(ID)), n=n(), BLQ=as.numeric(sum(BLQ)), NODOSE=as.numeric(sum(NODOSE))) %>%
      dplyr::rename(`Study Phase`=STUDY, `Randomization Group`=rndGroup, `No Dose`=NODOSE)

    testthat::expect_equal(x,truth)
  })
  
})

data <- mi210%>%
  dplyr::mutate(BLQ=(DV<=4&DV>0))

set.seed(123)
data$rndGroup <- sample(1:5,size = nrow(data),replace = TRUE)

data$NODOSE <- data$DV==0

labelled::var_label(data$STUDY) <- 'Study Phase'
labelled::var_label(data$rndGroup) <- 'Randomization Group'
labelled::var_label(data$NODOSE) <- 'No Dose'

testthat::describe('warnings',{
  
  it('nonzero EVID warning', {
    expect_warning(data%>%
                     count_tbl(formula = STUDY + rndGroup ~ BLQ[TRUE] + NODOSE[TRUE],returndf = TRUE)
    )
  })

  
})
