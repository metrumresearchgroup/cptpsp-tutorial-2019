testthat::context('NONMEM table')

nbl <- tidynm::nibble(project = system.file('extdata',package = 'tidynm'),
              run = c('510'))

nbl_fixed <- tidynm::nibble(project = system.file('extdata',package = 'tidynm'),
              run = c('510_fixed'))

x_parm <- nbl$PARAMTBL[[1]]

x_base <- x_parm %>% nm_tbl(returndf = TRUE)

testthat::describe('invalid input',{
  
  it('input non nibble', {
      testthat::expect_error(nm_tab(mtcars))
    })
  
})

testthat::describe('default nm_tbl',{
 
  it('class', {
      testthat::expect_s3_class(x_base,'data.frame')
    })
  it('dimension', {
      testthat::expect_equal(dim(x_base),c(12,7))
    })
  
})

testthat::describe('change confidence interval size',{
  
  x <- x_parm %>% nm_tbl(returndf = TRUE,ConfInt = 0.9)

  a <- eval(parse(text = paste0('c',x[1,4]))) 
  
  b <- eval(parse(text = paste0('c',x_base[1,4])))
  
  it('validate confidence interval', {
    testthat::expect_true((a[1] > b[1]) & (a[2] < b[2]))
  })
    
})

testthat::describe('remove diagonal from covariance matrix',{
  
  x <- x_parm %>% nm_tbl(returndf = TRUE,OffDiagonals = FALSE)
  
  full <- x_base[-9,]
  
  row.names(full) <- 1:nrow(full)
  
  it('validate baseline values', {
    testthat::expect_equal(full,x)
  })
  
})

testthat::describe('remove FIXED attribute',{
  

  x_fixed <- tidynm::nibble(project = system.file('extdata',package = 'tidynm'),
                run = c('510_fixed'))$PARAMTBL[[1]] %>%
    dplyr::mutate(value=ifelse(stringi::stri_trim(LABEL)=="CL", 0, value))
  class(x_fixed) <- c("nibble_param", class(x_fixed))

  x <- x_fixed %>%
    nm_tbl(returndf = TRUE,removeFixed = TRUE)
  
  it('no FIXED counterfactual', {
      testthat::expect_false(any(grepl('Fixed',x$pRSE) & x$Estimate==0))
    })
  
  it('FIXED with non-zero estimates remain',{
    testthat::expect_equal(sum(grepl('Fixed',x$pRSE)),3)
  })
  
})

testthat::describe('LOGD transform',{

  x_log <- x_parm
  x_log[1,'value'] <- log(x_log[1,'value'])
  x_log[1,'LABEL'] <- paste(x_log[1,'LABEL'],"LOGD")
  class(x_log) <- c("nibble_param", class(x_log))
  
  x <- x_log %>%nm_tbl(returndf = TRUE,unTransform = TRUE)
  it('log transform', {
      testthat::expect_equal(as.numeric(signif(x_parm[1,'value'],3)),as.numeric(x[1,'Estimate']))
    })
  
  it('LOGD comment removed', {
    testthat::expect_false(any(grepl("LOGD",x$Parameter)))
  })
  
})

testthat::describe('Boundaries',{
  
  x_bigse <- x_parm %>% 
    dplyr::mutate(
      TYPE=ifelse(TYPE=="[P]", "[A]", TYPE),
      cse=ifelse(PARAM=="OMEGA" & LABEL=="CL", 1, cse)
      )
  
  class(x_bigse) <- c("nibble_param",class(x_bigse))

  x <- nm_tbl(x_bigse, bound=TRUE, returndf = TRUE)
  
  it('Set negative boundary to 0',{
    testthat::expect_equal(grep("(0.00,",x$`CI (95\\%)`,fixed=TRUE), 8)
  })
})

testthat::describe('TYPE [P]',{
  
  x_type <- x_parm
  
  tbl <- x_type%>%nm_tbl(returndf = TRUE)
  
  it('diag Parameter label',{
      testthat::expect_equal(tbl$Parameter[8],'$\\omega_{\\text{CL}}$')
  })
    
  it('diag Units',{
    testthat::expect_equal(tbl$Units[8],'CV \\%')
  })

  it('diag Estimate OMEGA',{
    testthat::expect_equal(tbl$Estimate[8],sig(sqrt( exp(x_type$c[7]^2)-1) * 100))
  })
  
  it('diag Estimate SIGMA',{
    testthat::expect_equal(tbl$Estimate[12],sig(100*x_type$c[10]))
  })

  x_type$TYPE[8] <- '[P]'
  
  it('offdiag Parameter label',{
    testthat::expect_warning(x_type%>%nm_tbl(returndf = TRUE),regexp = 'Lognormal directive')
  })

})

testthat::describe('TYPE [A]',{
  
  x_type <- x_parm
  
  x_type$TYPE[c(7,8)] <- '[A]'
  
  tbl <- x_type%>%nm_tbl(returndf = TRUE)
  
  it('diag Parameter label',{
    testthat::expect_equal(tbl$Parameter[8],'$\\omega_{\\text{CL}}$')
  })
  
  it('diag Units',{
    testthat::expect_equal(tbl$Units[8],'SD')
  })
  
  it('diag Estimate',{
    testthat::expect_equal(tbl$Estimate[8],sig(x_type$c[7]))
  })

  it('offdiag Parameter label',{
    testthat::expect_equal(tbl$Parameter[9],'$\\text{Cor}_{\\text{V}-\\text{CL}}$')
  })
  
  it('offdiag Units',{
    testthat::expect_equal(tbl$Units[9],'r')
  })
  
  it('offdiag Estimate',{
    testthat::expect_equal(tbl$Estimate[9],sig(x_type$c[8]))
  })
  
})

testthat::describe('TYPE [R]',{
  
  x_type <- x_parm
  
  x_type$TYPE[c(7,8)] <- '[R]'
  
  tbl <- x_type%>%nm_tbl(returndf = TRUE)
  
  it('diag Parameter label',{
    testthat::expect_equal(tbl$Parameter[8],'$\\omega_{\\text{CL}}$')
  })
  
  it('diag Units',{
    testthat::expect_equal(tbl$Units[8],'SD')
  })
  
  it('diag Estimate',{
    testthat::expect_equal(tbl$Estimate[8],sig(x_type$c[7]))
  })
  
  it('offdiag Parameter label',{
    testthat::expect_equal(tbl$Parameter[9],'$\\text{Cor}_{\\text{V}-\\text{CL}}$')
  })
  
  it('offdiag Units',{
    testthat::expect_equal(tbl$Units[9],'r')
  })
  
  it('offdiag Estimate',{
    testthat::expect_equal(tbl$Estimate[9],sig(x_type$c[8]))
  })
  
})

testthat::describe('TYPE [C]',{
  
  x_type <- x_parm
  
  x_type$TYPE[c(7,8)] <- '[C]'
  
  tbl <- x_type%>%nm_tbl(returndf = TRUE)
  
  it('diag Parameter label',{
    testthat::expect_equal(tbl$Parameter[8],'$\\omega_{\\text{CL}}$')
  })
  
  it('diag Units',{
    testthat::expect_equal(tbl$Units[8],'Var')
  })
  
  it('diag Estimate',{
    testthat::expect_equal(tbl$Estimate[8],sig(x_type$value[7]))
  })
  
  it('offdiag Parameter label',{
    testthat::expect_equal(tbl$Parameter[9],'$\\omega_{\\text{CL-V}}$')
  })
  
  it('offdiag Units',{
    testthat::expect_equal(tbl$Units[9],'Cov')
  })
  
  it('offdiag Estimate',{
    testthat::expect_equal(tbl$Estimate[9],sig(x_type$value[8]))
  })
  
})
