testthat::context('General')

testthat::describe('significant digits', {
  
      it('default',{
       testthat::expect_equal(nchar(mrgtable:::sig(.56789)),5)
      })
  
      it('digits',{
        testthat::expect_equal(nchar(mrgtable:::sig(.56789,2)),4)
      })
      
      it('max exponent',{
        testthat::expect_equal(nchar(mrgtable:::sig(-0.56789^10,dig = 2,maxex = 2)),7)
      })
      
})

testthat::describe('latex utilites',{
  it('tabular colwidth',{
    testthat::expect_message(mrgtable::tabular(head(iris,5),colwidth=c(2)),regexp = 'coerced')
  })
})

testthat::describe('layout', {
  it('categorical wide',{
    testthat::expect_s3_class(mi210%>%
                                cat_tbl(
                                  formula  = STUDY ~ CLCRF,
                                  idVar    = "ID",
                                  total = FALSE,
                                  returndf = TRUE
                                ),
                              'data.frame')
  })
  it('categorical long',{
    testthat::expect_s3_class(mi210%>%
                                cat_tbl(
                                  formula  = STUDY ~ CLCRF,
                                  idVar    = "ID",
                                  wide = FALSE,
                                  total = FALSE,
                                  returndf = TRUE
                                ),
                              'data.frame')
  })
  
  it('continuous wide',{
      testthat::expect_s3_class(mi210%>%
                                  cont_tbl(
                                    formula  = STUDY ~ AGE + HT + WT | SEX,
                                    idVar    ='ID',
                                    returndf = TRUE),
                                'data.frame')
    })
  it('continuous long',{
    testthat::expect_s3_class(mi210%>%
                                cont_tbl(
                                  formula  = STUDY ~ AGE + HT + WT | SEX,
                                  idVar    ='ID',
                                  wide = FALSE,
                                  returndf = TRUE),
                              'data.frame')
  })
})


testthat::describe('yml', {

  file.remove(here::here('_mrgconfig.yml'))
  
  file.rename(here::here('.Rbuildignore'),here::here('.RbuildignoreOld'))  
  
  mrgtable::create_yml()

  it('yml exists',{
    testthat::expect_true(file.exists(here::here('_mrgconfig.yml')))
  })
    
  
  file.rename(here::here('.RbuildignoreOld'),here::here('.Rbuildignore'))

})