testthat::context("Output objects")

library(texPreview)

mrgtable_opts$restore()
tex_opts$restore()

mrgtable_opts$set(list(returnType="viewer", objPath=file.path(tempdir(),'testtex')))
tex_opts$set(list(imgFormat='svg'))

testthat::describe('tex path warning',{

  it('redirecting to working directory', {
    
        testthat::skip_on_travis()
    
        testthat::expect_warning(
          mi210%>%
          cont_tbl(formula = STUDY ~ AGE + HT + WT | SEX,
                   idVar   = 'ID',
                   stem    = 'textest')
          )
    })
  
  file.remove('textest.tex')
  file.remove('textest.svg')

})

mrgtable_opts$set(list(returnType="html", objPath=tempdir()))
tex_opts$set(list(imgFormat='png'))

testthat::describe('html output',{

  it('create magick image for html', {
    
        testthat::skip_on_travis()

        obj <- mi210%>%
          cont_tbl(
            formula = STUDY ~ AGE + HT + WT | SEX,
            idVar   = 'ID',
            stem    = 'textest'
            )
        
        testthat::expect_true(inherits(obj,"magick-image"))
  })

})

mrgtable_opts$set(list(objPath=tempdir()))
tex_opts$set(list(imgFormat='svg'))

# mrgtable_opts$set(list(objPath='tests/bench_figs/cont_tbl')) #create benchmarks

testthat::describe('wide continuous table',{
  
  base_cont_tbl <- mi210%>%
    cont_tbl(formula = STUDY ~ AGE + HT + WT | SEX,
             idVar   = 'ID',
             stem = 'default-cont_tbl_wide')
  
  this_fig <- 
    file.path(tempdir(),'default-cont_tbl_wide.svg')%>%
    readLines()%>%
    paste0(collapse = '\n')%>%
    xml2::read_xml()
  
  benchmark_fig <- 
    file.path('../bench_figs/cont_tbl/default-cont_tbl_wide.svg')%>%
    readLines()%>%
    paste0(collapse = '\n')%>%
    xml2::read_xml()
  
  it('validate benchmark', {
    testthat::expect_equivalent(this_fig,benchmark_fig)
  })

})

testthat::describe('continuous table long',{
  
  base_cont_tbl <- mi210%>%
    cont_tbl(formula = STUDY ~ AGE + HT + WT | SEX,
             idVar   = 'ID',
             wide = FALSE,
             stem = 'default-cont_tbl_long')
  
  this_fig <- 
    file.path(tempdir(),'default-cont_tbl_long.svg')%>%
    readLines()%>%
    paste0(collapse = '\n')%>%
    xml2::read_xml()
  
  benchmark_fig <- 
    file.path('../bench_figs/cont_tbl/default-cont_tbl_long.svg')%>%
    readLines()%>%
    paste0(collapse = '\n')%>%
    xml2::read_xml()
  
  it('validate benchmark', {
    testthat::expect_equivalent(this_fig,benchmark_fig)
  })

})

# mrgtable_opts$set(list(objPath='tests/bench_figs/cat_tbl')) #create benchmarks

testthat::describe('categorical table wide',{
  
  base_cat_tbl <- cat_tbl(formula=STUDY~SEX|CLCRF,idVar="ID",
                          data=mi210,
                          stem='default-cat_tbl_wide')
  
  this_fig <- 
    file.path(tempdir(),'default-cat_tbl_wide.svg')%>%
    readLines()%>%
    paste0(collapse = '\n')%>%
    xml2::read_xml()
  
  benchmark_fig <- 
    file.path('../bench_figs/cat_tbl/default-cat_tbl_wide.svg')%>%
    readLines()%>%
    paste0(collapse = '\n')%>%
    xml2::read_xml()
  
  it('validate benchmark', {
      testthat::expect_equivalent(this_fig,benchmark_fig)
  })
  
  #this_tex <- readLines(file.path(tempdir(),'default-cat_tbl.tex'))  
  #benchmark_tex <- readLines('../figs/cat_tbl/default-cat_tbl.tex')
  #expect_equivalent(this_tex,benchmark_tex)
  
})

testthat::describe('categorical table long',{
  
  base_cat_tbl <- cat_tbl(formula=STUDY~SEX|CLCRF,idVar="ID",
                          data=mi210,
                          wide = FALSE,
                          stem='default-cat_tbl_long')
  
  this_fig <- 
    file.path(tempdir(),'default-cat_tbl_long.svg')%>%
    readLines()%>%
    paste0(collapse = '\n')%>%
    xml2::read_xml()
  
  benchmark_fig <- 
    file.path('../bench_figs/cat_tbl/default-cat_tbl_long.svg')%>%
    readLines()%>%
    paste0(collapse = '\n')%>%
    xml2::read_xml()
  
  it('validate benchmark', {
      testthat::expect_equivalent(this_fig,benchmark_fig)
  })

})

# mrgtable_opts$set(list(objPath='tests/bench_figs/count_tbl')) #create benchmarks

data(mi210)

data <- mi210%>%
  dplyr::filter(EVID==0)%>%
  dplyr::mutate(BLQ=(DV<=4&DV>0))

set.seed(123)
data$rndGroup <- sample(1:5,size = nrow(data),replace = TRUE)

data$NODOSE <- data$DV==0

labelled::var_label(data$STUDY) <- 'Study Phase'
labelled::var_label(data$rndGroup) <- 'Randomization Group'
labelled::var_label(data$NODOSE) <- 'No Dose'

testthat::describe('count table',{
  
  base_count_tbl <- data%>%
    count_tbl(formula = STUDY + rndGroup ~ BLQ[TRUE] + NODOSE[TRUE],stem = 'default-count_tbl')
  
  this_fig <- 
    file.path(tempdir(),'default-count_tbl.svg')%>%
    readLines()%>%
    paste0(collapse = '\n')%>%
    xml2::read_xml()
  
  benchmark_fig <- 
    file.path('../bench_figs/count_tbl/default-count_tbl.svg')%>%
    readLines()%>%
    paste0(collapse = '\n')%>%
    xml2::read_xml()
  
  it('validate benchmark', {
      testthat::expect_equivalent(this_fig,benchmark_fig)
  })
  
})

# mrgtable_opts$set(list(objPath='tests/bench_figs/nm_tbl')) #create benchmarks

nbl <- tidynm::nibble(project = system.file('extdata',package = 'tidynm'),
              run = c('510'))

testthat::describe('NONMEM table',{
  
  base_nm_tbl <- nbl$PARAMTBL[[1]]%>%
    nm_tbl(stem='default-nm_tbl')
  
  this_fig <- 
    file.path(tempdir(),'default-nm_tbl.svg')%>%
    readLines()%>%
    paste0(collapse = '\n')%>%
    xml2::read_xml()
  
  benchmark_fig <- 
    file.path('../bench_figs/nm_tbl/default-nm_tbl.svg')%>%
    readLines()%>%
    paste0(collapse = '\n')%>%
    xml2::read_xml()
  
  it('validate benchmark', {
      testthat::expect_equivalent(this_fig,benchmark_fig)
  })
  
})

mrgtable_opts$restore()
tex_opts$restore()

testthat::describe('test defaults',{
  it('output class', {
      testthat::expect_is(mrgtable:::new_defaults(),'list')
    })
})

testthat::describe('categorical table data.frame output',{
  
  x <- mi210%>%
    cat_tbl(
      formula  = STUDY ~ CLCRF,
      idVar    = "ID",
      returndf = TRUE
    )
  
  it('class', {
    testthat::expect_s3_class(x,'data.frame')
  })
  
})


testthat::describe('continuous table data.frame output',{
  
  x <- mi210%>%
    cont_tbl(
      formula  = STUDY ~ AGE + HT + WT | SEX,
      idVar    ='ID',
      returndf = TRUE)
  
  
  it('class', {
    testthat::expect_s3_class(x,'data.frame')
  })
  
})

testthat::describe('count table data.frame output',{
  
  x <- mi210%>%
    cont_tbl(
      formula  = STUDY ~ AGE + HT + WT | SEX,
      idVar    ='ID',
      returndf = TRUE)
  
  
  it('class', {
    testthat::expect_s3_class(x,'data.frame')
  })
  
})

testthat::describe('NONMEM table data.frame output',{
  
  nbl <- tidynm::nibble(project = system.file('extdata',package = 'tidynm'),
                run = c('510'))
  
  x <- nbl$PARAMTBL[[1]]%>%nm_tbl(returndf = TRUE)
  
  
  it('class', {
    testthat::expect_s3_class(x,'data.frame')
  })
  
})

