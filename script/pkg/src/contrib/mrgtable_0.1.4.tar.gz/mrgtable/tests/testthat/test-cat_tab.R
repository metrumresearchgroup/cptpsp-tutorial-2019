testthat::context('Categorical table')

data("mi210")

testthat::describe('wide table with stratification and marginal totals',{
  
  x <- mi210%>%
    cat_tbl(
      formula  = STUDY ~ CLCRF | SEX,
      idVar    = "ID",
      returndf = TRUE
    )
  
  it('class', {
    testthat::expect_s3_class(x,'tbl_df')
  })
  it('dimension', {
    testthat::expect_equal(dim(x),c(5,3))
  })
  it('value', {
    truth <- mi210 %>% 
      dplyr::group_by(STUDY,SEX, CLCRF) %>% 
      dplyr::count()
    
    truth_total <- truth %>% 
      dplyr::group_by(CLCRF) %>% 
      dplyr::summarise(total=sum(n))
    
    testthat::expect_equal(x[2,] %>% as.character, 
                           c("Study 1", truth$n[1:2] %>% as.character))
    testthat::expect_equal(x[3,] %>% as.character, 
                           c("Study 1", truth$n[3:4] %>% as.character))
    testthat::expect_equal(x[4,] %>% as.character, 
                           c("(Total)", truth_total$total %>% as.character))
    testthat::expect_equal(x[5,] %>% as.character, 
                           c("(Percent)", as.character(mrgtable:::sig(truth_total$total/sum(truth_total$total)*100),3)))
  })
  
})

testthat::describe('long table with no marginal totals',{
  
  x <- mi210%>%
    cat_tbl(
      formula  = STUDY ~ CLCRF,
      idVar    = "ID",
      wide = FALSE,
      total = FALSE,
      returndf = TRUE
    )
  
  it('class', {
    testthat::expect_s3_class(x,'tbl_df')
  })
  it('dimension', {
    testthat::expect_equal(dim(x),c(2,4))
  })
  it('value', {
    truth <- mi210 %>% 
      dplyr::group_by(STUDY,CLCRF) %>% 
      dplyr::count() %>% 
      dplyr::ungroup() %>%
      dplyr::rename(whole=n, Category=CLCRF) %>%
      dplyr::mutate(Category=as.character(Category),
                    whole=as.character(whole)) 
    testthat::expect_equal(x %>% dplyr::select(-Variable), truth)
  })
  
})

testthat::describe('long table with no stratification',{
  
  x <- mi210%>%
    cat_tbl(
      formula  = STUDY ~ CLCRF,
      idVar    = "ID",
      wide = FALSE,
      returndf = TRUE
    )
  
  it('class', {
    testthat::expect_is(x,'list')
  })
  
  it('dimension', {
    testthat::expect_equal(dim(x[[1]]),c(2,4))
    testthat::expect_equal(dim(x[[2]]),c(2,3))
  })
  
  it('value', {
    truth_ltab <- mi210 %>% 
      dplyr::group_by(STUDY,CLCRF) %>% 
      dplyr::count() %>% 
      dplyr::ungroup() %>%
      dplyr::rename(whole=n, Category=CLCRF) %>%
      dplyr::mutate(
        Category=as.character(Category),
        whole=as.character(whole)
      ) 
    
    truth_ltab_total <- 
      mi210 %>% 
      dplyr::group_by(CLCRF) %>% 
      dplyr::count() %>% 
      dplyr::ungroup() %>%
      dplyr::mutate(
        Category=as.character(CLCRF),
        perc = mrgtable:::sig(n/sum(n)*100, dig=3),
        Total = paste(n, perc)
      )%>%
      dplyr::select(-n, -CLCRF, -perc)
    
    testthat::expect_equal(x$ltab %>% dplyr::select(-Variable), truth_ltab)
    testthat::expect_equal(x$ltab_total %>% dplyr::select(-Variable), truth_ltab_total)
  })
  
})

testthat::describe('long table with stratification',{
  
  x <- mi210%>%
    cat_tbl(
      formula  = STUDY ~ CLCRF | SEX,
      idVar    = "ID",
      returndf = TRUE,
      wide=FALSE
    )
  
  it('class', {
    testthat::expect_is(x,'list')
  })
  
  it('dimension', {
    testthat::expect_equal(dim(x[[1]]),c(2,5))
    testthat::expect_equal(dim(x[[2]]),c(2,4))
  })
  it('value', {
    truth_ltab <- mi210 %>% 
      dplyr::group_by(STUDY,SEX,CLCRF) %>% 
      dplyr::count() %>% 
      tidyr::spread(SEX,n) %>%
      dplyr::ungroup() %>%
      dplyr::rename(Category=CLCRF) %>%
      dplyr::mutate_all(.funs=as.character)
    
    truth_ltab_total <- 
      mi210 %>% 
      dplyr::group_by(CLCRF) %>% 
      dplyr::count() %>% 
      dplyr::ungroup() %>%
      dplyr::mutate(
        Category=as.character(CLCRF),
        perc=mrgtable:::sig(n/sum(n)*100, dig=3),
        Total = paste(n, perc)) %>%
      dplyr::select(-n, -CLCRF, -perc)
    testthat::expect_equal(x$ltab %>% dplyr::select(-Variable), truth_ltab)
    testthat::expect_equal(x$ltab_total %>% dplyr::select(Category,Total), truth_ltab_total)
  })
})

testthat::describe('counts are not rounded',{
  data <- data.frame(ID = 1, VAR = rnorm(100103), STUDY = "A", REG="IV")
  x <- cat_tbl(data, STUDY~REG, returndf = TRUE)
  
  it('check value',{
    testthat::expect_equal(x$REG_IV,c("IV",     "100103", "100103", "100"))
  })
})

