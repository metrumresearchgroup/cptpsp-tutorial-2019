testthat::context('Continuous table')

testthat::describe('wide tables',{
  
  x <- mi210%>%
    cont_tbl(
      formula  = STUDY ~ AGE + HT + WT | SEX,
      idVar    ='ID',
      returndf = TRUE)
  
  thruth_1 <- mi210%>%
    dplyr::filter(SEX==0)%>%
    dplyr::summarise(N = as.integer(n()), 
                     AGE = sprintf('%s (%s) [%s - %s]',
                                   mrgtable:::sig(mean(AGE),3),
                                   mrgtable:::sig(sd(AGE),3),
                                   mrgtable:::sig(min(AGE),3),
                                   mrgtable:::sig(max(AGE),3)
                     )
    )
  
  it('class', {
    testthat::expect_s3_class(x,'data.frame')
  })
  it('dimension', {
    testthat::expect_equal(dim(x),c(3,6))
  })
  it('value',{
    testthat::expect_equal(x$N[1],thruth_1$N[1])
    testthat::expect_equal(x$AGE[1],thruth_1$AGE[1])
  })
  
  x1 <- mi210%>%
    cont_tbl(
      formula  = STUDY ~ AGE + HT + WT | SEX,
      idVar    ='ID',
      N = FALSE,
      returndf = TRUE)
  
  it('no N', {
    testthat::expect_false('N'%in%names(x1))
  })
  
  x2 <- mi210%>%
    cont_tbl(
      formula  = STUDY ~ AGE + HT + WT | SEX,
      idVar    ='ID',
      template = '{length} [{min} - {max}]',
      N = FALSE,
      returndf = TRUE)
  
  thruth_2 <- mi210%>%
    dplyr::filter(SEX==0)%>%
    dplyr::summarise(AGE = sprintf('%s [%s - %s]',
                                   mrgtable:::sig(length(AGE),3),
                                   mrgtable:::sig(min(AGE),3),
                                   mrgtable:::sig(max(AGE),3)
    )
    )
  
  it('summary statistic template', {
    testthat::expect_equal(x2$AGE[1],thruth_2$AGE[1])
  })
})

testthat::describe('long tables',{
  
  x <- mi210%>%
    cont_tbl(formula  = STUDY ~ AGE + HT + WT | SEX,
             idVar    = 'ID',
             wide     = FALSE,
             returndf = TRUE)
  
  thruth_1 <- mi210%>%
    dplyr::filter(SEX==0)%>%
    dplyr::summarise(N = as.integer(n()), 
                     AGE = sprintf('%s (%s) [%s - %s]',
                                   mrgtable:::sig(round(mean(AGE),1),3),
                                   mrgtable:::sig(round(sd(AGE),2),3),
                                   mrgtable:::sig(min(AGE),3),
                                   mrgtable:::sig(max(AGE),3)
                     )
    )
  
  it('class', {
    testthat::expect_is(x,'data.frame')
  })
  it('dimension', {
    testthat::expect_equal(dim(x),c(9,6))
  })
  it('value',{
    testthat::expect_equal(x$N[1],thruth_1$N[1])
    testthat::expect_equal(x$Summary[1],thruth_1$AGE[1])
  })
})

testthat::describe('wide no stratification',{
  
  x <- mi210%>%
    cont_tbl(formula  = STUDY ~ AGE + HT + WT,
             idVar    = 'ID',
             returndf = TRUE)
  
  thruth_3 <- mi210%>%
    dplyr::summarise(N = as.integer(n()), 
                     AGE = sprintf('%s (%s) [%s - %s]',
                                   mrgtable:::sig(round(mean(AGE),1),3),
                                   mrgtable:::sig(round(sd(AGE),2),3),
                                   mrgtable:::sig(min(AGE),3),
                                   mrgtable:::sig(max(AGE),3)
                     ))
  
  it('class', {
    testthat::expect_is(x,'data.frame')
  })
  it('dimension', {
    testthat::expect_equal(dim(x),c(2,6))
  })
  it('value',{
    testthat::expect_equal(x$N[1],thruth_3$N[1])
    testthat::expect_equal(x$AGE[1],thruth_3$AGE[1])
  })
})

testthat::describe('long no stratification',{
  
  x <- mi210%>%
    cont_tbl(formula  = STUDY ~ AGE + HT + WT,
             idVar    = 'ID',
             wide = FALSE,
             returndf = TRUE)
  
  thruth_4 <- mi210%>%
    dplyr::summarise(N = as.integer(n()), 
                     AGE = sprintf('%s (%s) [%s - %s]',
                                   mrgtable:::sig(mean(AGE),3),
                                   mrgtable:::sig(sd(AGE),3),
                                   mrgtable:::sig(min(AGE),3),
                                   mrgtable:::sig(max(AGE),3)
                     ))
  
  it('class', {
    testthat::expect_is(x,'data.frame')
  })
  it('dimension', {
    testthat::expect_equal(dim(x),c(6,5))
  })
  it('value',{
    testthat::expect_equal(x$N[1],thruth_4$N[1])
    testthat::expect_equal(x$Summary[1],thruth_4$AGE[1])
  })
})

testthat::describe('user supplied summary statistics',{
  suppressWarnings(rm("ub","lb"))

  
  x <- mi210%>%
    cont_tbl(formula  = STUDY~AGE+HT+WT|SEX,
             idVar    = 'ID',
             template = '{mean} <{sd}> {{{lb} - {ub}}}',
             returndf = TRUE)
  
  alpha_c <- stats::qnorm(0.05/2 , lower.tail = FALSE)
  
  thruth_5 <- mi210%>%
    dplyr::group_by(SEX)%>%
    dplyr::summarise(N = as.integer(n()), 
                     MEAN = mean(AGE),
                     SD   = sd(AGE)
    )%>%
    dplyr::mutate(lb = MEAN - alpha_c*SD,
                  ub = MEAN + alpha_c*SD) %>%
    dplyr::mutate_at(dplyr::vars(MEAN,SD,lb,ub), mrgtable:::sig, dig=3) %>%
    dplyr::mutate(AGE = sprintf('%s <%s> {%s - %s}',MEAN,SD,lb,ub))


  it('dimension', {
    testthat::expect_equal(sum(grepl('}',x$AGE)),3)
  })
  it('value',{
    testthat::expect_equal(x$N[1],thruth_5$N[1])
    testthat::expect_equal(x$AGE[1],thruth_5$AGE[1])
  })

  
})

testthat::describe("integers are not rounded",{
  data <- data.frame(ID = 1, VAR = rnorm(100103), STUDY = "A")
  x <- cont_tbl(data, STUDY~VAR, returndf=TRUE)
  it('check value',{
    testthat::expect_true(all(x$N==100103))
  }
  )
})