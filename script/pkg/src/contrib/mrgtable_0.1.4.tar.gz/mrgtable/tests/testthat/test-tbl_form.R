testthat::context('Table formula input')

data("mi210")

testthat::describe('single category no stratification',{
  
  x <- mi210%>%
    tbl_form(formula = STUDY ~ CLCRF ,
             idVar="ID")
  
  
  it('class', {
    testthat::expect_is(x,'list')
    })
  
  it('variable names', {
    testthat::expect_equal(x$grp,'STUDY')
    testthat::expect_equal(x$cats,c('CLCRF'))
    testthat::expect_equal(x$strat,c('whole'))
  })
  
  it('variable labels', {
    testthat::expect_equal(x$grplabs,'STUDY')
    testthat::expect_equal(x$catlabs,c('CLCRF'))
    testthat::expect_equal(x$stratlabs,c(''))
  })
})

testthat::describe('multiple categories no stratification',{
  x <- mi210%>%
    tbl_form(formula = STUDY ~ CLCRF + SEX ,
             idVar="ID")
  
  it('variable names', {
      testthat::expect_equal(x$cats,c('CLCRF','SEX'))
    })
  it('variable labels', {
      testthat::expect_equal(x$catlabs,c('CLCRF','SEX'))
    })
})

testthat::describe('single category with stratification',{
  x <- mi210%>%
    tbl_form(formula = STUDY ~ CLCRF | SEX ,
             idVar="ID")
  
  it('variable names', {
    testthat::expect_equal(x$cats,c('CLCRF'))
    testthat::expect_equal(x$strat,c('SEX'))
  })
  
  it('variable labels', {
    testthat::expect_equal(x$catlabs,c('CLCRF'))
    testthat::expect_equal(x$stratlabs,c('SEX'))
  })
})

testthat::describe('parameter labels',{
  
  labelled::var_label(mi210$STUDY) <- 'x'
  labelled::var_label(mi210$CLCRF) <- 'Clearance'
  
  x <- mi210%>%tbl_form(formula = STUDY ~ CLCRF , idVar="ID")
  
  it('labels for group and category', {
    testthat::expect_equal(x$grplabs,'x')
    testthat::expect_equal(x$catlabs,c('Clearance'))
  })
  
})

testthat::describe('parameter labels with underscores',{
  
  labelled::var_label(mi210$STUDY) <- 'x_y'
  labelled::var_label(mi210$CLCRF) <- 'Clear_ance'
  
  x <- mi210%>%tbl_form(formula = STUDY ~ CLCRF , idVar="ID")
  
  it('labels for group and category', {
    testthat::expect_equal(x$grplabs,'x_y')
    testthat::expect_equal(x$catlabs,c('Clear_ance'))
  })
  
})

testthat::describe('partial parameter labels',{  
  
  labelled::var_label(mi210$STUDY) <- 'x'
  
  x <- mi210%>%
    tbl_form(formula = STUDY ~ CLCRF ,
             idVar="ID")
  
  it('labels for group only', {
    testthat::expect_equal(x$grplabs,'x')
  })
})

testthat::describe('invalid object names',{
  
  mi210_test <- mi210
  
  names(mi210_test)[22] <- 'variable'
  
  x <- mi210_test%>%tbl_form(formula = STUDY ~ variable ,
                             idVar="ID")
  
  it("variable name is 'variable'", {
      testthat::expect_equal(x$cats,c('variable__'))
    })
  
})

testthat::describe('ungrouping input data',{
  it('message for intervention',{
    testthat::expect_message(mi210%>%
      dplyr::group_by(SEX)%>%
      cat_tbl(formula = STUDY~CLCRF+SEX,
              idVar="ID",returndf = TRUE),
      'input data is grouped ... ungrouping')
  })
})