Tests and Coverage
================
30 November, 2018 11:49:51

This output is created by
[covrpage](https://github.com/yonicd/covrpage).

## Coverage

Coverage summary is created using the
[covr](https://github.com/r-lib/covr) package.

| Object                                     | Coverage (%) |
| :----------------------------------------- | :----------: |
| mrgtable                                   |    68.22     |
| [R/opts\_complete.R](../R/opts_complete.R) |     0.00     |
| [R/utils\_Hmisc.R](../R/utils_Hmisc.R)     |    23.72     |
| [R/utils\_latex.R](../R/utils_latex.R)     |    44.03     |
| [R/opts.R](../R/opts.R)                    |    44.74     |
| [R/zzz.R](../R/zzz.R)                      |    50.00     |
| [R/utils.R](../R/utils.R)                  |    74.19     |
| [R/utils\_format.R](../R/utils_format.R)   |    78.26     |
| [R/nm\_tbl.R](../R/nm_tbl.R)               |    88.89     |
| [R/nm\_create.R](../R/nm_create.R)         |    91.09     |
| [R/mrg\_footnote.R](../R/mrg_footnote.R)   |    92.86     |
| [R/preview\_tex.R](../R/preview_tex.R)     |    96.00     |
| [R/cat\_tbl.R](../R/cat_tbl.R)             |    96.43     |
| [R/cont\_tbl.R](../R/cont_tbl.R)           |    98.08     |
| [R/nm\_format.R](../R/nm_format.R)         |    98.33     |
| [R/count\_tbl.R](../R/count_tbl.R)         |    98.41     |
| [R/cat\_whole.R](../R/cat_whole.R)         |    98.55     |
| [R/cat\_long.R](../R/cat_long.R)           |    100.00    |
| [R/cat\_wide.R](../R/cat_wide.R)           |    100.00    |
| [R/create\_yml.R](../R/create_yml.R)       |    100.00    |
| [R/nm\_tex.R](../R/nm_tex.R)               |    100.00    |
| [R/tbl\_form.R](../R/tbl_form.R)           |    100.00    |

<br>

## Unit Tests

Unit Test summary is created using the
[testthat](https://github.com/r-lib/testthat)
package.

| file                                           |  n |  time | error | failed | skipped | warning |
| :--------------------------------------------- | -: | ----: | ----: | -----: | ------: | ------: |
| [test-cat\_tab.R](testthat/test-cat_tab.R)     | 20 | 0.081 |     0 |      0 |       0 |       0 |
| [test-cont\_tab.R](testthat/test-cont_tab.R)   | 22 | 0.031 |     0 |      0 |       0 |       0 |
| [test-count\_tab.R](testthat/test-count_tab.R) |  5 | 0.116 |     0 |      0 |       0 |       0 |
| [test-general.R](testthat/test-general.R)      |  8 | 1.375 |     0 |      0 |       0 |       0 |
| [test-input.R](testthat/test-input.R)          |  4 | 0.030 |     0 |      0 |       0 |       0 |
| [test-nm\_tab.R](testthat/test-nm_tab.R)       | 33 | 0.124 |     0 |      0 |       0 |       0 |
| [test-output.R](testthat/test-output.R)        | 13 | 2.670 |     0 |      0 |       0 |       0 |
| [test-tbl\_form.R](testthat/test-tbl_form.R)   | 20 | 0.082 |     0 |      0 |       0 |       0 |

<details closed>

<summary> Show Detailed Test Results
</summary>

| file                                                   | context             | test                                                             | status | n |  time |
| :----------------------------------------------------- | :------------------ | :--------------------------------------------------------------- | :----- | -: | ----: |
| [test-cat\_tab.R](testthat/test-cat_tab.R#L15)         | Categorical table   | wide table with stratification and marginal totals: class        | PASS   | 1 | 0.010 |
| [test-cat\_tab.R](testthat/test-cat_tab.R#L18)         | Categorical table   | wide table with stratification and marginal totals: dimension    | PASS   | 1 | 0.004 |
| [test-cat\_tab.R](testthat/test-cat_tab.R#L29_L30)     | Categorical table   | wide table with stratification and marginal totals: value        | PASS   | 4 | 0.011 |
| [test-cat\_tab.R](testthat/test-cat_tab.R#L53)         | Categorical table   | long table with no marginal totals: class                        | PASS   | 1 | 0.001 |
| [test-cat\_tab.R](testthat/test-cat_tab.R#L56)         | Categorical table   | long table with no marginal totals: dimension                    | PASS   | 1 | 0.001 |
| [test-cat\_tab.R](testthat/test-cat_tab.R#L66)         | Categorical table   | long table with no marginal totals: value                        | PASS   | 1 | 0.010 |
| [test-cat\_tab.R](testthat/test-cat_tab.R#L82)         | Categorical table   | long table with no stratification: class                         | PASS   | 1 | 0.001 |
| [test-cat\_tab.R](testthat/test-cat_tab.R#L86)         | Categorical table   | long table with no stratification: dimension                     | PASS   | 2 | 0.002 |
| [test-cat\_tab.R](testthat/test-cat_tab.R#L113)        | Categorical table   | long table with no stratification: value                         | PASS   | 2 | 0.015 |
| [test-cat\_tab.R](testthat/test-cat_tab.R#L130)        | Categorical table   | long table with stratification: class                            | PASS   | 1 | 0.002 |
| [test-cat\_tab.R](testthat/test-cat_tab.R#L134)        | Categorical table   | long table with stratification: dimension                        | PASS   | 2 | 0.003 |
| [test-cat\_tab.R](testthat/test-cat_tab.R#L156)        | Categorical table   | long table with stratification: value                            | PASS   | 2 | 0.020 |
| [test-cat\_tab.R](testthat/test-cat_tab.R#L166)        | Categorical table   | counts are not rounded: check value                              | PASS   | 1 | 0.001 |
| [test-cont\_tab.R](testthat/test-cont_tab.R#L23)       | Continuous table    | wide tables: class                                               | PASS   | 1 | 0.002 |
| [test-cont\_tab.R](testthat/test-cont_tab.R#L26)       | Continuous table    | wide tables: dimension                                           | PASS   | 1 | 0.001 |
| [test-cont\_tab.R](testthat/test-cont_tab.R#L29)       | Continuous table    | wide tables: value                                               | PASS   | 2 | 0.003 |
| [test-cont\_tab.R](testthat/test-cont_tab.R#L41)       | Continuous table    | wide tables: no N                                                | PASS   | 1 | 0.001 |
| [test-cont\_tab.R](testthat/test-cont_tab.R#L62)       | Continuous table    | wide tables: summary statistic template                          | PASS   | 1 | 0.001 |
| [test-cont\_tab.R](testthat/test-cont_tab.R#L86)       | Continuous table    | long tables: class                                               | PASS   | 1 | 0.002 |
| [test-cont\_tab.R](testthat/test-cont_tab.R#L89)       | Continuous table    | long tables: dimension                                           | PASS   | 1 | 0.001 |
| [test-cont\_tab.R](testthat/test-cont_tab.R#L92)       | Continuous table    | long tables: value                                               | PASS   | 2 | 0.004 |
| [test-cont\_tab.R](testthat/test-cont_tab.R#L114)      | Continuous table    | wide no stratification: class                                    | PASS   | 1 | 0.001 |
| [test-cont\_tab.R](testthat/test-cont_tab.R#L117)      | Continuous table    | wide no stratification: dimension                                | PASS   | 1 | 0.001 |
| [test-cont\_tab.R](testthat/test-cont_tab.R#L120)      | Continuous table    | wide no stratification: value                                    | PASS   | 2 | 0.002 |
| [test-cont\_tab.R](testthat/test-cont_tab.R#L143)      | Continuous table    | long no stratification: class                                    | PASS   | 1 | 0.001 |
| [test-cont\_tab.R](testthat/test-cont_tab.R#L146)      | Continuous table    | long no stratification: dimension                                | PASS   | 1 | 0.002 |
| [test-cont\_tab.R](testthat/test-cont_tab.R#L149)      | Continuous table    | long no stratification: value                                    | PASS   | 2 | 0.003 |
| [test-cont\_tab.R](testthat/test-cont_tab.R#L179)      | Continuous table    | user supplied summary statistics: dimension                      | PASS   | 1 | 0.002 |
| [test-cont\_tab.R](testthat/test-cont_tab.R#L182)      | Continuous table    | user supplied summary statistics: value                          | PASS   | 2 | 0.002 |
| [test-cont\_tab.R](testthat/test-cont_tab.R#L193)      | Continuous table    | integers are not rounded: check value                            | PASS   | 1 | 0.002 |
| [test-count\_tab.R](testthat/test-count_tab.R#L25)     | Count table         | count\_tbl: class                                                | PASS   | 1 | 0.001 |
| [test-count\_tab.R](testthat/test-count_tab.R#L28)     | Count table         | count\_tbl: dimension                                            | PASS   | 1 | 0.003 |
| [test-count\_tab.R](testthat/test-count_tab.R#L31)     | Count table         | count\_tbl: no dose value                                        | PASS   | 1 | 0.001 |
| [test-count\_tab.R](testthat/test-count_tab.R#L41)     | Count table         | count\_tbl: value                                                | PASS   | 1 | 0.007 |
| [test-count\_tab.R](testthat/test-count_tab.R#L61_L63) | Count table         | warnings: nonzero EVID warning                                   | PASS   | 1 | 0.104 |
| [test-general.R](testthat/test-general.R#L6)           | General             | significant digits: default                                      | PASS   | 1 | 0.001 |
| [test-general.R](testthat/test-general.R#L10)          | General             | significant digits: digits                                       | PASS   | 1 | 0.001 |
| [test-general.R](testthat/test-general.R#L14)          | General             | significant digits: max exponent                                 | PASS   | 1 | 0.002 |
| [test-general.R](testthat/test-general.R#L21_L28)      | General             | layout: categorical wide                                         | PASS   | 1 | 0.111 |
| [test-general.R](testthat/test-general.R#L31_L39)      | General             | layout: ccategorical long                                        | PASS   | 1 | 0.149 |
| [test-general.R](testthat/test-general.R#L43_L48)      | General             | layout: continuous wide                                          | PASS   | 1 | 0.414 |
| [test-general.R](testthat/test-general.R#L51_L57)      | General             | layout: continuous long                                          | PASS   | 1 | 0.696 |
| [test-general.R](testthat/test-general.R#L71)          | General             | yml: yml exists                                                  | PASS   | 1 | 0.001 |
| [test-input.R](testthat/test-input.R#L6)               | Input objects       | check inherit function: data.frame                               | PASS   | 1 | 0.003 |
| [test-input.R](testthat/test-input.R#L10)              | Input objects       | check inherit function: tbl\_df                                  | PASS   | 1 | 0.023 |
| [test-input.R](testthat/test-input.R#L16)              | Input objects       | check inherit function: nibble                                   | PASS   | 1 | 0.002 |
| [test-input.R](testthat/test-input.R#L20)              | Input objects       | check inherit function: wrong class                              | PASS   | 1 | 0.002 |
| [test-nm\_tab.R](testthat/test-nm_tab.R#L16)           | NONMEM table        | invalid input: input non nibble                                  | PASS   | 1 | 0.020 |
| [test-nm\_tab.R](testthat/test-nm_tab.R#L24)           | NONMEM table        | default nm\_tbl: class                                           | PASS   | 1 | 0.001 |
| [test-nm\_tab.R](testthat/test-nm_tab.R#L27)           | NONMEM table        | default nm\_tbl: dimension                                       | PASS   | 1 | 0.001 |
| [test-nm\_tab.R](testthat/test-nm_tab.R#L41)           | NONMEM table        | change confidence interval size: validate confidence interval    | PASS   | 1 | 0.001 |
| [test-nm\_tab.R](testthat/test-nm_tab.R#L55)           | NONMEM table        | remove diagonal from covariance matrix: validate baseline values | PASS   | 1 | 0.003 |
| [test-nm\_tab.R](testthat/test-nm_tab.R#L72)           | NONMEM table        | remove FIXED attribute: no FIXED counterfactual                  | PASS   | 1 | 0.001 |
| [test-nm\_tab.R](testthat/test-nm_tab.R#L76)           | NONMEM table        | remove FIXED attribute: FIXED with non-zero estimates remain     | PASS   | 1 | 0.002 |
| [test-nm\_tab.R](testthat/test-nm_tab.R#L90)           | NONMEM table        | LOGD transform: log transform                                    | PASS   | 1 | 0.002 |
| [test-nm\_tab.R](testthat/test-nm_tab.R#L94)           | NONMEM table        | LOGD transform: LOGD comment removed                             | PASS   | 1 | 0.001 |
| [test-nm\_tab.R](testthat/test-nm_tab.R#L112)          | NONMEM table        | Boundaries: Set negative boundary to 0                           | PASS   | 1 | 0.002 |
| [test-nm\_tab.R](testthat/test-nm_tab.R#L123)          | NONMEM table        | TYPE \[P\]: diag Parameter label                                 | PASS   | 1 | 0.003 |
| [test-nm\_tab.R](testthat/test-nm_tab.R#L127)          | NONMEM table        | TYPE \[P\]: diag Units                                           | PASS   | 1 | 0.003 |
| [test-nm\_tab.R](testthat/test-nm_tab.R#L131)          | NONMEM table        | TYPE \[P\]: diag Estimate OMEGA                                  | PASS   | 1 | 0.003 |
| [test-nm\_tab.R](testthat/test-nm_tab.R#L135)          | NONMEM table        | TYPE \[P\]: diag Estimate SIGMA                                  | PASS   | 1 | 0.003 |
| [test-nm\_tab.R](testthat/test-nm_tab.R#L141)          | NONMEM table        | TYPE \[P\]: offdiag Parameter label                              | PASS   | 1 | 0.057 |
| [test-nm\_tab.R](testthat/test-nm_tab.R#L155)          | NONMEM table        | TYPE \[A\]: diag Parameter label                                 | PASS   | 1 | 0.001 |
| [test-nm\_tab.R](testthat/test-nm_tab.R#L159)          | NONMEM table        | TYPE \[A\]: diag Units                                           | PASS   | 1 | 0.001 |
| [test-nm\_tab.R](testthat/test-nm_tab.R#L163)          | NONMEM table        | TYPE \[A\]: diag Estimate                                        | PASS   | 1 | 0.002 |
| [test-nm\_tab.R](testthat/test-nm_tab.R#L167)          | NONMEM table        | TYPE \[A\]: offdiag Parameter label                              | PASS   | 1 | 0.001 |
| [test-nm\_tab.R](testthat/test-nm_tab.R#L171)          | NONMEM table        | TYPE \[A\]: offdiag Units                                        | PASS   | 1 | 0.002 |
| [test-nm\_tab.R](testthat/test-nm_tab.R#L175)          | NONMEM table        | TYPE \[A\]: offdiag Estimate                                     | PASS   | 1 | 0.001 |
| [test-nm\_tab.R](testthat/test-nm_tab.R#L189)          | NONMEM table        | TYPE \[R\]: diag Parameter label                                 | PASS   | 1 | 0.001 |
| [test-nm\_tab.R](testthat/test-nm_tab.R#L193)          | NONMEM table        | TYPE \[R\]: diag Units                                           | PASS   | 1 | 0.001 |
| [test-nm\_tab.R](testthat/test-nm_tab.R#L197)          | NONMEM table        | TYPE \[R\]: diag Estimate                                        | PASS   | 1 | 0.001 |
| [test-nm\_tab.R](testthat/test-nm_tab.R#L201)          | NONMEM table        | TYPE \[R\]: offdiag Parameter label                              | PASS   | 1 | 0.001 |
| [test-nm\_tab.R](testthat/test-nm_tab.R#L205)          | NONMEM table        | TYPE \[R\]: offdiag Units                                        | PASS   | 1 | 0.001 |
| [test-nm\_tab.R](testthat/test-nm_tab.R#L209)          | NONMEM table        | TYPE \[R\]: offdiag Estimate                                     | PASS   | 1 | 0.001 |
| [test-nm\_tab.R](testthat/test-nm_tab.R#L223)          | NONMEM table        | TYPE \[C\]: diag Parameter label                                 | PASS   | 1 | 0.001 |
| [test-nm\_tab.R](testthat/test-nm_tab.R#L227)          | NONMEM table        | TYPE \[C\]: diag Units                                           | PASS   | 1 | 0.001 |
| [test-nm\_tab.R](testthat/test-nm_tab.R#L231)          | NONMEM table        | TYPE \[C\]: diag Estimate                                        | PASS   | 1 | 0.002 |
| [test-nm\_tab.R](testthat/test-nm_tab.R#L235)          | NONMEM table        | TYPE \[C\]: offdiag Parameter label                              | PASS   | 1 | 0.001 |
| [test-nm\_tab.R](testthat/test-nm_tab.R#L239)          | NONMEM table        | TYPE \[C\]: offdiag Units                                        | PASS   | 1 | 0.001 |
| [test-nm\_tab.R](testthat/test-nm_tab.R#L243)          | NONMEM table        | TYPE \[C\]: offdiag Estimate                                     | PASS   | 1 | 0.001 |
| [test-output.R](testthat/test-output.R#L17_L22)        | Output objects      | tex path warning: redirecting to working directory               | PASS   | 1 | 1.540 |
| [test-output.R](testthat/test-output.R#L46)            | Output objects      | html output: create magick image for html                        | PASS   | 1 | 1.100 |
| [test-output.R](testthat/test-output.R#L76)            | Output objects      | wide continuous table: validate benchmark                        | PASS   | 1 | 0.002 |
| [test-output.R](testthat/test-output.R#L102)           | Output objects      | continuous table long: validate benchmark                        | PASS   | 1 | 0.003 |
| [test-output.R](testthat/test-output.R#L128)           | Output objects      | categorical table wide: validate benchmark                       | PASS   | 1 | 0.008 |
| [test-output.R](testthat/test-output.R#L157)           | Output objects      | categorical table long: validate benchmark                       | PASS   | 1 | 0.002 |
| [test-output.R](testthat/test-output.R#L197)           | Output objects      | count table: validate benchmark                                  | PASS   | 1 | 0.002 |
| [test-output.R](testthat/test-output.R#L225)           | Output objects      | NONMEM table: validate benchmark                                 | PASS   | 1 | 0.002 |
| [test-output.R](testthat/test-output.R#L235)           | Output objects      | test defaults: output class                                      | PASS   | 1 | 0.002 |
| [test-output.R](testthat/test-output.R#L249)           | Output objects      | categorical table data.frame output: class                       | PASS   | 1 | 0.005 |
| [test-output.R](testthat/test-output.R#L265)           | Output objects      | continuous table data.frame output: class                        | PASS   | 1 | 0.002 |
| [test-output.R](testthat/test-output.R#L280)           | Output objects      | count table data.frame output: class                             | PASS   | 1 | 0.001 |
| [test-output.R](testthat/test-output.R#L294)           | Output objects      | NONMEM table data.frame output: class                            | PASS   | 1 | 0.001 |
| [test-tbl\_form.R](testthat/test-tbl_form.R#L13)       | Table formula input | single category no stratification: class                         | PASS   | 1 | 0.001 |
| [test-tbl\_form.R](testthat/test-tbl_form.R#L17)       | Table formula input | single category no stratification: variable names                | PASS   | 3 | 0.004 |
| [test-tbl\_form.R](testthat/test-tbl_form.R#L23)       | Table formula input | single category no stratification: variable labels               | PASS   | 3 | 0.003 |
| [test-tbl\_form.R](testthat/test-tbl_form.R#L35)       | Table formula input | multiple categories no stratification: variable names            | PASS   | 1 | 0.001 |
| [test-tbl\_form.R](testthat/test-tbl_form.R#L38)       | Table formula input | multiple categories no stratification: variable labels           | PASS   | 1 | 0.002 |
| [test-tbl\_form.R](testthat/test-tbl_form.R#L48)       | Table formula input | single category with stratification: variable names              | PASS   | 2 | 0.002 |
| [test-tbl\_form.R](testthat/test-tbl_form.R#L53)       | Table formula input | single category with stratification: variable labels             | PASS   | 2 | 0.002 |
| [test-tbl\_form.R](testthat/test-tbl_form.R#L66)       | Table formula input | parameter labels: labels for group and category                  | PASS   | 2 | 0.002 |
| [test-tbl\_form.R](testthat/test-tbl_form.R#L80)       | Table formula input | parameter labels with underscores: labels for group and category | PASS   | 2 | 0.002 |
| [test-tbl\_form.R](testthat/test-tbl_form.R#L95)       | Table formula input | partial parameter labels: labels for group only                  | PASS   | 1 | 0.001 |
| [test-tbl\_form.R](testthat/test-tbl_form.R#L109)      | Table formula input | invalid object names: variable name is ‘variable’                | PASS   | 1 | 0.002 |
| [test-tbl\_form.R](testthat/test-tbl_form.R#L116_L120) | Table formula input | ungrouping input data: message for intervention                  | PASS   | 1 | 0.060 |

</details>

<details>

<summary> Session Info </summary>

| Field    | Value                               |
| :------- | :---------------------------------- |
| Version  | R version 3.4.1 (2017-06-30)        |
| Platform | x86\_64-apple-darwin15.6.0 (64-bit) |
| Running  | macOS Sierra 10.12.6                |
| Language | en\_US                              |
| Timezone | America/New\_York                   |

| Package  | Version |
| :------- | :------ |
| testthat | 2.0.1   |
| covr     | 3.2.1   |
| covrpage | 0.0.65  |

</details>

<!--- Final Status : pass --->
