library(testthat)
library(dplyr)
library(mrgtable)
library(rlang)
library(tidynm)
library(texPreview)
library(stringi)


test_check("mrgtable")
