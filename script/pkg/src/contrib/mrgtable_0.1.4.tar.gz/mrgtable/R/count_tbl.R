#' @title Table that depicts the frequency by groups and exclusion criteria
#' @concept table
#' @description Table that depicts the frequency by groups and exclusion criteria
#' @param data data.frame, contains the necessary variables to produce the output (data should be filtered to EVID==0).
#' @param formula formula, formula that is seperated by ~, where the LHS variables convery the grouping (rows) 
#' and the RHS variables convey the Exclusion (columns). eg G1 + G2 ~ E1[E1 REFVALUE] [ + E2[E2 REFVALUE] ] 
#' @param stem character, filename to save output
#' @param idVar character, Column name for ID, Default: 'ID'
#' @param returndf logical, return data.frame instead of tex, Default: FALSE
#' @param table_opts list, named list of arguments to create the table footnote, Default: mrgtable_opts$get(')
#' @param texp_opts named list of parameters to pass to \code{texPreview}, Default: tex_opts$get()
#' @details A frequency table reporting \code{N} patients, \code{n} observations, and the number of those records 
#' that adhere to the reference value indicated for the exclusion columns.  
#' 
#' \code{N} and \code{n} do include the excluded records.
#' 
#' @seealso \code{\link[texPreview]{texPreview}}, \code{\link{mrg_footnote}}
#' @examples
#' 
#' data(mi210)
#' 
#' data <- mi210%>%
#'  dplyr::filter(EVID==0)%>%
#'  dplyr::mutate(BLQ=(DV<=4&DV>0))
#'
#' data$rndGroup <- sample(1:5,size = nrow(data),replace = TRUE)
#'
#' data$NODOSE <- data$DV==0
#'
#' labelled::var_label(data$STUDY) <- 'Study Phase'
#' labelled::var_label(data$rndGroup) <- 'Randomization Group'
#' labelled::var_label(data$NODOSE) <- 'No Dose Given'
#'
#' data%>%
#'  count_tbl(formula = STUDY + rndGroup ~ BLQ[TRUE] + NODOSE[TRUE],returndf = TRUE)
#'
#' data%>%
#'  count_tbl(formula = STUDY + rndGroup ~ .,returndf = TRUE)
#' 
#' @export
#' @import dplyr
#' @importFrom texPreview tex_opts
#' @importFrom tidyr gather spread
#' @importFrom rlang !!! syms
#' @rdname count_tbl
count_tbl <-
  function(data,
           formula = 'STUDY ~ BLQ[TRUE]',
           stem="count_tbl",
           idVar="ID",
           returndf = FALSE,
           table_opts = mrgtable_opts$get(),
           texp_opts = texPreview::tex_opts$get()) {
    
    if ("EVID" %in% names(data)) {
      if (any(as.logical(data$EVID)) != 0) {
        warning("All EVID's should be 0!")
      }
    }
    
    tbl_args <- tbl_form(data, formula, idVar, el_names = c('groupBy','excl_var','stratBy'))

    subData       <- NULL
    grp           <- NULL
    grplabs       <- NULL
    excl_var      <- NULL
    excl_var_labs <- NULL
    excl_flag     <- NULL
    
    list2env(tbl_args,envir = environment())
    
    out <- subData %>%
      dplyr::select(!!!(rlang::syms(c(grp, idVar)))) %>%
      dplyr::distinct() %>%
      dplyr::count(!!!(rlang::syms(grp))) %>%
      dplyr::rename(N = n) %>%
      dplyr::left_join(
        subData %>% 
          dplyr::count(
              !!!(rlang::syms(grp))
            ),
        by = grp)

    if (!any('.'%in%excl_var)) {
      eVal <- dplyr::data_frame(flag = excl_var, value = excl_flag)
      
      suppressWarnings({
        
        excl_data <- subData %>%
          dplyr::select(!!!(rlang::syms(c(grp, excl_var)))) %>%
          tidyr::gather(key = !!(rlang::sym('flag')),
                        value = !!(rlang::sym('value')),
                        gather_cols = !!!(rlang::syms(excl_var)))
        
      })
      
      eOut <- eVal %>%
        dplyr::left_join(excl_data,by = c("flag", "value")) %>%
        dplyr::count(!!!(rlang::syms(c(grp, "flag")))) %>%
        tidyr::spread(key = .data[['flag']], value = .data[["n"]], fill = 0)

      suppressWarnings(
        out <- out %>% 
          dplyr::left_join(
            eOut,
            by = grp)
      )
    }
    names(out)[which(names(out) %in% grp)] <- grplabs

    if (!any('.'%in%excl_var)) {
      names(out)[which(names(out) %in% excl_var)] <- excl_var_labs

      out <- out %>%
        dplyr::mutate_at(
          .vars = dplyr::vars(!!!(rlang::syms(excl_var_labs))),
          .funs = dplyr::funs(`%0%`)
        )
    }

    if(returndf)
      return(out)
    
    tex <- tabular(out,
                   charjust = 'left',
                   numjust = 'center',
                   verbatim = FALSE)

    tex <- tex%>%
      preview_tex(stem = stem,
                  sanitize.math = FALSE,
                  table_opts = table_opts,
                  texp_opts = texp_opts)

    if(table_opts$returnType=='html'){
      tex
    }else{
      return(invisible(tex))
    }
  }
