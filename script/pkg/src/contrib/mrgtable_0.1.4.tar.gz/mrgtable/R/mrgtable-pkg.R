#' @title mrgtable R package
#' 
#' @description The mrgtable package is an R package for creating demographic and NONMEM model summary
#' tables in a reproducible manner.  
#' 
#' @section Tables:
#' 
#' \itemize{
#' \item \code{\link{count_tbl}}: Table that depicts the frequency by groups and exclusion criteria
#' \item \code{\link{cat_tbl}}: Demographics table for categorical
#' variables
#' \item \code{\link{cont_tbl}}: Demographics table for continuous 
#' variables
#' \item \code{\link{nm_tbl}}: NONMEM model summary table
#' }
#' 
#' 
#' @section Utility:
#' 
#' \itemize{
#' \item \code{\link{mrgtable_opts}}: Options for functions in the mrgtable package
#' \item \code{\link{mrg_footnote}}: concatonates a caption to a tex table
#' }
#' 
#' @section Data:
#' 
#' \itemize{
#' \item \code{\link{mi210}}: The data represents a one compartment full model with 
#' IV administration that has been post processed through the TFL generator.
#' }
#' 
#' 
"_PACKAGE"
