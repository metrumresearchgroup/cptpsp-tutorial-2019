#' @title Format paramtbl output
#' @description format parameter table output from tidynm to get it ready for tex
#' @param Out tibble, paramtbl output from tidynm
#' @param Sig numeric , significant digits in table cells, Default: 3
#' @param ConfInt numeric, confidence interval level, Default: 0.95
#' @param removeFixed logical, Remove all fixed values (nonzero) from the output table, Default: FALSE
#' @param OffDiagonals logical, include the off diagonal values in the table presentation, Default: TRUE
#' @return tibble
#' @rdname nm_format
# @export 
#' @import dplyr
nm_format <- function(Out,
                       Sig = 3,
                       ConfInt = 0.95,
                       removeFixed = FALSE, 
                       OffDiagonals = TRUE){


if(!'Variability'%in%names(Out))
  Out$Variability <- ''
    
Out <- Out%>%
  dplyr::mutate(
    #Format Labels
    LABEL = param_label(.data[['LABEL']],.data[['Var1']],.data[['Var2']]),
    
    #Format Estimates
    Estimate  =  sig(.data[['value']], dig=Sig),
    
    #Format Parameters
    Parameter = .data[['PARAM']],
    Parameter = ifelse(is.null(.data[['PARAM']]), NA, .data[['Parameter']]),
    Parameter = ifelse(.data[['PARAM']]=="THETA",
                       sprintf("$%s$", .data[['LABEL']]),
                       sprintf("$\\%s_{%s}$",tolower(.data[['PARAM']]),.data[['LABEL']])),
    
    #Create RSE
    pRSE = sprintf('%s\\%%',sig(abs(.data[['prse']]), dig=Sig)),
    pRSE = ifelse(.data[['pRSE']]=="Inf\\%",'.',.data[['pRSE']]),
    pRSE = ifelse(.data[['FIXED']],'Fixed',.data[['pRSE']]),
    
    #Create Units
    Units = ifelse(!nzchar(.data[['UNIT']]),.data[['Variability']],.data[['UNIT']]),
    Units = gsub('\\b%\\b','\\\\%',.data[['Units']]),
    
    PARAM_lvl=.data[['PARAM']],
    PARAM = as.numeric(factor(.data[['PARAM']], levels=unique(.data[['PARAM']]))),
    
    Equal = .data[['Var1']]==.data[['Var2']]
  )

# Format CIs
CId <- formatC(ConfInt * 100, digits = 4, format="fg", width=1)
LCId <- paste0(CId, "\\% CI\nLower Bound")
UCId <- paste0(CId, "\\% CI\nUpper Bound")


Out <- 
  suppressWarnings(
    Out %>%
      mutate_at(c(LCId,UCId), function(.x) if_else(is.na(as.numeric(.x)), .x, sig(.x,dig=3)))
  )  # Suppress warning about coercing to numeric, which is behavior we're explicitly checking.


# Format Variability (r) ????? ----

for(i in grep("\\br\\b",Out$Variability)){
  cl <- Out$PARAM[i]
  t1 <- Out$Var1[i]
  t2 <- Out$Var2[i]
  Out$Parameter[i] <- sprintf("$\\text{Cor}_{%s-%s}$",
                             Out$LABEL[Out$Var1==t1 & Out$Var2==t1 & Out$PARAM==cl],
                             Out$LABEL[Out$Var1==t2 & Out$Var2==t2 & Out$PARAM==cl])
}




Out<- Out%>%arrange(.data[['PARAM']],.data[['Var2']],.data[['Var1']])

if (!OffDiagonals) 
  Out <- Out[which(Out$Var1==Out$Var2|Out$PARAM_lvl=='THETA'),]

#Insert some blank spaces for the pretties
blank <- rep(c(" REPLACE IIV "), times=dim(Out)[2])

if('OMEGA'%in%Out$PARAM_lvl){
  
  Omega1 <- grep("OMEGA", Out$PARAM_lvl)[1]
  
  Out <- rbind(Out[1:(Omega1-1),],blank, Out[-(1:(Omega1-1)),])  
  
  blank <- rep(c(" REPLACE RESERR "), times=dim(Out)[2]) 
  
}

if('SIGMA'%in%Out$PARAM_lvl){
  
  Sigma1 <- grep("SIGMA", Out$PARAM_lvl)[1]

  Out <- rbind(Out[1:(Sigma1-1),],blank, Out[-(1:(Sigma1-1)),])
  
}

#Remove fixed values if necessary
if(removeFixed){
  
  Out <- Out[!(as.logical(Out$FIXED) & Out$value==0),]  # NA's will skip
  
}


outThese <- c("Parameter","Estimate", "pRSE", LCId, UCId, "Units","PARAM","PARAM_lvl")

Out=Out[,outThese]

# Replace NAs or 0s
Out <- data.frame(apply(Out, c(1,2), function(x){ifelse(is.na(x), "", x)}), stringsAsFactors=FALSE, check.names=FALSE)

# Change all : characters to ~ because it screws up the later files
Out <- data.frame(apply(Out, c(1,2), function(x){gsub(pattern=":", replacement = "~", x)}), stringsAsFactors=FALSE, check.names=FALSE)


colId <- sprintf("CI (%s\\%%)", CId)
  Out[colId] <- sprintf("(%s, %s)", Out[,paste0(CId,"\\% CI\nLower Bound")], Out[,paste0(CId,"\\% CI\nUpper Bound")])
  Out[,colId][Out[,colId]=="( ,  )"] <- ""
  Out[,colId][Out[,colId]=="(-, -)"] <- "-"


Out <- Out[!grepl("\n",names(Out),fixed=TRUE)]

Out <- Out%>%
  dplyr::select(.data[['Parameter']],.data[['Estimate']],.data[['pRSE']],dplyr::contains('CI'),dplyr::everything())

return(Out)

}
