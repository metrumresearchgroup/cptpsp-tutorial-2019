#' @title Preview a TeX table using texPreview
#' @description Pass TeX tabular lines into texPreview
#' @param tex character, TeX tabular lines
#' @param stem character, name to use in output files
#' @param sanitize.math booleam, use math sanitizer on the table contents, Default: TRUE
#' @param table_opts list, named list of arguments specifying output behavior and footnotes,
#'  Default: \code{\link[mrgtable]{mrgtable_opts}}$get()
#' @param texp_opts named list of parameters to pass to \code{\link[texPreview]{texPreview}},
#'  Default: \code{\link[texPreview]{tex_opts}}$get()
#' @return LaTeX table
#' @seealso 
#'  \code{\link[texPreview]{texPreview}}
#' @rdname preview_tex
#' @export 
#' @importFrom texPreview texPreview
preview_tex <- function(tex,
                        stem,
                        sanitize.math = TRUE,
                        table_opts = mrgtable_opts$get(),
                        texp_opts = tex_opts$get()
                        ){
  
  table_opts <- fill_options(table_opts, y = mrgtable_opts$get())
  tex_args   <- fill_options(texp_opts, y = tex_opts$get()) 
  
  tex <- c("\\begin{center}",tex,"\\end{center}")

  if( sanitize.math )
    tex <- c(tex[c(1,2)],sapply(lapply(strsplit(tex[-c(1,2)],'\\&'),function(y) latexTranslate(gsub('\\\\%','%',y))),paste0,collapse='&'))
  
  if( table_opts$srcAdd ){
    
    if( !dir.exists(table_opts$objPath) ){
      
      warning(table_opts$objPath, " does not exist, writing to working directory")
      
      table_opts$objPath <- getwd()
      
    }
    
    tex_args$fileDir <- table_opts$objPath
    
    table_opts['srcAdd'] <- NULL
    
    table_opts$objName <- stem
    
    tblFootnote <- do.call(mrg_footnote,table_opts)
    
    tex <- c(tex,' ',tblFootnote$srcLab,' ',tblFootnote$objLab)
    
    writeLines(tex, con = file.path(table_opts$objPath, paste0(table_opts$objName,".tex")))
  }
  
  tex_args$returnType <- table_opts$returnType
  
  if(tex_args$returnType%in%c("tex","beamer")){
    tex_args$resizebox <- FALSE 
  }
  
  tex_args$obj        <- tex
  
  tex_args$stem       <- stem
  
  tex_args$ignore.stdout <- TRUE

  ret <- do.call(texPreview::texPreview,tex_args)
  
  if(tex_args$returnType=='viewer'){
    ret <- sprintf('\\input{%s}',normalizePath(file.path(tex_args$fileDir,sprintf('%s.tex',tex_args$stem))))
  }
  
  ret
    
}
