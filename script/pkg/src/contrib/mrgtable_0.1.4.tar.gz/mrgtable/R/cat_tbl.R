#' @title Demographics table for categorical variables
#' @concept table
#' @description Create a demographics table for categorical variables.
#' @param formula formula, formula that is seperated by ~, where the LHS variables convery the grouping (rows) 
#' and the RHS variables convey the continuous (columns) with an optional startification variable that is
#' placed after the | symbol. eg G1 + G2 ~ C1 + C2 | S1
#' @param data data.frame, contains the necessary variables to produce the output
#' @param stem character, stem for filename, Default: "cat_table"
#' @param idVar character, Column name for ID, Default: 'ID'
#' @param sig_dig integer, number of significant digits, Default: 3
#' @param wide logical, wide format, or long format (transposed), Default: TRUE
#' @param total logical, suppress summarization across strata and row groupings
#' @param sanitize.math logical, convert characters into tex valid math and symbols, Default: TRUE
#' @param returndf logical, return data.frame instead of tex output, Default: FALSE
#' @param table_opts list, named list of arguments specifying output behavior and footnotes, Default: mrgtable_opts$get()
#' @param texp_opts named list of parameters to pass to \code{texPreview}, Default: tex_opts$get()
#' @seealso \code{\link[texPreview]{texPreview}}, \code{\link{mrg_footnote}}
#' @examples 
#' data("mi210")
#' 
#' mi210%>%
#'   cat_tbl(formula = STUDY~CLCRF+SEX,
#'   idVar="ID")
#'   
#' mi210%>%
#'   cat_tbl(formula = STUDY~CLCRF+SEX,
#'   idVar="ID")
#'   
#' mi210%>%
#'   cat_tbl(formula = STUDY~CLCRF|SEX,
#'   idVar="ID")
#'   
#' mi210%>%
#'   cat_tbl(formula = STUDY~CLCRF|SEX,
#'   idVar="ID",
#'   wide=FALSE)
#'  
#' labelled::var_label(mi210$STUDY) <- 'Study ID'  
#' labelled::var_label(mi210$CLCRF) <- 'Clearance'
#' labelled::var_label(mi210$SEX) <- 'Gender'
#'  
#' mi210%>%
#'   cat_tbl(formula = STUDY~CLCRF+SEX,
#'   idVar="ID")
#'   
#' mi210%>%
#'   cat_tbl(formula = STUDY~CLCRF+SEX,
#'   idVar="ID",
#'   wide=FALSE)
#'   
#' @return LaTeX table
#' @export
#' @importFrom texPreview tex_opts
#' @rdname cat_tbl
cat_tbl <- 
  function(data,
           formula = .~.,
           stem="cat_table",
           idVar="ID",
           sig_dig = 3,
           wide = TRUE,
           total = TRUE,
           sanitize.math=TRUE,
           returndf=FALSE,
           table_opts = mrgtable_opts$get(),
           texp_opts = texPreview::tex_opts$get()){ 

    data <- check_group(data)

	  tbl_args <- tbl_form(data, formula, idVar)

	  subData   <- NULL
	  grp       <- NULL
	  grplabs   <- NULL
	  cats      <- NULL
	  catlabs   <- NULL
	  strat     <- NULL
	  stratlabs <- NULL
	  	  
	  list2env(tbl_args,envir = environment())

	  subDataCat <- cat_whole(subData,idVar,grp,cats,strat,stratlabs,total,sig_dig,returndf)
		
		if( wide ){
		  
		  tex <- cat_wide(subDataCat,grp,grplabs,cats,catlabs,strat,returndf)
		  
		  
		}else{
		  
		  tex <- cat_long(subDataCat,subData,total,grp,grplabs,cats,catlabs,strat,returndf)

		}

	  if(returndf)
	     return(tex)
	  
	  tex <- tex%>%
	    preview_tex(stem = stem,
	                sanitize.math = sanitize.math,
	                table_opts = table_opts,
	                texp_opts = texp_opts)
	  
	  if(table_opts$returnType=='html'){
	    tex
	  }else{
	    return(invisible(tex))
	  }
		
		
}
