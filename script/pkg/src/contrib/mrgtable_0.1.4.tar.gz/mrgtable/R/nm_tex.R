#' @title FUNCTION_TITLE
#' @description FUNCTION_DESCRIPTION
#' @param Out PARAM_DESCRIPTION
#' @return OUTPUT_DESCRIPTION
#' @details DETAILS
#' @examples 
#' \dontrun{
#' if(interactive()){
#'  #EXAMPLE1
#'  }
#' }
#' @rdname nm_tex
#' @export 

nm_tex <- function(Out) {
  
  Outi <- Out

  Outi$grp <- Outi$PARAM

  Outi$grp[Outi$PARAM > 3] <- 4

  Out$pRSE <- gsub("%", "", Out$pRSE, fixed = TRUE)

  names(Out)[grep("pRSE", names(Out))] <- "$\\%$RSE"

  Out[, c('PARAM','PARAM_lvl')] <- NULL

  tex <- tabular(Out,
                 grid = TRUE,
                 rowgroups = Outi$grp,
                 verbatim = FALSE)

  tex[ grep("REPLACE IIV", tex) ] <- sprintf("\\multicolumn{%s}{l}{Interindividual variability} \\\\ \\hline", ncol(Out))
  tex[ grep("REPLACE RESERR", tex) ] <- sprintf("\\multicolumn{%s}{l}{Residual error} \\\\ \\hline", ncol(Out))

  return(tex)
}
