#' @importFrom yaml yaml.load_file
#' @importFrom here here
.onLoad <- function(libname, pkgname) {
  config_file <- here::here("_mrgconfig.yml")

  if (file.exists(config_file)) {
    config <- yaml::yaml.load_file(config_file)
    
    config <- parse_attempt_yml(config)
    
    if (length(config$mrgtable) > 0) mrgtable_opts$set(config$mrgtable)
    if (length(config$tex) > 0) tex_opts$set(config$tex)
  }
}

.onAttach <- function(libname, pkgname) {
  config_file <- here::here("_mrgconfig.yml")

  x <- default_yml()
  
  if (file.exists(config_file)) {
    packageStartupMessage(
      "Current session settings defined by _mrgconfig.yml:\n\n",yaml::as.yaml(x)
    )
  }
}
