#' @title Create _mrgconfig.yml
#' @description Create _mrgconfig.yml file in project root directory
#' @return nothing
#' @examples
#' \dontrun{
#' create_yml()
#' }
#' @rdname create_yml
#' @export
#' @author Jonathan Sidi
#' @importFrom here here
create_yml <- function() {

  yml <- here::here("_mrgconfig.yml")
  ignore <- here::here(".Rbuildignore")
  no_ignore <- !file.exists(ignore)

  if (!file.exists(yml)) {
    yaml::write_yaml(default_yml(),file = yml)
    message(yml, " created")
  }

  if (no_ignore) {
    file.create(ignore)

    message(ignore, " created")
  }

  current_ignore <- readLines(ignore)

  if (!any(grepl("\\^\\\\_mrgconfig\\\\.yml\\$", current_ignore))) {
    cat("^\\_mrgconfig\\.yml$", file = ignore, sep = "\n", append = !no_ignore)

    message("^\\_mrgconfig\\.yml$ added to ", ignore)
  }
}

default_yml <- function(){
  
  tex      <- tex_opts$get()
  
  list(
    mrgtable = mrgtable_opts$get(),
    tex      = tex[-match(c('fileDir','returnType'),names(tex))]
    )
}
