#' @title mi210 Data
#'
#' @description The mi210 data.frame has 600 rows and 23 columns. 
#' The data represents a one compartment full model with 
#' IV administration that has been post processed through the TFL generator.
#'
#' @docType data
#'
#' @keywords datasets
#'
#' @references Metrum Research Group
#'
#' @format A data frame with 600 rows and 23 variables:
#' \describe{
#'   \item{\code{C}}{integer COLUMN_DESCRIPTION}
#'   \item{\code{ID}}{double COLUMN_DESCRIPTION}
#'   \item{\code{DV}}{double COLUMN_DESCRIPTION}
#'   \item{\code{AMT}}{integer COLUMN_DESCRIPTION}
#'   \item{\code{II}}{integer COLUMN_DESCRIPTION}
#'   \item{\code{ADDL}}{integer COLUMN_DESCRIPTION}
#'   \item{\code{TIME}}{double COLUMN_DESCRIPTION}
#'   \item{\code{RATE}}{integer COLUMN_DESCRIPTION}
#'   \item{\code{HT}}{integer COLUMN_DESCRIPTION}
#'   \item{\code{WT}}{integer COLUMN_DESCRIPTION}
#'   \item{\code{CLCR}}{double COLUMN_DESCRIPTION}
#'   \item{\code{SEX}}{integer COLUMN_DESCRIPTION}
#'   \item{\code{AGE}}{integer COLUMN_DESCRIPTION}
#'   \item{\code{IPRED}}{double COLUMN_DESCRIPTION}
#'   \item{\code{EVID}}{double COLUMN_DESCRIPTION}
#'   \item{\code{ETA1}}{double COLUMN_DESCRIPTION}
#'   \item{\code{ETA2}}{double COLUMN_DESCRIPTION}
#'   \item{\code{PRED}}{double COLUMN_DESCRIPTION}
#'   \item{\code{RES}}{double COLUMN_DESCRIPTION}
#'   \item{\code{WRES}}{double COLUMN_DESCRIPTION}
#'   \item{\code{Run}}{character COLUMN_DESCRIPTION}
#'   \item{\code{CLCRF}}{integer COLUMN_DESCRIPTION}
#'   \item{\code{STUDY}}{character COLUMN_DESCRIPTION} 
#'}
"mi210"
