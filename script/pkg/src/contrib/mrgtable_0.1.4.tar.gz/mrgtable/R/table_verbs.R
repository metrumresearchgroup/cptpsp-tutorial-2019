justify <- function(x,just = NULL){
  
  if(is.null(just))
    return(x)
  
  if(length(x)==1){
    
    x <- strsplit(x,'\n')[[1]]
    
  }
  
  idx <- grep('^\\\\begin\\{tabular\\}',x)
  current <- gsub('^\\\\begin\\{tabular\\}','',x[idx])
  current_ncols <- nchar(gsub('[{}|]','',current))
  just_ncols <- nchar(gsub('[|]','',just))
  
  if(current_ncols!=just_ncols){
    stop('not enough columns specficied, should be %s, submitted %s',current_ncols,just_ncols)
  }
  
  x[idx] <- sprintf('\\begin{tabular}{%s}',just)
  
  paste0(x,collapse = '\n')
}

centering <- function(input) {
  sprintf('\\begin{center}\n%s\n\\end{center}',input) 
}