#' @title re-export pipe operators
#' @description re-exported purrr operators
#' @importFrom purrr %>%
#' @name %>%
#' @rdname pipe
#' @export
NULL

#' @importFrom rlang %||%
#' @name %||%
#' @rdname pipe
#' @export
NULL

#' @title mrgtable pipe operators
#' @description Helper pipe operators for mrgtable
#' @param x,y If x is NA, will return y; otherwise returns x.
#' @param table If x is not in table return FALSE, else TRUE
#' @name %0%
#' @rdname mrgpipe
#' @export
`%0%` <- function(x,y = 0) ifelse(is.na(x),y,x)

#' @name %-%
#' @rdname mrgpipe
#' @export
`%-%` <- function(x,y = '-') ifelse(is.na(x),y,x)

#' @name %nin%
#' @rdname mrgpipe
#' @export
`%nin%` <- function (x, table) 
  match(x, table, nomatch = 0) == 0

#' @name map
#' @title Map values using corresponding values of another set
#' @description map function ported over from metrumrg
#' @author Tim Bergsma
#' @details Systematically substitute specific values from one set using corresponding
#' values from another set.
#' 
#' Occasionally one wants to recode a set of categories using some other idiom.
#' \code{factor} supports recoding by creative use of the arguments
#' \code{levels} and \code{labels}.  However, the result is a factor, and may
#' need more transformation.  Furthermore, \code{factor} allows one-to-one
#' reclassification but not many-to-one reclassification (repeated levels is
#' not supported; i.e., it is not directly possible to collapse two levels to a
#' single replacement code).
#' 
#' Here, \code{from} is the discrete set of values we expect in \code{x}, and
#' \code{to} is the element-wise corresponding values with which we wish to
#' re-present elements in \code{x}.  Values in \code{x} not found in
#' \code{from} will be normally represented as NA (which is itself a legitimate
#' value for \code{to}). However, if \code{strict=FALSE}, \code{.map} tries to
#' preserve un-mapped values.
#' 
#' It is an error if \code{from} and \code{to} have different lengths.
#' 
#' @param x vector
#' @param from vector (elements usually unique)
#' @param to vector with same length as \code{from}
#' @param strict whether to set unmapped values to \code{NA} (default)
#' @param \dots ignored
#' @return vector of same class as \code{to} and same length as \code{x}
#' @seealso \itemize{ \item \code{\link{match}} }
.map <-
  function(x,from,to,strict=TRUE,...){
    stopifnot(length(to)==length(from))
    res <- to[match(x,table=from)]
    if(!strict) res[!(x %in% from)] <- x[!(x %in% from)]
    res
  }

#' @title Capitalize letter in each word of a string
#' @description Capitalize letter in each word of a string
#' @param x character
#' @return character
#' @export
capitalize=function(x){
  gsub("(^|[[:space:]])([[:alpha:]])", "\\1\\U\\2", x, perl=TRUE)
}


deparse_tbl_form<-function(formula){
  x<-sapply(strsplit(deparse(formula,width.cutoff = 500),' ~ | \\| ')[[1]],
            function(x) strsplit(x,' \\+ '))
  
  lapply(x,function(y){
    s=splitlabel(y)
    sL=sapply(s,length)
    if(all(sL>1)){
      s
    }else{
      s[sL==1]=sapply(s[sL==1],function(x) list(rep(x,2)),USE.NAMES = FALSE)  
      s
    }
    
  })
}

splitlabel <- function( x1 ){
  
  lapply(strsplit( gsub('\\[(.*?)\\]',"~\\1~",x1), "~" ),function(x) gsub('\\"','',x))
  
}

.prev <-
  function(x){
    s <- seq_along(x)
    s <- c(length(s),s[-length(s)])
    x <- x[s]
    if(length(x))x[[1]] <- NA
    x
  }

.runhead <-
  function(x){#not like last observation
    n <- x != .prev(x)
    if(length(n)) n[[1]] <- TRUE
    n
  }


#from msm package
#' @importFrom stats deriv
deltamethod <- function (g, mean, cov, ses = TRUE) 
{
  cov <- as.matrix(cov)
  n <- length(mean)
  if (!is.list(g)) 
    g <- list(g)
  if ((dim(cov)[1] != n) || (dim(cov)[2] != n)) 
    stop(paste("Covariances should be a ", n, " by ", n, 
               " matrix"))
  syms <- paste("x", 1:n, sep = "")
  for (i in 1:n) assign(syms[i], mean[i])
  gdashmu <- t(sapply(g, function(form) {
    as.numeric(attr(eval(stats::deriv(form, syms)), "gradient"))
  }))
  new.covar <- gdashmu %*% cov %*% t(gdashmu)
  if (ses) {
    new.se <- sqrt(diag(new.covar))
    new.se
  }
  else new.covar
}

match_lvl <- function(a,b,data){
  data[[a]] <- as.factor(data[[a]])
  match(b, levels(data[[a]])) 
}

fill_options <- function(x,y = tex_opts$get()){
  
  fill_not_all_names <- intersect(names(y),names(x))
  
  for(i in fill_not_all_names){
    if(inherits(y[[i]],'list')){
      
      fill_options(x[[i]],y[[i]])
      
    }else{
      y[[i]] <- x[[i]]
    }
    
  }
  
  return(y)
}

#' @import dplyr
check_group <- function(data){
  
  check_class(data)
  
  if(dplyr::is.grouped_df(data)){
    message('input data is grouped ... ungrouping')
   
    data <- data%>%
      dplyr::ungroup()
  }
  
  return(data)
}

check_class <- function(data,expected = c('tbl_df', 'data.frame')){
  if(!inherits(data,expected))
    stop(sprintf("Expected data to inherit %s, instead data inherits '%s'",
                 paste0(expected,collapse = ' or '),
                 paste0(class(data),collapse = ',')
                 )
         )
}


split_tex <- function(tex,direction = 'head'){
  
  et <- grep("end\\{tabular\\}",tex)
  
  switch(direction,
         head = {
           tex <- tex[1:(et-1)]
           lt <- length(tex)
           tex[lt] <- gsub(' \\\\hline$','',tex[lt])
           tex
         },
         foot = {
           lt <- length(tex)
           tex[et:lt]
         })
  
}

parse_attempt_yml <- function(config){
  sapply(names(config),function(nx) {
  
  x <- config[[nx]]
  
  sapply(names(x),function(nm){
    
    y <- x[[nm]]
    
    to_eval <- grepl(y,pattern = '^`') 
    
    if(any(to_eval)){
      
      this <- y[to_eval]
      
      eval_str <- gsub('^`(.*?)r |`$','',this)
      
      tryCatch({
        eval(parse(text = eval_str))
      }, error = function(e) {
        stop(sprintf("Failed attempting to run R code in _mrgconfig.yml\n  %s: %s: %s\n%s", nx, nm, this, e),call. = FALSE)
      })
      
      y[to_eval] <- eval(parse(text = eval_str))
    }
    return(y)
  },simplify = FALSE) 
},simplify = FALSE)
}