#' @title Initial transformation of demog cat data
#' @description Initial transformation of demog cat data to pass to wide_cat or long_cat
#' @param subData data.frame
#' @param idVar character, Column name for ID
#' @param grp character, grouping columns
#' @param cats character, category columns
#' @param strat character, stratification columns
#' @param stratlabs character, labels for printing of the stratification columns
#' @param total logical, suppress summarization across strata and row groupings
#' @param sig_dig integer, number of significant digits
#' @param returndf logical, return data.frame instead of tex output, Default: FALSE
#' @return list containing templates of output tables by stratificationa levels and Total.
#' @rdname cat_whole
#' @import dplyr
#' @importFrom rlang !!! syms !! sym
#' @importFrom tidyr gather unite spread
#' @importFrom purrr map2_chr map
cat_whole <- function(subData,idVar,grp,cats,strat,stratlabs,total,sig_dig,returndf = FALSE){

  suppressWarnings({
    
  wholeData <- subData%>%
      dplyr::select(idVar,!!!(rlang::syms(cats)))%>%
      dplyr::mutate_if(is.factor,as.character)%>%
      tidyr::gather(key = 'variable',value='value',cats)
  
  })
  
  wholeData_freq <- wholeData%>%
    dplyr::count(.data[['variable']],.data[['value']])%>%
    dplyr::rename(freq=n)
  
  wholeData_prop <- prop.table(table(wholeData[,c("variable","value")],useNA="always"),margin = 1)
  
  colnames(wholeData_prop)[is.na(colnames(wholeData_prop))] <- "NA"
  
  for( j in 1:nrow(wholeData_freq) ){
    
    thisvalue <- as.character(wholeData_freq$value[j])
    
    if(is.na(thisvalue)) thisvalue <- "NA"
    
    wholeData_freq[j,"prop"] <- sig(wholeData_prop[wholeData_freq$variable[j],thisvalue]*100, dig = sig_dig)

  if(!returndf){
    wholeData_freq[j,"prop"] <- sprintf('(%s\\%%)',wholeData_freq[j,"prop"])
  }
      
  }
  
  wholeData_freq <- wholeData_freq%>%
    dplyr::rename(level=.data[['value']])
  
  wholeData_freq <-
    wholeData_freq%>%
    dplyr::group_by(.data[['variable']])%>%
    dplyr::mutate(order = purrr::map2_chr(.data[['variable']],!!(rlang::sym('level')), function(a,b){
      match(b, levels(subData[,a]))
    }))%>%
    dplyr::arrange(.data[['variable']],.data[['order']])%>%
    dplyr::select(-order)%>%
    tidyr::unite(!!(rlang::sym('var_lbl')),c(.data[['variable']],.data[['level']]),sep='_')
  
  wholeData <-
    rbind(
      wholeData_freq%>%dplyr::select(-.data[['prop']])%>%tidyr::spread(.data[['var_lbl']],value=.data[['freq']]),
      wholeData_freq%>%dplyr::select(-.data[['freq']])%>%tidyr::spread(.data[['var_lbl']],value=.data[['prop']])
    )%>%
    dplyr::select(wholeData_freq$var_lbl)%>%
    dplyr::mutate(value="(all)")
  
  names(wholeData)[grep('value',names(wholeData))] <- grp
  
  if(returndf){
    wholeData[grp] <- c("(Total)","(Percent)")  
  }else{
    wholeData[grp] <- c("{\\bfseries Total}","\\quad\\%")  
  }
  
  
  subDataCat <- split(subData, subData[,strat])
  
  subDataCat <- purrr::map(subDataCat, function(statData){

  suppressWarnings({
      
  statData__ <- statData%>%
        dplyr::select(!!!(syms(c(grp,cats))))%>%
        dplyr::mutate_if(is.factor,as.character)%>%
        tidyr::gather(key = 'Parameter',value='value',gather_cols = cats)

  })
    
    # Analyze the categorical variables ----
    
    statData__ <- statData__%>%
      dplyr::group_by(!!!(rlang::syms(names(statData__))))%>%
      dplyr::count() %>% 
      dplyr::mutate(n = as.character(.data[["n"]]))%>%
      dplyr::rename(level=.data[['value']], value=.data[["n"]])%>%
      tidyr::unite(!!(rlang::sym('param_lbl')),c(.data[['Parameter']],.data[['level']]),sep='_')%>%
      tidyr::spread(key = .data[['param_lbl']],value=.data[['value']])
    
    statData__ <- statData__ %>% mutate_all(function(x__) ifelse(is.na(x__), "0", x__))
    
    template <- replicate(nrow(statData__),wholeData[1,],simplify = FALSE)%>%
      dplyr::bind_rows()
    
    template[,] <- 0
    
    for( i in 1:nrow(statData__) ) 
      template[i,names(statData__)] <- statData__[i,names(statData__)]
    
    if(!returndf)
    template[grp] <- paste("\\quad",template[grp] %>% unlist)
    
    return(template)
  })
  
  if( total )
    subDataCat[["Total"]] <- wholeData
  
  if(!returndf)
  names(subDataCat) <- paste0("{\\bfseries ", capitalize(tolower(stratlabs)),": ", names(subDataCat), "}")
  
  subDataCat
}
