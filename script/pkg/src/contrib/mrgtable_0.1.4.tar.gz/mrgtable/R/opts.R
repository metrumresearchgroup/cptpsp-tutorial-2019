# forked from https://github.com/yihui/knitr/blob/master/R/defaults.R
#' @importFrom purrr set_names
new_defaults = function(value = list()) {
  defaults = value
  
  get = function(name, default = FALSE, drop = TRUE, regex=FALSE, ...) {
    if (default) defaults = value  # this is only a local version
    if (missing(name)) defaults else {
      if (drop && length(name) == 1){
        if(regex){
          name_grep <- grep(name,names(defaults),value=TRUE, ...)
          purrr::set_names(defaults[name_grep],name_grep)
        }else{
          defaults[[name]]
        }
      } else {
        purrr::set_names(defaults[name], name)
      }
    }
  }
  
  set = function(...) {
    dots = list(...)
    if (length(dots) == 0) return()
    if (is.null(names(dots)) && length(dots) == 1 && is.list(dots[[1]]))
      if (length(dots <- dots[[1]]) == 0) return()
    defaults <<- merge(dots)
    invisible(NULL)
  }
  
  merge = function(values) merge_list(defaults, values)
  
  restore = function(target = value) defaults <<- target
  
  append = function(...) {
    dots = list(...)
    if (length(dots) == 0) return()
    if (is.null(names(dots)) && length(dots) == 1 && is.list(dots[[1]]))
      if (length(dots <- dots[[1]]) == 0) return()
    dots<-sapply(names(dots),function(x) dots[[x]]<-c(defaults[[x]],dots[[x]]),simplify = FALSE)
    defaults <<- merge(dots)
    invisible(NULL)
  }
  
  list(get = get, set = set, append=append, merge = merge, restore = restore)
}

#' @title Default and current table options
#'
#' @description Options for functions in the mrgtable package. When running R code, the object \code{mrgtable_opts}
#' (default options) is not modified by chunk headers (local chunk options are
#' merged with default options), whereas \code{mrgtable_opts_current} (current options)
#' changes with different chunk headers and it always reflects the options for
#' the current chunk.
#'
#' Normally we set up the global options once in the first code chunk in a
#' document using \code{mrgtable_opts$set()}, so that all following chunks will
#' use these options.
#' 
#' \tabular{lll}{
#' \strong{Field} \tab \strong{Description} \tab \strong{Default Value}\cr
#' returnType   \tab character, defines the rendering behavior, see note after table        \tab 'tex'                         \cr
#' srcAdd       \tab boolean, add footer to tex with file paths to script and tex sources   \tab TRUE                            \cr
#' srcName      \tab character, file name of source script                                  \tab 'script'                          \cr
#' srcPath      \tab character, path to source script                                       \tab '.'                               \cr
#' objPath      \tab character, path to tex output                                          \tab '../deliv/table '                 \cr
#' table_position \tab character, LaTex table position code, used by wrap_tabular           \tab "!htbp"      
#'}
#'
#' The use of the \code{returnType} option specifies the output behavior; options are "viewer", "tex", and "html".  For all selections, both a tex tabular file and a version of the table rendered as a \code{png} will be written \code{objPath}.  Other rendered outputs are possible, see the \code{tex_opts} \code{imgFormat} option for these options.  The \code{returnType} option is differentiated by what is returned to the calling R session.  
#' 
#' * "viewer": the table is rendered as an image in the Rstudio viewer
#' * "tex": return the tex code as an object to the R session and to skip preview of the table
#' * "html", an image is rendered on disk and an html tag is returned to the console
#' 
#'  Both "tex" and "html" types are intended for use when knitting Rmd documents using the `results="asis"` chunk argument for \code{knitr} to simplify use of tables in html and pdf docs.
#'
#   A list of available options:
#   \url{https://yihui.name/knitr/options/#chunk_options}
#' @export
#' @rdname mrgtableOpts
#' @examples 
#' mrgtable_opts$get()
#' mrgtable_opts$set(srcAdd=TRUE, srcName="thisScript.R", returnType="viewer")
#' mrgtable_opts$get()
mrgtable_opts = new_defaults(
  list(
    returnType = 'tex',
    srcAdd = TRUE, 
    srcName = 'script', 
    srcPath = '.', 
    objPath = "../deliv/table",
    table_position = '!htbp'
    )
)

#' @rdname mrgtableOpts
#' @export
mrgtable_opts_current = new_defaults()

# merge elements of y into x with the same names
merge_list = function(x, y) {
  x[names(y)] = y
  x
}
