#' @title Long layout of categorical tables
#' @description Set up the long layout of cateogrical table to pass to tex
#' @param subDataCat data.frame, data to transform
#' @param subData data.frame, raw input data transformed with tbl_form
#' @param total logical, suppress summarization across strata and row groupings
#' @param grp character, grouping columns
#' @param grplabs character, labels for printing of the grouping columns
#' @param cats character, category columns
#' @param catlabs character, labels for printing of the category columns
#' @param strat character, stratification columns
#' @param returndf boolean, return object for data.frame or tex outputs, Default: FALSE
#' @return data.frame
#' @rdname cat_long
#' @import dplyr
#' @importFrom purrr map_int map2_chr map_chr imap_dfc
#' @importFrom tidyr gather separate spread
#' @importFrom rlang !! sym .data
cat_long <- function(subDataCat,
                     subData,
                     total,
                     grp,
                     grplabs,
                     cats,
                     catlabs,
                     strat,
                     returndf=FALSE){
  
  ltab <- do.call(rbind,subDataCat)%>%
    dplyr::mutate_all(funs(`%-%`))
  
  ltab <- ltab%>%
    dplyr::select(grp, everything())
  
  ltab$strata <- rep(names(subDataCat), times = purrr::map_int(subDataCat,nrow))
  
  if( total ){
    
    ltab_total <- ltab%>%
      dplyr::filter(.data[['strata']]==names(subDataCat)[length(subDataCat)])
    
    ltab <- ltab%>%dplyr::anti_join(ltab_total,by=intersect(names(ltab),names(ltab_total)))
    
  }
  
  gather_index <- setdiff(names(ltab),c("strata",grp))
  
  suppressWarnings({
    
    ltab <- 
      ltab%>%
      tidyr::gather(key="variable", value="value", gather_index) %>%
      dplyr::arrange(.data[['strata']],!!(rlang::sym(grp))) %>%
      tidyr::separate(col=.data[['variable']],into = c("varnm","category"),sep="_",remove = TRUE) %>%
      tidyr::spread(key = .data[['strata']],value = .data[['value']]) %>%
      mutate(order = purrr::map2_chr(.data[['varnm']], .data[['category']],match_lvl,data=subData)) %>%
      dplyr::arrange(!!(rlang::sym(grp)),.data[['varnm']],.data[['order']]) %>%
      dplyr::select(-.data[['order']])  
    
  })
  
  if(!returndf){
    ltab <- ltab%>%
      group_by(!!(rlang::sym(grp))) %>%
      mutate(varnm = ifelse(duplicated(.data[['varnm']]),"",.data[['varnm']]))
    
    ltab[duplicated(ltab[,grp]),grp] <- ""		    
    names(ltab) <- gsub(grp,paste("{\\\\bfseries", grplabs, "}"),names(ltab))
  }
  
  ltab <- ltab%>%
    dplyr::rename(Variable = .data[['varnm']], Category = .data[['category']])
  
  names(catlabs) <- cats
  
  ltab$Variable <- unname(catlabs)[match(ltab$Variable,names(catlabs))]
  ltab$Variable[is.na(ltab$Variable)] <- ''
  
  if( strat=="whole" ){
    
    names(ltab) <- gsub("{\\bfseries : whole}",'N',names(ltab),fixed = TRUE)
    
  }
  
  tex1 <- tabular(ltab,verbatim = FALSE)
  
  if( total ){
    
    suppressWarnings({
      
    ltab_total <- ltab_total%>%
      purrr::imap_dfc( ~ paste(.x, collapse=" ")) %>%
      tidyr::gather(!!(rlang::sym('variable')),!!(rlang::sym('value')),gather_index) %>%
      tidyr::separate(col= 'variable' , into = c("varnm","category"),sep="_",remove = TRUE)
    
    })
    
    if(!all(ltab_total$strata==''))
      ltab_total <- ltab_total%>%
        tidyr::spread(key = .data[['strata']],value = .data[['value']])
    
    ltab_total <-   ltab_total%>%
      dplyr::mutate(order = purrr::map2_chr(.data[['varnm']], .data[['category']], match_lvl, data=subData)) %>%
      dplyr::arrange(!!(rlang::sym(grp)),.data[['varnm']],.data[['order']]) %>%
      dplyr::mutate(order = NULL) %>%
      dplyr::mutate( grp= gsub("\\quad\\%","(\\%)",!!(sym(grp)),fixed = TRUE)) %>%
      dplyr::group_by(!!(rlang::sym(grp))) %>%
      dplyr::mutate(varnm = ifelse(duplicated(.data[['varnm']]),"",.data[['varnm']]))%>%
      dplyr::ungroup()
    
    ltab_total[duplicated(ltab_total[,grp]),grp] <- ""
    
    if( strat=="whole" ){
      
      ltab_total[,ncol(ltab_total)] <- NULL
      
    }else{
      
      ltab_total[,"grp"] <- ""
      
    }
    
    dummy <- matrix(NA,ncol = ncol(ltab)-ncol(ltab_total),nrow = nrow(ltab_total))
    
    colnames(dummy) <- rep("RENAME_ME",ncol(dummy))
    
    ltab_total <- bind_cols(ltab_total,data.frame(dummy))
    
    ltab_total$varnm <- unname(catlabs)[match(ltab_total$varnm,names(catlabs))]
    ltab_total$varnm[is.na(ltab_total$varnm)] <- ''
    
    ltab_total <- ltab_total%>%
      dplyr::rename(Variable = .data[['varnm']], Category = .data[['category']])
    
    tex2 <- tabular(ltab_total,rules = c(1,1,1),verbatim = FALSE)
    
    tex2 <- tex2[-grep(paste0("^[[:space:]]",grp),tex2)]
    
    tex2 <- tex2[(grep("begin\\{tabular\\}",tex2)+1):(grep("end\\{tabular\\}",tex2)-1)]
    
    tex <- c(
      split_tex(tex1,'head'),
      tex2,
      split_tex(tex1,'foot')
    )
    
  }else{
    
    tex <- tex1
    
  }
  
  if(returndf){

    if(total){
      ltab_list<- list(ltab = ltab,
                       ltab_total = ltab_total%>%
        dplyr::select(-!!(rlang::sym(grp)))%>%
        dplyr::rename(Total=.data[['Total Total']]))
      
    }else{
      
      ltab_list <- ltab
      
    }
    
    return(ltab_list)
  }
    
  
  tex
}
