#' @title mrg_footnote
#' @concept utility
#' @description \code{mrg_footnote} builds footnotes from mrgtable_opts
#' @param srcName character, source script name, Default: 'script'
#' @param srcPath character, source script path, Default: '.'
#' @param objPath character, Output figure/table path, Default: '../deliv/figure'
#' @param objName character, Output figure/table name, Default: 'Rplot.pdf'
#' @param size numeric, size of caption text relative to overall plot theme size, Default: 0.6
#' @param \dots other options are caught here and ignored
#' @return character
#' @importFrom tools file_path_sans_ext
#' @export
#' @rdname mrg_footnote
mrg_footnote=function(srcName='script',srcPath='.',objName="Rtable.tex",objPath="../deliv/table",size=0.6,...){
  
  if( !dir.exists(objPath) ) 
    stop(objPath, 'directory does not exist!, please specify valid objPath to save object output')
  
  objExt  <- ifelse(nchar(tools::file_ext(objName))==0,'tex',tools::file_ext(objName))
  
  objName <- tools::file_path_sans_ext(objName)
  
  srcExt  <- ifelse(nchar(tools::file_ext(srcName))==0,'R',tools::file_ext(srcName))
  
  srcName <- tools::file_path_sans_ext(srcName)
  
  srcLab  <- sprintf('%s/%s.%s',srcPath,srcName,srcExt)

  srcLab  <- gsub("_","\\\\_",srcLab)
  
  objPath <- gsub("_","\\\\_",objPath)
  
  objName <- gsub("_","\\\\_",objName)
  
  list(
    
    srcLab = sprintf('{\\raggedleft Source code: %s}',srcLab),
    
    objLab = sprintf('{\\raggedleft Source file: %s/%s.%s}',objPath,objName,objExt)
    
  )
  
}
