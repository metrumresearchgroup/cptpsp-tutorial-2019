#' @title Parse formula
#' @description Parse formula for demog tables and update input data for reserved words
#' @param data data.frame
#' @param formula formula, formula describing table layout
#' @param idVar character, Column name for ID
#' @param el_names character, names of elements in output list, Default: c('groupBy','catList','stratBy')
#' @return list containing data and parsed formula into a elements
#' @examples
#' data("mi210")
#' tbl_form(data = mi210,formula = STUDY~CLCRF+SEX,idVar="ID")
#' @seealso
#'  \code{\link[rlang]{quasiquotation}},\code{\link[rlang]{sym}}
#' @rdname tbl_form
#' @export
#' @import dplyr
#' @importFrom rlang !!! syms
#' @importFrom labelled to_factor var_label
tbl_form <- function(data, formula, idVar, el_names=c("groupBy", "catList", "stratBy")) {
  
  catList <- NULL
  groupBy <- NULL
  stratBy <- NULL

  if (deparse(formula, width.cutoff = 500) != ".~.") {
    fout <- deparse_tbl_form(formula)

    names(fout) <- c("groupBy", "catList", "stratBy")[1:length(names(fout))]

    list2env(fout, envir = environment())
  }

  col_labels <- labelled::var_label(data)
  
  data <- labelled::to_factor(data)
  
  grp <- sapply(groupBy, "[", 1)

  grplabs <- sapply(seq_along(grp),function(x) col_labels[[grp[x]]]%||%grp[x])

  cats <- sapply(catList, "[", 1)

  catlabs <- sapply(seq_along(cats),function(x) col_labels[[cats[x]]]%||%cats[x])

  if("excl_var" %in% el_names & !any('.'%in%cats)){
    
    excl_flag <- sapply(catList,function(x) eval(parse(text = x[2])))
    
  }else{
    
    excl_flag <- NULL
    
  }
  
  
  if (!is.null(stratBy)) {
    strat <- sapply(stratBy, "[", 1)
    
    stratlabs <- sapply(seq_along(strat),function(x) col_labels[[strat[x]]]%||%strat[x])
    
  } else {
    strat <- "whole"
    
    stratlabs <- ""
    
    data$whole <- "whole"
  }

  # "variable" is a reserved word
  if ("variable" %in% c(grp, cats)) {
    data <- dplyr::rename(data, `variable__` = "variable")

    grp[ grp == "variable" ] <- "variable__"

    cats[ cats == "variable" ] <- "variable__"
  }

  out <- list(
    subData = data,
    grp = grp,
    grplabs = grplabs,
    cats = cats,
    catlabs = catlabs,
    strat = strat,
    stratlabs = stratlabs
  )

  if ("conList" %in% el_names) {
    names(out)[c(4, 5)] <- c("cons", "conlabs")
  }

  if ("excl_var" %in% el_names) {
    names(out)[c(4, 5)] <- c("excl_var", "excl_var_labs")
    out$excl_flag <- excl_flag
  }
  
  return(out)
}
