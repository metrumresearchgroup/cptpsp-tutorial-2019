#' @title Wide layout of categorical tables
#' @description Set up the wide layout of cateogrical table to pass to tex
#' @param subDataCat data.frame, data to transform
#' @param grp character, grouping columns
#' @param grplabs character, labels for printing of the grouping columns
#' @param cats character, category columns
#' @param catlabs character, labels for printing of the category columns
#' @param strat character, stratification columns
#' @param returndf boolean, return object for data.frame or tex outputs, Default: FALSE
#' @return data.frame
#' @rdname cat_wide
#' @export 
#' @import dplyr
#' @importFrom stringi stri_split_regex
cat_wide <- function(subDataCat,grp,grplabs,cats,catlabs,strat,returndf=FALSE){
  
  ltab <- do.call(rbind,subDataCat)%>%
    dplyr::mutate_all(funs(`%-%`))
  
  ltab <- rbind(sapply(stringi::stri_split_regex(str = names(ltab),'_',n=2),function(x) x[2]), ltab)
  
  ltab <- ltab%>%
    dplyr::select(grp,everything())
  
  namerep <- sapply(stringi::stri_split_regex(str = names(ltab),'_',n=2),function(x) x[1])
  
  namerepLabs <- c(grplabs,catlabs)
  
  names(namerepLabs) <- c(grp,cats)
  
  namerep <- namerepLabs[namerep]
  
  ltabi <- within(ltab, grp <- c(0,rep(1:length(subDataCat), times = sapply(subDataCat,nrow))))
  
  ltab[ltabi$grp==0,grp] <- namerep[1]

  if(returndf)
    return(ltab)
    
  ltab[1,] <- paste0("{\\bfseries ",ltab[1,],"}")
  
  ltab[ltabi$grp==0,grp] <- ""

  colnames(ltab) <- NULL
  
  tex <- tabular(ltab,
                 rowgroups = ltabi$grp,
                 grid = TRUE,
                 colgroups = namerep,
                 rowgrouprule = 2,
                 verbatim = FALSE)
  
  ss <- '\\\\'
  
  if( strat!="whole" ){
    
    mc <- sapply(names(subDataCat), function(xx){
      sprintf("\\multicolumn{%i}{c}{}%s \\multicolumn{%i}{c}{\\bfseries %s}%s \\hline", 
              ncol(ltab),ss, ncol(ltab), xx,ss) 
    })
    
    index <- grep("\\\\ \\hline",tex,fixed = TRUE)
    
    index <- index[-c(1,length(index))]
    
    neworder <- c(1:length(tex),index+.5)
    
    tex <- c(tex,mc)[order(neworder)]
    
  }
  
  # Header ----
  
  factorTable <- data.frame(table(namerep))
  
  names(factorTable)=c('x','freq')
  
  factorTable$x <- as.character(factorTable$x)
  
  factorTable <- factorTable[match(unique(namerep),factorTable$x),]
  
  header <- apply(factorTable,1,function(r) 
    
    sprintf("\\multicolumn{%s}{c}{{\\bfseries %s}}", r["freq"],r["x"])
    
  )
  
  header <- sprintf('%s %s \\hline ', paste(header,collapse="&"), ss)
  
  tex <- c( tex[c(1,2)], header, tex[4:length(tex)] )  # Skipping 3 intentionally, just blank space 
  
  tex
}
