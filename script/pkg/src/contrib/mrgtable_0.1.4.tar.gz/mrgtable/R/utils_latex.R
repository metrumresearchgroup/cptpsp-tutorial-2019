#quoting from http://en.wikibooks.org/wiki/LaTeX/Absolute_Beginners ...
#"Anything in LaTeX can be expressed in terms of commands and environments."

#LaTeX Commands
#LaTeX commands are case sensitive, and take one of the following two formats:
# - They start with a backslash \ and then have a name consisting of letters only. Command names are terminated by a space, a number or any #other "non-letter".
# - They consist of a backslash \ and exactly one non-letter.
#Some commands need an argument, which has to be given between curly braces { } after the command name. Some commands support optional #parameters, which are added after the command name in square brackets [ ]. The general syntax is:
#\commandname[option1,option2,...]{argument1}{argument2}...

#LaTeX environments
#Environments in LaTeX have a role that is quite similar to commands, but they usually have effect on a wider part of the document. Their syntax #is:
#\begin{environmentname}
#text to be influenced
#\end{environmentname}
#Between the \begin and the \end you can put other commands and nested environments. In general, environments can accept arguments as well, but #this feature is not commonly used and so it will be discussed in more advanced parts of the document.

#' @title Verify only letters
#' @description Verify that each element contains only letters.
#' @param x character
#' @param \dots ignored
#' @details Verifies that each element in \code{x} contains only 
#'  upper or lower case letters.
#' @return logical
#' @author Tim Bergsma
#' @seealso \code{\link{is.latex.token}}
is.alpha <- function(x,...){
  stopifnot(is.character(x))
  font <- c(letters,LETTERS)
  x <- strsplit(x,'')
  sapply(x,function(vec)all(vec %in% font))
}

#' @title Check That Each Element is a Single Non-letter
#' @description Verify that each element is just one non-letter.
#' @param x character
#' @param ... ignored
#' @details Used to help identify proper latex command words.
#' @return logical
#' @author Tim Bergsma
#' @seealso \code{is.latex.token}
is.one.nonalpha <- function(x,...){
  stopifnot(is.character(x))
  font <- c(letters,LETTERS)
  (nchar(x)==1) & (!x %in% font)
}

#' @title Determine if String is Valid Latex Command or Environment
#' @description Latex commands (and presumably, environment names) must consist entirely of
#' upper or lower case letters, or must be a single non-letter.
#' @param x character
#' @param \dots ignored
#' @return logical
#' @author Tim Bergsma
#' @seealso \itemize{ \item \code{\link{is.alpha}} \item
#' \code{\link{is.one.nonalpha}} }
is.latex.token <- function(x,...)is.alpha(x) | is.one.nonalpha(x)

spaces <- function(x)paste(rep(' ',x),collapse='')

tagvalue <- function(x,sep='=',collapse=',',...){
  stopifnot(is.list(x))
  y <- sapply(
    seq_along(x),
    function(num){
      tag <- names(x)[[num]]
      value <- x[[num]]
      if(!is.null(tag))
        if(!is.na(tag))
          if(tag != "")value <- paste(tag,value,sep=sep)
      value
    }
  )
  paste(y,collapse=collapse)
}

#' @title Format Latex Command Options
#' @description Elements are strung in a comma separated list, optionally with \code{name=}
#' syntax.  List is enclosed in square brackets.
#' @param x list or vector
#' @param \dots ignored
#' @return character
#' @author Tim Bergsma
#' @seealso \itemize{ \item \code{\link{wrap}} \item \code{\link{command}}}
latex.options <- function(x,...){
  x <- as.list(x)
  x <- tagvalue(x)
  if(nchar(x)) x <- paste0('[',x,']')
  x
}


#' @title Format latex command arguments.
#' @description Each element wrapped in curly braces; elements are strung together.
#' @param x list or vector
#' @param \dots ignored
#' @return character
#' @author Tim Bergsma
#' @seealso \itemize{ \item \code{\link{wrap}} \item \code{\link{command}} }
latex.args <- function(x,...){
  x <- sapply(x,function(x)paste0('{',x,'}'))
  x <- paste(x,collapse='')
  x
}	

#' @title Format a latex command.
#' @description \code{x} is formated as a latex command, with the options (possibly named)
#' inserted in square brackets, and the arguments each enclosed in curly
#' braces.  \code{depth} spaces are added to the left end of the string.
#' @param x length one character
#' @param options vector or list
#' @param args vector or list
#' @param depth integer
#' @return character
#' @author Tim Bergsma
#' @seealso \itemize{ \item \code{\link{wrap}} \item \code{\link{ltable.data.frame}}}
command <- function(x, options=NULL, args=NULL,depth=0){
  stopifnot(length(x)==1, is.latex.token(x))
  options <- latex.options(options)
  args <- latex.args(args)
  res <- paste(c(spaces(depth),'\\',x,options,args),collapse='')
  res
}


#' @title Wrap Text in a Latex Environment
#' @description Wrap text in a latex environment. \code{x} is wrapped in the specified environment,
#'  with options and aruments formatted appropriately.
#' @param x character
#' @param environment name of environment
#' @param options list or vector
#' @param args list or vector
#' @param depth integer: extra spaces on the left.
#' @return character
#' @author Tim Bergsma
#' @seealso \itemize{ \item \code{\link{command}} \item
#' \code{\link{latex.args}} \item \code{\link{latex.options}}
#' \item \code{\link{ltable.data.frame}} }
wrap <- function(x,environment,options=NULL,args=NULL,depth=0){
  stopifnot(is.character(x),length(environment)==1,is.latex.token(environment))
  options <- latex.options(options)
  args <- latex.args(args)
  begin <- paste0(spaces(depth),'\\begin{',environment,'}',options,args)
  end   <- paste0(spaces(depth),'\\end{',environment,'}')
  x <- paste0(spaces(depth+1),x)
  res <- c(begin,x,end)
  res
}

#' @title Identify Boundaries Between Sets of Elements
#' 
#' @description Identify boundaries between sets elements.
#' A vector of length n has at most n-1 divisions between elements.  If the
#' elements are taken in runs of repeated elements, a set of divisions <= n-1
#' may be identified. This function returns a zero for each between-element
#' position if the bounding elements are identical, and a one for each
#' between-element position if the bounding elements differ. Used for placing
#' lines between sets of rows or columns in a table.
#' 
#' @param x vector
#' @return integer
#' @author Tim Bergsma
breaks <- function(x) as.integer(.runhead(x))[-1]

tabularformat <- function(justify,breaks,walls){
  stopifnot(
    length(walls)==2,
    length(justify)==length(breaks)+1,
    is.numeric(breaks),
    is.numeric(walls),
    !any(is.na(breaks)),
    !any(is.na(walls))
  )
  format <- ''
  format <- append(format, rep('|',walls[[1]]))
  for(i in seq_along(breaks)){
    format <- append(format,justify[[i]])
    format <- append(format,rep('|',breaks[[i]]))
  }
  #since there is one more justify than breaks ...
  format <- append(format, rev(justify)[[1]])
  format <- append(format, rep('|',walls[[2]]))
  format <- paste(format,collapse='')	
  format
}

#' @title Format Vector for Latex Tabular Row
#' @description Format a vector for use as a row in latex tabular environment.
#' Elements are collapsed into a string, with ampersand as the separator.
#' @param x vector, coerced to character with \code{paste}
#' @param \dots ignored
#' @return character
#' @author Tim Bergsma
#' @export
row2tabular <- function(x,...){
  x <- paste(x,collapse=' & ')
  x <- paste(x,'\\\\')
  x
}

#' @title Format Numeric Vectors Specially
#' 
#' @description Format a numeric vector so that decimal mark is a constant distance from the
#' end or beginning of each element. 
#' 
#' For \code{align.decimal}, each element is formatted separately using
#' \code{prettyNum}, then the character results are padded with spaces on the
#' right, so that the decimals align.  Whole numbers without the decimal mark
#' get an extra space in its place.
#' 
#' For \code{padded}, x (numeric) is formatted with zero decimal places, no
#' decimal, and enough leading zeros to ensure width \code{width}.

#' @param x numeric
#' @param decimal.mark character indicating decimal
#' @param width numeric indicating total digits
#' @param \dots ignored
#' @return character
#' @author Tim Bergsma
align.decimal <- function(x, decimal.mark='.', width, ...){
  x <- prettyNum(x)
  nodecimal <- !.contains(decimal.mark,x,fixed=TRUE)
  x[nodecimal] <- paste0(x[nodecimal],' ')
  splits <- strsplit(x,decimal.mark,fixed=TRUE)
  splits <- lapply(splits,function(x){if(length(x)==1)x[[2]]<-'';x})
  tails <- sapply(splits,function(x)nchar(x[[2]]))
  need <- max(tails) - tails
  while(any(need > 0)){
    x[need > 0] <- paste0(x[need > 0],' ')
    need <- need - 1
  }
  x
}

padded <- function (x, width = 4, ...) sprintf(paste0("%0",width,".0f"), x)

#' @title Use the ltable method
#' @description Convert object to ltable class.
#' @param x object
#' @param \dots arguments passed to methods
#' @export
as.ltable <- function(x,...)UseMethod('ltable')

#' @title Convert tex tables to tex longtables
#' @description Use the ltable method to convert objects to latex.
#' @param x object
#' @param \dots arguments passed to methods
#' @details See \code{\link{ltable.data.frame}}, \code{\link{ltable.character}}
#' @export
ltable <- function(x,...)UseMethod('ltable')


#' @title Convert a Data Frame to a Latex Table
#' @export
#' @description Converts data.frame to tabular, then wraps it in specified environments,
#' then wraps result in a latex table environment.  Result is returned visibly,
#' or if \code{file} is specified it is printed to file and returned invisibly.
#' 
#' If \code{source} and \code{source.label} are defined, they will be printed
#' in a tiny font immediately under the table (bound to the tabular element).
#' If \code{file} and \code{file.label} are defined as well, they will be
#' printed (tiny) under source.  Set \code{source.label} to NULL to suppress
#' embedding of \code{source}; set to empty string to suppress source label.
#' Set \code{file.label} to NULL to suppress embedding of \code{file}; set to
#' empty string to suppress file label. Note that \code{file} controls file
#' destination, whether or not represented in the result.
#' 
#' \code{ltable} is generic.  You can write methods for other classes.
#' \code{ltable.table} reclassifies its argument as matrix.
#' \code{ltable.matrix} tries to capture the column names as a caption, and
#' (like \code{tabular.matrix}) converts its argument to data.frame, capturing
#' rownames as a column in the first position if rownames are suitably named.
#' 
#' \code{as.ltable} is an alias for \code{ltable}.
#' 
#' @param x data.frame
#' @param caption full version of the caption
#' @param cap short version of the caption, for list of tables
#' @param cap.top Should caption be placed at the top, instead of bottom?
#' @param label optional label
#' @param options options for latex table environment
#' @param environments extra environments to nest between \sQuote{table} and
#' \sQuote{tabular}.
#' @param source optional source attribution
#' @param file optional file name
#' @param source.label optional text to preceed source if specified
#' @param file.label optional text to preceed file if specified
#' @param basefile if TRUE, strip path from file for display purposes
#' @param footnote.size font size for source and file, etc.
#' @param \dots passed to \code{tabular}
#' @return character
#' @author Tim Bergsma
#' @examples
#' 
#' ltable(head(Theoph))
#' ltable(table(1:3,4:6))
ltable.data.frame <- function(
  x,
  caption=NULL,
  cap=paste0("{",caption,"}"),
  cap.top=TRUE,
  label=NULL,
  options='!htpb',
  environments='center',
  source=NULL,
  file=NULL, ### file needs to support verbatim e.g. _
  source.label='source: ',
  file.label='file: ',
  basefile=FALSE,
  footnote.size='tiny',
  ...
){
  x <- tabular(x, ...)
  if(!is.null(source))if(!is.null(source.label)) x <- c(x,paste0('\\\\{\\',footnote.size,' ',source.label,source,'}'))  
  if(!is.null(file))if(!is.null(file.label)) x <- c(
    x,
    paste0(
      '\\\\{\\',footnote.size,' ',
      file.label,
      if(basefile)basename(file) else file,
      '}'
    )
  )
  for (env in environments) x <- wrap(x,env)
  if (!is.null(label))label <- command('label',args=label)
  if(!is.null(caption)){
    caption <- command(
      'caption',
      options=cap,
      args=paste(caption,label)
    )
    x <- c(
      if(cap.top)caption else NULL,
      x,
      if(!cap.top)caption else NULL
    )
  }
  x <- wrap(
    x,
    'table',
    options=options
  )
  class(x) <- c('ltable',class(x))
  if(is.null(file))return(x)
  else {
    writeLines(x,file)
    invisible(x)
  }
}	


#' @title Convert a Data Frame to a Latex Tabular Environment, Latex Document, or PDF
#' 
#' @description \code{tabular} attempts to convert R objects into suitable latex tables.
#' Use of \code{texPreview::texPreview} is recommended as the method for converting 
#' latex to pdf (or other formats) on disk.
#' 
#' \code{tabular.table} reclassifies its argument as matrix.
#' \code{tabular.matrix} converts its argument to data.frame.  If the rownames
#' are suitably named, they are adopted as a column in the first position.
#' 
#' Principal choices in \code{tabular.data.frame} are the number of lines above
#' and below the header, number of lines at the end of the table (rules), and
#' whether to have lines between rows and columns (grid).  If you do want the
#' latter, you can modify their placement easily with rowgroups and colgroups:
#' factor-like objects that show implicitly which sets of columns or rows go
#' together. Neighboring groups will be separated with a line.  For multiple
#' lines at a given position, explicit control is offered by rowbreaks and
#' colbreaks.  These latter have lengths one less than their respective
#' dimensions.
#' 
#' As of v5.56, if you specify rowgroups or colgroups as a character vector,
#' the appropriate margin will be explicitly subclassified (extra column for
#' rowgroups and extra header for colgroups).  If you also supply non-default
#' column attributes (e.g. colbreaks, na, verbatim, colwidth, justify), add an
#' extra element for the rowgroup column to overide internal defaults.  Row
#' color (rowcolors) seems not to be entirely compatible with multirow cells
#' (explicit rowgroups). For rowgroups, be sure to use package \code{multirow}
#' in your latex preamble.
#' 
#' If \code{source} and \code{source.label} are defined, they will be printed
#' in a \code{footnote.size} font immediately under the table (bound to the
#' tabular element).  If \code{file} and \code{file.label} are defined as well,
#' they will be printed (same size) under source.  Set \code{source.label} to
#' NULL to suppress embedding of \code{source}; set to empty string to suppress
#' source label. Set \code{file.label} to NULL to suppress embedding of
#' \code{file}; set to empty string to suppress file label. Note that
#' \code{file} controls file destination, whether or not represented in the
#' result.
#' 
#' Rownames are ignored.  If informative, capture them as a column (done
#' implicitly for \code{tabular.table} and \code{tabular.matrix}).
#' 
#' Converting a \code{tabular} object or any character vector to a document
#' causes inclusion of default values for the the arguments of
#' \code{makePreamble} and \code{as.document.character}.  Any of these can be
#' dropped by passing NULL.  Invocation of \code{makePreamble} can be avoided
#' entirely by passing a value for \code{preamble}. Alternatively, specify
#' \code{morePreamble} to extend the preamble, or to replace any elements you
#' may have dropped.
#' 
#' @param x object to be converted, typically data.frame
#' @param \dots see details
#' 
#' @details
#'  rules numeric; will be recycled to length 3.  indicates number of
#' horizontal lines above and below the header, and below the last row.
#' 
#'  walls numeric, recycled to length 2.  Number of vertical lines on
#' left and right of table.
#' 
#'  grid logical, whether to have lines between rows and columns
#'  
#'  rowgroups a vector as long as nrow(x), non-repeats trigger horizontal
#' lines
#' 
#'  colgroups a vector as long as names(x), non-repeats trigger vertical
#' lines
#' 
#'  rowbreaks numeric: a manual way to specify numbers of lines between
#' rows (ignores grid and rowgroups)
#' 
#'  colbreaks numeric: a manual way to specify numbers of lines between
#' columns (ignores grid and colgroups)
#' 
#'  rowgrouprule number of lines to set off row group column, if
#' rowgroups supplied as character
#' 
#'  colgrouprule number of lines to set off col group header, if
#' colgroups supplied as character
#' 
#'  rowcolors character vector of color names, recycled as necessary to
#' color all rows (NULL: no color)
#' 
#'  rowgrouplabel character string (at least one character) to label
#' rowgroup column
#' 
#'  charjust default justification for character columns
#'  
#'  numjust default justification for numeric columns
#'  
#'  justify manual specification of column justifications: left, right,
#' center, or decimal (vector as long as ncol(x))
#' 
#'  colwidth manual specification of column width. (vector of length
#' ncol(x).) Overrides \code{justify} where not NA.
#' 
#'  paralign used with colwidth to align paragraphs: top, middle, or
#' bottom.
#' 
#'  na string to replace NA elements
#'  
#'  verbatim whether to use verbatim environment for numeric fields.
#' Makes sense for decimal justification; interacts with \code{trim} and
#' \code{justify}.
#' 
#'  escape symbol used by `verb' command as delimiter.  A warning is
#' issued if it is found in non-NA text.
#' 
#'  trim passed to the format command: true by default, so that alignment
#' is the responsibility of just the tabular environment arguments
#' 
#'  source optional source attribution
#'  
#'  file optional file name
#'  
#'  source.label optional text to preceed source if specified
#'  
#'  file.label optional text to preceed file if specified
#'  
#'  basefile if TRUE, strip path from file for display purposes
#'  
#'  tabularEnvironment default \code{tabular}; consider also
#' \code{longtable}
#' 
#'  caption for \code{define}, included in \code{pretable}
#'  
#'  tabnum for \code{define}, whether to number this table
#'  
#'  pretable for \code{define}, material to place before the table
#'  
#'  prepos for \code{define}, where exactly to append pretable material
#'  
#'  headerBold for \code{define}, whether to display the table header in
#' bold font
#' 
#'  wide document width in mm
#'  
#'  long document lenth in mm
#'  
#'  wider additional document width in mm
#'  
#'  longer additional document lenth in mm
#'  
#'  preamble latex markup to include before beginning the document
#'  
#'  landscape if TRUE, default orientation is `landscape' not `portrait'
#'  
#'  geoLeft geometry package: left margin
#'  
#'  geoRight geometry package: right margin
#'  
#'  geoTop geometry package: top margin
#'  
#'  geoBottom geometry package: bottom margin
#'  
#'  documentclass document class command
#'  
#'  xcolorPackage xcolor package command
#'  
#'  geometryPackage geometry package command
#'  
#'  geometry geometry specification
#'  
#'  multirow multirow specification
#'  
#'  morePreamble additional preamble before beginning the document
#'  
#'  thispagestyle thispagestyle command
#'  
#'  pagestyle pagestyle command
#'  
#'  prolog latex markup to include before x
#'  
#'  epilog latex markup to include after x
#'  
#'  stem the stem of a file name (no extension)
#'  
#'  dir output directory
#'  
#'  clean whether to delete system files after pdf creation
#'  
#'  onefile whether to combine tex snippets into a single file
#'  
#'  delete whether temporary pdf (_doc.pdf) should persist
#'  
#'  latency how many seconds to wait before deleting temporary pdf
#'  
#'  footnote.size font size for source and file attributions

#' @return character
#' @author Tim Bergsma
#' @seealso \itemize{ \item \code{\link{ltable}} \item
#' \code{\link{align.decimal}} \item \code{\link{breaks}} \item
#' \code{\link{row2tabular}}
#' }
#' @examples
#' 
#' tabular(head(Theoph))
#' as.tabular(head(Theoph))
#' tabular(table(1:3,4:6))
#' tabular(head(Theoph,source='foo/bar',footnote.size='huge'))
#' @export
tabular <- function(x,...) UseMethod('tabular')

#' @title Convert object to tabular class
#' @description Convert object to tabular class
#' @param x object
#' @param \dots parameters to pass to tabular
#' @export
as.tabular <- function(x,...) UseMethod('tabular')

#' @export
tabular.data.frame <- function (x, ...) 
{

  l <- list(...)
  
  list2env(list(...),envir = environment())
  
  if(!exists('rules',where = l))
    rules = c(2, 1, 1)
  
  if(!exists('walls',where = l))
    walls = 0
  
  if(!exists('grid',where = l))
    grid = FALSE
  
  if(!exists('rowcolors',where = l))
    rowcolors = NULL
  
  if(!exists('charjust',where = l))
    charjust = "left"
  
  if(!exists('numjust',where = l))
    numjust = "right"
  
  if(!exists('colwidth',where = l))
    colwidth = NA
  
  if(!exists('paralign',where = l))
    paralign = "top"
  
  if(!exists('na',where = l))
    na = ""
  
  if(!exists('escape',where = l))
    escape = "#" 
  
  if(!exists('trim',where = l))
    trim = TRUE
  
  if(!exists('source',where = l))
    source = NULL
  
  if(!exists('file',where = l))
    file = NULL
  
  if(!exists('source.label',where = l))
    source.label = "source: "
  
  if(!exists('file.label',where = l))
    file.label = "file: "
  
  if(!exists('basefile',where = l))
    basefile = FALSE
  
  if(!exists('tabularEnvironment',where = l))
    tabularEnvironment = "tabular"
  
  if(!exists('endhead',where = l))
    endhead=FALSE

  if(!exists('rowgroups',where = l))
    rowgroups <- rownames(x)
  
  if(!exists('colgroups',where = l))
    colgroups = names(x)
    
  if(!exists('verbatim',where = l))
    verbatim = ifelse(sapply(x,is.numeric), TRUE, FALSE)
  
  justify = ifelse(sapply(x, is.numeric), numjust, charjust)
  rowbreaks = if (grid) breaks(rowgroups) else 0 
  colbreaks = if (grid) breaks(colgroups) else 0
  
  x <- as.data.frame(x)
  rules <- rep(rules, length.out = 3)
  walls <- rep(walls, length.out = 2)
  rowgroups <- rep(rowgroups, length.out = nrow(x))
  colgroups <- rep(colgroups, length.out = ncol(x))
  rowbreaks <- rep(rowbreaks, length.out = nrow(x) - 1)
  colbreaks <- rep(colbreaks, length.out = ncol(x) - 1)
  if (!is.null(rowcolors)) 
    rowcolors <- rep(rowcolors, length.out = nrow(x))
  stopifnot(length(charjust) == 1)
  stopifnot(length(numjust) == 1)
  stopifnot(length(escape) == 1)
  stopifnot(charjust %in% c("left", "right", "center"))
  stopifnot(numjust %in% c("left", "right", "center"))
  na <- rep(na, length.out = ncol(x))
  verbatim <- as.logical(rep(verbatim, length.out = ncol(x)))
  paralign <- .map(paralign, from = c("top", "middle", "bottom"), 
                  to = c("p", "m", "b"))[[1]]
  colwidth <- rep(colwidth, length.out = ncol(x))
  if(is.numeric(colwidth)){
    colwidth <- sprintf('%scm',colwidth)
    message(sprintf("colwidth coerced to (%s)",paste0(sprintf("'%s'",colwidth),collapse = ',')))
  }
  colwidth <- sub("^", paste0(paralign, "{"), colwidth)
  colwidth <- sub("$", "}", colwidth)
  justify <- rep(justify, length.out = ncol(x))
  decimal <- justify == "decimal"
  justify <- .map(justify, from = c("left", "right", "center", 
                                   "decimal"), to = c("l", "r", "c", "r"))
  justify[!is.na(colwidth)] <- colwidth[!is.na(colwidth)]
  format <- tabularformat(justify = justify, breaks = colbreaks, 
                          walls = walls)
  header <- row2tabular(names(x)) 
  if (endhead) header <- paste(header,'\\hline \\endhead')
  sapply(names(x)[verbatim], function(nm) if (any(!is.na(x[[nm]]) & 
                                                  .contains(escape, x[[nm]], fixed = TRUE))) 
    warning(nm, "contains", escape))
  
  x[] <- lapply(seq_along(x), function(col) if (decimal[[col]]) 
    align.decimal(x[[col]], ...)
    else format(x[[col]], trim = trim, ...))
  
  x[] <- lapply(seq_along(x), function(col) sub("^ *NA *$",na[[col]], x[[col]]))
  
  x[] <- lapply(seq_along(x), function(col){
    if (verbatim[[col]]){
      sprintf("\\lstinline[]{%s}", x[[col]])  
    }else{
      x[[col]]
    } 
  })
  
  x <- as.matrix(x)
  x <- apply(x, 1, row2tabular)
  if (!is.null(rowcolors)) 
    x <- paste0("\\rowcolor{", rowcolors, "}", x)
  x <- c("", header, x)
  rowbreaks <- c(rules[1:2], rowbreaks, rules[[3]])
  stopifnot(length(rowbreaks) == length(x))
  while (any(rowbreaks > 0)) {
    x[rowbreaks > 0] <- paste(x[rowbreaks > 0], "\\hline")
    rowbreaks <- rowbreaks - 1
  }
  x <- wrap(x, tabularEnvironment, args = format)
  class(x) <- c("tabular", class(x))
  if (!is.null(source)) 
    if (!is.null(source.label)) 
      x <- c(x, paste0("\\\\ {\\raggedleft \\tiny ", source.label, source, 
                     "}"))
  if (!is.null(file)) 
    if (!is.null(file.label)) 
      x <- c(x, paste0("\\\\ {\\raggedleft \\tiny ", file.label, if (basefile) basename(file) else file, 
                     "}"))
  if (is.null(file)) 
    return(x)
  else {
    writeLines(x, file)
    invisible(x)
  }
}

#' @export
tabular.table <- function(x, ...){
  if(length(dim(x)) != 2) stop('tabular.table only implemented for 2-dimensional tables')
  class(x) <- 'matrix'
  tabular(x, ...)
}

#' @export
ltable.table <- function(x, ...){
  if(length(dim(x)) != 2) stop('ltable.table only implemented for 2-dimensional tables')
  class(x) <- 'matrix'
  ltable(x, ...)
}

#' @export
tabular.matrix <- function(x,...){
  y <- as.data.frame(x)
  dimnames <- dimnames(x)
  if(!is.null(dimnames)){
    nms <- names(dimnames)
    rows <- nms[[1]]
    if(!is.null(rows))
      if(!is.na(rows))
        if(rows != '')
          if(!rows %in% names(y)){
            y[,rows] <- rownames(x)
            y <- shuffle(y, rows) # move to front
          }
  }
  tabular(y,...)
}

#' @export
ltable.matrix <- function(x, caption = names(dimnames(x))[[2]],...){
  y <- as.data.frame(x)
  dimnames <- dimnames(x)
  if(!is.null(dimnames)){
    nms <- names(dimnames)
    rows <- nms[[1]]
    if(!is.null(rows))
      if(!is.na(rows))
        if(rows != '')
          if(!rows %in% names(y)){
            y[,rows] <- rownames(x)
            y <- shuffle(y, rows) # move to front
          }
  }
  ltable(y,caption=caption, ...)
}

#' @title character method for ltable
#' @description Wrap tex (tabular) into a table float, primarily for use in Rmd documents
#' @param x a vector of tex code in a tabular environment
#' @param ... arguments to pass into ltable, see details
#' @details 
#' 
#' Arguments to pass in ...
#' 
#' caption: table caption
#' 
#' cap.top: logical, caption at top (TRUE) or bottom of float?
#' 
#' label: table label
#' 
#' environments: table is implied in the function, but additional environments 
#' may be wrapped between the table and tabular environments here
#' 
#' options: options for the table float, e.g., !hbtp
#' 
#' @return a character vector suitable for rendering "asis" for table inclusion
#' @examples 
#' 
#' tex <- mi210%>%
#'        cat_tbl(formula    = STUDY ~ AGE + HT,
#'                idVar      = 'ID',
#'                table_opts = list(srcAdd     = FALSE,returnType = 'tex')
#'                )
#'                     
#' tex%>%
#' ltable(
#'        caption = "Mean [Range] (N non-missing) per study.",
#'        label="tab:tab1",
#'        options="!H"
#'        )%>%
#'        writeLines()
#'
#' @export

ltable.character <- function(x, ... ){
  
  l <- list(...)
  
  list2env(list(...),envir = environment())
  
  if(!exists('caption',where = l))
    caption <- NULL
  
  if(!exists('cap.top',where = l))
    cap.top <- TRUE
  
  if(!exists('label',where = l))
    label <- NULL
  
  if(!exists('environments',where = l))
    environments <- NULL
  
  if(!exists('options',where = l))
    options <- NULL
  
  for (env in environments) x <- wrap(x,env)
  
  if (!is.null(label))label <- command('label',args=label)
  if(!is.null(caption)){
    caption <- command(
      'caption',
      options=caption,
      args=paste(caption,label)
    )
    x <- c(
      if(cap.top)caption else NULL,
      x,
      if(!cap.top)caption else NULL
    )
  }
  x <- wrap(
    x,
    'table',
    options=options
  )
  return(x)
}

#' @title Convert ftable to data.frame as displayed
#' @description Convert ftable to data.frame As Displayed
#' @param x ftable
#' @param \dots ignored
#' @details \code{as.data.frame.ftable} does indeed convert an \code{ftable} to \code{data.frame},
#'  but it gives a stacked result.  Use this function to 
#'  give something more like what is displayed at the prompt (suitable for passing to latex).
#' @return data.frame
#' @author Tim Bergsma
#' @examples
#' 
#' x <- mtcars[c("cyl", "vs", "am", "gear")]%>%
#' ftable()
#' 
#' x
#' 
#' x%>%
#' as.data.frame()
#' 
#' x%>%
#' ftable()%>%
#' ftable2data.frame()
#' 
#' @export

ftable2data.frame <- function(x,...){
  y <- format(x,quote=FALSE)
  z <- data.frame(y[-1,],stringsAsFactors=FALSE)
  names(z) <- y[1,]
  z
}

#' @title Escape all regexp
#' @description Give a string, return an escaped string over all special characters.  
#' This was originally written to be used with str_replace_all for the names in 
#' the \code{pattern} argument
#' @param string string you want to be escaped, special characters will be escaped
escape <- function(string) {
  gsub("(\\W)", "\\\\\\1",string)
}

shuffle <- function (x, who, after = NA){
  names(x) <- make.unique(names(x))
  who <- names(x[, who, drop = FALSE])
  nms <- names(x)[!names(x) %in% who]
  if (is.null(after)) 
    after <- length(nms)
  if (is.na(after)) 
    after <- 0
  if (length(after) == 0) 
    after <- length(nms)
  if (is.character(after)) 
    after <- match(after, nms, nomatch = 0)
  if (after < 0) 
    after <- length(nms)
  if (after > length(nms)) 
    after <- length(nms)
  nms <- append(nms, who, after = after)
  x[nms]
}

.nxt <- function(x)rev(.prev(rev(x)))


#' @importFrom stats quantile
f.quantile <- function(x, ind, ...) stats::quantile(x[ind], ...)


#' @title Creates a ln (log) based sequence
#' @description Used in creating appropriate plot legend breaks
#' @param x numeric vector
#' @return  numeric vector
lnseq <- function(x){sig(2.718282^(seq(from=floor(log(range(x, na.rm=TRUE)[1])), 
                                          to=ceiling(log(range(x, na.rm=TRUE)[2])), 
                                          by=1)), 
                            dig=3)}

.contains <-
  function(pattern,text,...){
    hits <- regexpr(pattern,text,...)
    hits >=0
  }

insert <- function(x, y, after=NULL, before=NULL){
  
  if(!is.null(after)) return(c(x[1:after], y, x[(after+1):length(x)]))
  if(!is.null(before))return(c(x[1:(before-1)], y, x[before:length(x)]))
  
}

#' @title Longtable a LaTex table
#' @description Strip a table/tabular tex object and turn it into a longtable
#' @param tex tex object
#' @details Longtables will stretch over several pages, but require a slightly different 
#' setup than table/tabular.  This function attempts to convert to a longtable format.  
#' Currently, \code{endline} and \code{endhead} are forced, this is to be improved in future versions
#' @export 

table_to_longtable <- function(tex){

  tex <- gsub("tabular","longtable",tex)
  capi <- grep("caption", tex)
  cap <- paste0(tex[capi],"\\\\") # required in longtable
  
  if(length(capi)>0){ 
    
    tex <- tex[-capi] 
    
  }else{
    
      cap <- NULL
      
  }
  
  longbegini <- grep("begin{longtable}",tex,fixed = TRUE)
  
  tex <- insert(tex, cap, longbegini)
  
  # Now insert the header break
  headi <- grep('&',tex,fixed = TRUE)[1]
  tex <- insert(tex, c("\\endline","\\hline","\\endhead"), headi)
  
  # Strip table
  tablei <- grep("{table}",tex,fixed = TRUE)
  
  if(length(tablei)>0)
    tex <- tex[!tablei]

  return(tex)
}


#' @title wrap tabular tex file in a table call
#' @description add table, caption and label around an input tex call for
#' a file that has a tabular object.
#' @param object character, tabular tex lines or tex input call with path to tex file
#' @param caption character, Caption of the table, Default: ''
#' @param label character, Label of the table, Default: 'LABEL'
#' @param position character, Position of the table, Default: mrgtable_opts$get('table_position')
#' @param writelines boolean, if TRUE then result is printed to console, default: TRUE
#' @return tex lines
#' @details In RStudio the function can be invoked from the addins menu and wrap highlighted text with
#' the output defaults.
#' @examples 
#' \dontrun{
#' wrap_tabular('\\input{a_table.tex}')
#' }
#' @rdname wrap_tabular
#' @export 

wrap_tabular <- function(
  object,
  caption='',
  label='LABEL',
  position = mrgtable_opts$get('table_position'),
  writelines = TRUE) {

  object <- paste0(object,collapse = '\n')

  label <- sprintf('\\label{%s}',label)
  
  caption <- sprintf('\\caption{%s}',caption)
  
  ret <- sprintf('\\begin{table}[%s]\n%s\n%s\n%s\n\\end{table}',
          position,
          caption,
          label,
          object)
  
  if(writelines){
    
    cat(ret)
    return(invisible(ret))
    
  }else{
    
    return(ret)
    
  }
    
}

#' @rdname wrap_tabular
#' @export
#' @importFrom rstudioapi getSourceEditorContext modifyRange
wrap_tabular_addin <- function(){
  
  loadNamespace("rstudioapi")
  
  adc <- rstudioapi::getSourceEditorContext()
  
  new_text <- wrap_tabular(adc$selection[[1]]$text,writelines = FALSE)
  
  rstudioapi::modifyRange(location = adc$selection[[1]]$range,new_text,id = adc$id)
}
