#' @title Format Parameter Label
#' @description Create tex formats for parameter label from input formulas used in *_tbl calls.
#' @param LABEL character, Original Label
#' @param ROW character, if LABEL is empty ('') ROW is the variable row index, Default: NULL
#' @param COL character, if LABEL is empty ('') COL is the variable column index, Default: NULL
#' @return character
#' @details If the LABEL has an underscore eg a_b it is converted to \\text{a}_b.
#' ROW and COL represent the index of elements in a matrix and are concatenated with a comma. 
#' @examples 
#' param_label('a')
#' param_label('a_b')
#' param_label('','c','d')
#' @rdname param_label
#' @export 

param_label <- function(LABEL,ROW = NULL,COL = NULL){

  #Trim white spaces
  
    LABEL <- trimws(LABEL)
  
  # Fill in missing LABEL with index of PARAM type
    
    LABEL <- ifelse(nzchar(LABEL), LABEL, sprintf('%s,%s',ROW,COL))
  
  # Format Parameter Label  
    
    title <- lapply(strsplit(LABEL,"_"), function(l){
      l[1] <- sprintf("\\text{%s}",l[1])
      if(length(l)>1) l <- sprintf('%s_%s',l[1],l[-1])
      return(l)
    })
  
  LABEL <- unlist(title)
    
  return(LABEL)
  
}

#' @title Significant Digits
#' @description Set significant digits according to metrum SOP.
#' @param x numeric, value to manipulate
#' @param dig numeric, number of significant digits Default: 3
#' @param maxex numeric, maximum number of significant
#' digits before moving to scientific notation, Default: NULL
#' @return character
#' @examples 
#' sig(1.123455)
#' sig(0.123455)
#' sig(1.123455,dig = 5)
#' sig(1123,maxex = 3)
#' sig(1123,maxex = 4)
#' @rdname sig
#' @export 
sig <- function(x,dig=3,maxex=NULL) {
  if(class(x)=="integer") return(x)
  namez <- names(x)
  
  x <- as.numeric(x)
  x <- formatC(signif(x,digits=dig), digits=dig, format='g', flag='#')
  
  if(is.numeric(maxex)) {
    if(dig!=maxex) {
      ex <- "([-]*[0-9]\\.[0-9]+)e([+-][0-9]{2})"
      subit <- grepl(ex,x,perl=TRUE)
      b <- as.numeric(gsub(ex, "\\2", x))
      subit <- subit & abs(b) < maxex
      x <- ifelse(subit,formatC(signif(as.numeric(x),digits=dig),digits=dig, format="fg",flag="#"),x)
    }
  }
  x <- gsub("\\.$", "", x, perl=TRUE)
  names(x) <- namez
  return(x)
}
