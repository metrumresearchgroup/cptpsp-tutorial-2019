#' @title Create NONMEM table
#' @description Worker function for \code{nm_tbl}
#' @param all the PARAMTBL element from a nibble object
#' @param ConfInt numeric, confidence interval level, Default: 0.95
#' @param unTransform logical, search for LOGD in fixed effect parameter estimates.  If present, use delta method to exponentiated version.
#' @param bound logical, set the minimum of the confidence interval to 0 for diagonal elements of the random effect parameters
#' @return tibble
#' @seealso 
#'  \code{\link[stats]{TDist}}
#' @rdname nm_create
# @export 
#' @import dplyr
#' @importFrom stats qt
nm_create <- function(all,
                      ConfInt = 0.95,
                      unTransform=TRUE,
                      bound = FALSE) {
  
  all$PARAM <- gsub("%", "\\%", all$PARAM, fixed = TRUE)
  all$LABEL <- gsub("%", "\\%", all$LABEL, fixed = TRUE)
  
  all <- all %>% mutate(
    se = ifelse(
      .data[['FIXED']],
      NA,
      .data[['se']]
      ),
    cse = ifelse(
      .data[['FIXED']],
      NA,
      .data[['cse']]
      )
    )
    
  # Generate the ci multiplier
  ciMult <- stats::qt(ConfInt / 2 + 0.5, Inf)
  all$CI <- as.numeric(all$se) * ciMult
  
  # set Confidence interval
  CId <- formatC(ConfInt * 100, digits = 4, format="fg", width=1)
  LCId <- paste0(CId, "\\% CI\nLower Bound")
  UCId <- paste0(CId, "\\% CI\nUpper Bound")
  
  # Create Confidence Bounds
  all[, LCId ] <- all$value - all$CI
  all[, UCId ] <- all$value + all$CI
  
  if (unTransform) {
    
    # transform based on description
    transList <- c("value", LCId, UCId)
    all <- all %>% mutate_at(vars(transList), as.numeric)
    
    idx <- which(grepl("LOGD", all$LABEL) & grepl("THETA", all$PARAM))
    
    if (length(idx > 0)) {
      all[idx, "se"] <- sapply(idx, function(y) {
        deltamethod(~exp(x1), all[y, "value"], all[y, "se"] ^ 2)
      })
      all[idx, names(all) %in% transList] <- exp(all[idx, names(all) %in% transList])
    }
    
    # remove the LOGD notation
    all$LABEL <- gsub("[[:space:]]*LOGD[[:space:]]*", "", all$LABEL)
  }
  
  all$prse <- all$se / all$value * 100
  
  if (any(grepl("OMEGA|SIGMA", all$PARAM))) {
    all$crse <- all$cse / all$c
    
    all$Variability <- NA
    
    all$TYPE <- gsub("[[:space:]]*", "", all$TYPE)
    
    unknown_directive <- setdiff(all$TYPE, c("",paste0("[",c("A","P","R","C",""),"]")))
    for(i in seq_along(unknown_directive)) warning("Unknown directive:", unknown_directive[i])
    
    # P; Lognormal or proportional
    pIdx <- which(all$TYPE == "[P]")
    if(length(pIdx)>0){
      pIdx_offdiag <- pIdx[all[pIdx,"Var1"]!=all[pIdx,"Var2"]]
      if(length(pIdx_offdiag)>0){
        warning("Lognormal directive indicated for off-diagonal elements, reporting correlation")
        all[pIdx_offdiag,"TYPE"] <- "[R]"
        pIdx <- setdiff(pIdx,pIdx_offdiag)
      }
      all$Variability[pIdx] <- "CV %"

      # Assume lognormal for OMEGA, proportional error for SIGMA
      all$value[pIdx] <- ifelse(grepl("OMEGA",all$PARAM[pIdx]), sqrt( exp(all$c[pIdx]^2)-1) * 100, all$c[pIdx]*100)
      all$prse[pIdx] <- all$crse[pIdx] * 100
      
      all[pIdx, LCId] <- 
        ifelse(grepl("OMEGA",all$PARAM[pIdx]), 
               ( sqrt(exp(all$c[pIdx]^2- ciMult * all$se[pIdx])-1)) * 100, # Use the SE of the variance
               ( all$c[pIdx] - ciMult * all$cse[pIdx]) * 100               # Use the SE of the sd
               )
      all[pIdx, UCId] <-         
        ifelse(grepl("OMEGA",all$PARAM[pIdx]), 
               ( sqrt(exp(all$c[pIdx]^2+ ciMult * all$se[pIdx])-1) ) * 100,
               ( all$c[pIdx] + ciMult * all$cse[pIdx]) * 100
        )
      
      if(bound & length(pIdx)>0){
        # Set 0 as lower bound on diagonals
        all[pIdx,LCId] <- pmax(unlist(all[pIdx,LCId]), rep(0,length(pIdx)))
        all[pIdx,UCId] <- pmax(unlist(all[pIdx,UCId]), rep(0,length(pIdx)))
      }
    }
    
    # A; Additive
    aIdx <- which(all$TYPE == "[A]")
    
    if(length(aIdx)>0){
      
      aIdx_offdiag <- aIdx[all[aIdx,"Var1"]!=all[aIdx,"Var2"]]
      if(length(aIdx_offdiag)>0){
        all[aIdx_offdiag,"TYPE"] <- "[R]"
        aIdx <- setdiff(aIdx,aIdx_offdiag)
      }
      
      all$Variability[aIdx] <- "SD"
      all$value[aIdx] <- all$c[aIdx]
      all$prse[aIdx] <- all$crse[aIdx] * 100
      
      all[aIdx, LCId] <- all$c[aIdx] - ciMult * all$cse[aIdx]
      all[aIdx, UCId] <- all$c[aIdx] + ciMult * all$cse[aIdx]
      
      if(bound & length(aIdx)>0){
        # Set 0 as lower bound on diagonals
        all[aIdx,LCId] <- pmax(unlist(all[aIdx,LCId]), rep(0,length(aIdx)))
        all[aIdx,UCId] <- pmax(unlist(all[aIdx,UCId]), rep(0,length(aIdx)))
      } 
    }
    
    
    # R; Give correlation matrix values
    rIdx <- which(all$TYPE == "[R]")
    
    if(length(rIdx)>0){
      
      all$Variability[rIdx] <- ifelse(all$Var1[rIdx]!=all$Var2[rIdx], "r", "SD")
      all$value[rIdx] <- all$c[rIdx]
      all$prse[rIdx] <- all$crse[rIdx] * 100
      
      all[rIdx, LCId] <- all$c[rIdx] - ciMult * all$cse[rIdx]
      all[rIdx, UCId] <- all$c[rIdx] + ciMult * all$cse[rIdx]
      
      if(bound & length(rIdx)>0){
        # Set 0 as lower bound on diagonals
        rIdx <- rIdx[all[rIdx,"Var1"]==all[rIdx,"Var2"]]
        if(length(rIdx)>0){
          all[rIdx,LCId] <- pmax(unlist(all[rIdx,LCId]), rep(0,length(rIdx)))
          all[rIdx,UCId] <- pmax(unlist(all[rIdx,UCId]), rep(0,length(rIdx)))
        }
      }
      
    }
    
    
    # C; Give covariance matrix values
    cIdx <- which(all$TYPE == "[C]")
    
    if(length(cIdx)>0){
      
      all$Variability[cIdx] <- ifelse(all$Var1[cIdx]!=all$Var2[cIdx], "Cov", "Var")
      all[cIdx, LCId] <- all$value[cIdx] - ciMult * all$se[cIdx]
      all[cIdx, UCId] <- all$value[cIdx] + ciMult * all$se[cIdx] 
      
      if(bound & length(cIdx)>0){
        # Set 0 as lower bound on diagonals
        cIdx <- cIdx[all[cIdx,"Var1"]==all[cIdx,"Var2"]]
        if(length(cIdx)>0){
          all[cIdx,LCId] <- pmax(unlist(all[cIdx,LCId]), rep(0,length(cIdx)))
          all[cIdx,UCId] <- pmax(unlist(all[cIdx,UCId]), rep(0,length(cIdx)))
        }
      }
    }
    
    all$Variability <- gsub("%", "\\%", all$Variability, fixed = TRUE)
  }
  

  
  all[all$FIXED, LCId] <- "-"
  all[all$FIXED, UCId] <- "-"
  
  return(all)
}
