#' @title Demographics table for continuous variables
#' @concept table
#' @description Create demographics tables for continuous variables
#' @param formula formula, formula that is seperated by ~, where the LHS variables convery the grouping (rows) 
#' and the RHS variables convey the continuous (columns) with an optional startification variable that is
#' placed after the | symbol. eg G1 + G2 ~ C1 + C2 | S1
#' @param stem character, stem for filename, DEfault: "cont_tbl"
#' @param idVar character, Column name for ID, Default: 'ID'
#' @param data data.frame, contains the necessary variables to produce the output
#' @param wide logical, wide format, or long format (transposed)
#' @param total logical, print summary for combined rows and strata
#' @param sanitize.math logical, convert characters into tex valid math and symbols, Default: TRUE
#' @param returndf logical, return data.frame instead of tex output, Default: FALSE
#' @param funs_to_apply a function to apply to each group being summarized, Default \code{\link{cont_summary}}.
#' @param ... parameters to pass to \code{funs_to_apply}.  
#' @param table_opts list, named list of arguments specifying output behavior and footnotes, Default: mrgtable_opts$get()
#' @param texp_opts named list of parameters to pass to \code{texPreview}, Default: tex_opts$get()
#' @details The \code{\link{cont_summary}} \code{funs_to_apply} should cover everything you need.  By passing the argument \code{template} (i.e., in \code{...}), \code{\link{cont_summary}} will \code{\link{search}} the session for existence of functions specified to \code{\link{glue}} into the template.  E.g., \code{template='{mean} ({sd}) [{q25} - {q75}]'}, where the user has defined functions \code{q25} and \code{q75} prior to calling \code{cont_tbl}.
#' @seealso \code{\link[texPreview]{texPreview}}, \code{\link{mrg_footnote}}, \code{\link{cont_summary}}
#' @examples 
#' 
#' data("mi210")
#' 
#' mi210%>%
#'   cont_tbl(formula = STUDY~AGE+HT+WT|SEX,
#'            idVar='ID')
#' 
#' mi210%>%
#'   cont_tbl(formula = STUDY~AGE+HT+WT|SEX,
#'            idVar='ID',
#'            wide = FALSE)
#' 
#' mi210%>%
#'   cont_tbl(formula = STUDY~AGE+HT+WT|SEX,idVar='ID',
#'            template='{mean} <{sd}> [{lb} - {ub}]')
#' 
#' # Introduce some missingness
#' nadat <- mi210%>%
#'   dplyr::distinct(ID,.keep_all = TRUE)
#' 
#' nadat$AGE[1] <- NA
#' 
#' nadat%>%
#'   cont_tbl(
#'     formula = STUDY~AGE+HT+WT|SEX,
#'     idVar   = 'ID')
#' 
#' # Create own summary statistics
#' q25=function(x) quantile(x,probs=.25)
#' q75=function(x) quantile(x,probs=.75)
#' 
#' mi210%>%cont_tbl(
#'   formula   = STUDY~AGE+HT+WT|SEX,
#'   idVar     = 'ID',
#'   template  = '{mean} ({sd}) [{q25} - {q75}]'
#' )

#' 
#' @return LaTeX table
#' @export
#' @import dplyr
#' @importFrom purrr map set_names
#' @importFrom tidyr spread gather
#' @importFrom texPreview tex_opts
#' @importFrom rlang !!! syms
#' @rdname cont_tbl
cont_tbl <-
  function(data, 
           formula='.~.',
	         stem="cont_tbl",
	         idVar="ID",
	         funs_to_apply = cont_summary,
					 wide = TRUE,
					 total = TRUE,
					 sanitize.math=TRUE,
					 returndf=FALSE,
					 ...,
					 table_opts = mrgtable_opts$get(),
					 texp_opts = texPreview::tex_opts$get()
					 )
		{ 

    data <- check_group(data)
    
    tbl_args <- tbl_form(data, formula, idVar, el_names = c('groupBy','conList','stratBy'))
    
    subData   <- NULL
    grp       <- NULL
    grplabs   <- NULL
    cons      <- NULL
    conlabs   <- NULL
    strat     <- NULL
    stratlabs <- NULL

    list2env(tbl_args,envir = environment())
    
		subDataCon <- split(subData,subData[[strat]])
		
		subDataCon <- purrr::map(subDataCon, .f = function(statData){
		  
		  suppressWarnings({
		    
		    statData__ <- statData%>%
		      dplyr::select(!!!(rlang::syms(c(grp,cons))))%>%
		      dplyr::mutate_if(is.factor,as.character)%>%
		      tidyr::gather(key="Parameter", value="value", gather_cols = c(cons))
		    
		  })
		  
		    statData__ <- split(statData__,f = statData__[,c(grp,"Parameter")],sep = "__WILD__") %>%
		      purrr::map(.f = funs_to_apply, ...)%>%
		    dplyr::bind_rows(.id='id')%>%
		    tidyr::separate(id, into = c(grp,"Parameter"),sep="__WILD__")
		  
      statData__[[grp]] <- paste("\\quad", statData__[[grp]])
      
      statData__%>%
        tidyr::spread(key = .data[['Parameter']],value=.data[['value']])
		})

		if( total ){

		  suppressWarnings({
		    
		  wholeData__ <- subData%>% 
		    dplyr::select(!!!(rlang::syms(cons)))%>%
		    dplyr::mutate_if(is.factor,as.character)%>%
		    tidyr::gather()
		  
		  })
		  
		  wholeData__ <- split(wholeData__,wholeData__$key) %>%
		    purrr::map(funs_to_apply, ...)%>%
		    dplyr::bind_rows(.id='Parameter')
		  
		  wholeData__[[grp]] <- "{\\bfseries Total}"
		  
		  subDataCon[["Total"]] <- wholeData__ %>% tidyr::spread(key = .data[['Parameter']],
		                                                         value = .data[['value']])
		}
		
		names(subDataCon) <- paste0(stratlabs,": ", names(subDataCon))
		
		ltab <- dplyr::bind_rows(subDataCon)%>%
		  dplyr::mutate_all(dplyr::funs(`%-%`))

		if( wide ){
		  
		  names(ltab) <- ltab%>%
		    dplyr::rename_(.dots = purrr::set_names(c(grp,cons), c(grplabs,conlabs)))%>%
		    names
		  
		  ltab <- within(ltab, grp <- rep(1:length(subDataCon), times = sapply(subDataCon,nrow)))
		  
		}else{
		  
		  ltab$strat <- rep(names(subDataCon), times = purrr::map_int(subDataCon,nrow)) 
		  
		  ltab$strat <- factor(ltab$strat, levels = names(subDataCon))
		  
		  suppressWarnings({
		    
		  ltab <- 
		    ltab %>% 
		    tidyr::gather(!!(rlang::sym('variable')),!!(rlang::sym('value')),cons) %>% 
		    dplyr::arrange(strat,!!(rlang::sym(grp))) %>%
		    dplyr::group_by(strat) %>%
		    dplyr::mutate_at(dplyr::vars(c(!!(rlang::sym(grp)),.data[['N']])),
		                     .funs = function(x_)ifelse(duplicated(x_),NA,x_))
		  
		  })
		  
      names(ltab) <- 
        ltab %>%
        dplyr::rename_(.dots = purrr::set_names(grp,grplabs)) %>% 
        dplyr::rename(Variable = .data[['variable']], Summary = .data[['value']]) %>%
        names()
      
      ltab$Variable <- .map(ltab$Variable, cons, conlabs)
      
      ltab[,"grp"] <- as.numeric(ltab$strat)
      
      if( strat!="whole" ){
        
        ltab <- ltab %>% 
          select(strat, everything()) %>% 
          ungroup() %>%
          mutate(strat = ifelse(duplicated(strat), NA, as.character(strat)))
        
        ltab$strat <- gsub(paste0(stratlabs,": Total"),NA,ltab$strat)
        
      }else{
        
        ltab[,'strat'] <- NULL
        
      }
		}

		if (returndf){
		  return(ltab)
		}
		
		nms <- paste("{\\bfseries", names(ltab), "}")
		
		nms[grep(" grp",nms)] <- "grp"
		
		nms[grep(" strat",nms)] <- ""
		
		names(ltab) <- nms

		tex <- tabular(ltab[,setdiff(names(ltab),"grp")],
		               rowgroups = ltab$grp,
		               grid = TRUE,
		               colgroups = rep(1,ncol(ltab)),
		               rowgrouprule = 2,
		               verbatim= FALSE)

		if( strat!="whole" & wide ){
		  mc <- sapply(names(subDataCon), 
		               function(xx) 
		                 sprintf("\\multicolumn{%i}{c}{}\\\\ \\multicolumn{%i}{c}{{\\bfseries %s}}\\\\ \\hline", 
		                         ncol(select(ltab,-grp)), ncol(select(ltab,-grp)), xx))
		  
		  index <- grep("\\\\ \\hline",tex,fixed = TRUE)
		  
		  index <- index[-length(index)]
		  
		  neworder <- c(1:length(tex),index+.5)
		  
		  tex <- c(tex,mc)[order(neworder)]
		  
		}

		tex <- tex%>%
		  preview_tex(stem = stem,
		              sanitize.math = sanitize.math,
		              table_opts = table_opts,
		              texp_opts = texp_opts)
		
		if(table_opts$returnType=='html'){
		  tex
		}else{
		  return(invisible(tex))
		}
	}

#' @title Continuous variable summary function 
#' @description Workhorse function applied in continuous tables.
#' @details Workhorse function to be applied in tables. A named list of all 
#' summary measures to display in the continuous demographic table.  Note that 
#' variables in the parent frame of this function (e.g., the \code{\link{cont_tbl}}
#' calling environment) are visible; this is leveraged to get \code{sig_dig}.
#' @param x continuous numeric variable to be summarized
#' @param template character, template of summary statistics format to output
#' @param N boolean, add N column to summary output, Default: TRUE
#' @param level Confidence level, normal distribution is assumed
#' @param sig_dig Number of significant digits, can be modified in \dots of \code{cont_tbl}
#' @param na.rm Remove missing values.  When true, the reported \code{N} is given 
#' on the number of non-missing patients going into the calculation, which can lead to 
#' multiple rows per grouping variable.
#' @return named list of summary measures to be used in \code{\link{cont_tbl}}
#' @rdname cont_summary
#' @import dplyr
#' @importFrom glue glue_data
#' @export
cont_summary <- function(x, 
                         template='{mean} ({sd}) [{min} - {max}]', 
                         N = TRUE,
                         level = 95, 
                         sig_dig = 3, 
                         na.rm = FALSE
                         ){
  

  template_vec <- gsub('[{}]','',regmatches(template, gregexpr('\\{(.*?)\\}', template))[[1]])
  # tot_funs     <- c(sum_funs,names(more_funs),c('cv','lb','ub'))
  tot_funs <- unique(c(template_vec,"length","mean", "median","sd","min","max"))

  bs_use <-  base_summary(x = x, level = level, sig_dig = sig_dig, na.rm = na.rm, sum_funs = tot_funs)  
  glued <- bs_use %>% glue::glue_data(template)
    
  if(N){
    ret <- list(N=as.integer(bs_use$length),value=as.character(glued))
  }else{
    ret <- list(value=as.character(glued))
  }

  
  return(ret)
}

#' @importFrom stats sd median
#' @importFrom rlang syms !!! .data 
#' @importFrom purrr possibly

base_summary <- function(x, sig_dig = 3, level = 95, na.rm = FALSE,
                         sum_funs = list("length", "mean", "median", "sd", "min", "max")
                         ){
  if( level < 1 ) 
    stop("Input level as a percentage")
  
  alpha <- 1-level*.01
  alpha_c <- stats::qnorm(alpha/2 , lower.tail = FALSE)
  
  num2char <- function(x) as.character(sig(x, dig = sig_dig))
  
  x <- x %>% 
    dplyr::mutate(value=as.numeric(.data[['value']]))
  
  if(na.rm) 
    x <- x %>%
    stats::na.omit()

  summaries <- 
    dplyr::summarise_at(.tbl = x,
                        .vars = dplyr::vars(.data[['value']]),
                        .funs = c(dplyr::funs(
                          !!!(rlang::syms(
                            sum_funs[sapply(sum_funs,exists)]
                          ))
                        ))
    )

  if(all(c('mean','sd')%in%sum_funs)){
    
    # Check for existence of cv, ub, lb function on search path
    is_function <- purrr::possibly(function(fn__){ is.function(get(fn__))}, FALSE)
    
    if(!is_function('cv')){
      summaries <- summaries%>%
        dplyr::mutate(cv = (100 * .data[["sd"]] / .data[["mean"]]) %>% num2char)
    }
    
    if(!is_function('lb')){
      summaries <- summaries%>%
        dplyr::mutate(
          lb = (.data[['mean']] - alpha_c*.data[['sd']]) %>% num2char)
    }
    
    if(!is_function('ub')) {
      summaries <- summaries%>%
        dplyr::mutate(
          ub = (.data[['mean']] + alpha_c*.data[['sd']]) %>% num2char)
    }
  }
  
  ret <-  summaries %>%
    dplyr::mutate_at(
      .vars =  dplyr::vars(!!!(rlang::syms(sum_funs))),
      .funs =  dplyr::funs(num2char)
      )
  
  return(ret)
}
