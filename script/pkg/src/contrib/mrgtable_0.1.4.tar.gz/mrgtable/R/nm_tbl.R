#' @title Create a NONMEM parameter estimation output table from a nibble class
#' @description NONMEM parameter table using output from the XML, 
#' via the \code{\link[tidynm]{nibble}} PARAMTBL element.
#' @param paramtbl element from paramtbl column in nibble object
#' @param tableobj object created from RNM when returndf set to TRUE, Default: NULL
#' @param stem character, file stem for output, Default: 'nmtab'
#' @param Sig numeric significant figures to display in the table, Default: 3
#' @param ConfInt numeric, defines confidence intervals to display, Default: 0.95
#' @param OffDiagonals logical, include the off diagonal values in the table presentation,
#'  Default: TRUE
#' @param unTransform logical, Indicates whether to revert log transformed parameter estimates
#'  specified with "LOGD" comments, Default: TRUE
#' @param removeFixed logical, Remove all values fixed to 0 from the output table, Default: FALSE
#' @param bound logical, For variance components on the diagonal 
#' (i.e., not correlation/covariance estimates), should we set the lower bound of the CI to 0,
#'  Default: TRUE
#' @param returndf logical, return a data.frame for further manipulation, Default: FALSE
#' @param table_opts list, named list of arguments specifying output behavior and footnotes,
#'  Default: mrgtable_opts$get()
#' @param texp_opts named list of parameters to pass to \code{\link[texPreview]{texPreview}},
#'  Default: tex_opts$get()
#' @return tex/tibble
#' @details The markup for the creation of this table is read from the copy of the 
#' control stream that is embedded in the XML file (and thus is contained in a
#'  \code{\link[tidynm]{nibble}} object).  The markdown is as follows:
#' 
#' \code{<nonmem_inits> ; [directive] <Parameter name <LOGD>>}
#' 
#' \itemize{
#' \item Inits are the NONMEM initial values, following NONMEM specs
#' \item Directives include:
#'   \itemize{
#'   \item For fixed effects the directives are translated to units, i.e., L/h
#'   \item For variance components (and only variance components):
#'   \itemize{
#'       \item [A] is the assumed directive and it yields standard deviation / correlation.  
#'       Typically used when the random component has a linear relationship to the typical value.
#'       \item [P] yields Coefficient of Variation.  
#'       We use \eqn{CV_lognormal = sqrt( exp(omega^2)-1 ) \times 100} for omegas, 
#'       and the value of omega from the correlation matrix (i.e., the SD) for sigmas.   
#'       Typically used with exponentiated random effects or proportional residual error.
#'       \item [R] indicates that this is an item that should be read from the correlation 
#'       matrix as opposed to the covariance matrix.  
#'       I.e., standard deviation and correlation of the parameter on the raw scale will be reported.
#'       \item [C] indicates that this item should be read from the covariance matrix, i.e., variance
#'        and covariance of the parameter on the raw scale will be reported.
#'      }
#'   }
#' \item Paramemter name is run through a LaTex parser
#' \item LOGD is a flag to indicate that the parameter is modeled on the log 
#' scale (i.e., \eqn{e^\theta}) and should be exponentiated for reporting.  
#' If so, the standard error for the parameter is adjusted via the delta method.
#' }
#' 
#' For example:
#'
#' \preformatted{ 
#' $THETA 
#'   (.001,.08,2) ; [L/day] CL
#'   (7,18,40) ; [L] V
#' }
#' 
#' \preformatted{
#' $OMEGA BLOCK(2) 
#'  .6 ;[P] CL 
#'  .3 ;[R] CL-V
#'  .3 ;[A] V
#'  }
#'
#" Will give:
#' Titles of "CL" and "V" with units of "L/day" and "L" for THETA
#' For variance components, the titles are "CL", "CL-V", and "V".
#' [P] will report the CV, the off-diagonal will 
#' report as correlation, and the IIV for V will be reported as a standard deviation.
#' Similar rules apply to residual error.
#' 
#' 
#' @return The output dataframe or table will have the following columns:
#' \itemize{
#'   \item \code{Parameter}: Parameter name that will be LaTex formatted
#'   \item \code{Estimate}: Estimate, described further by the "units" column
#'   \item \code{pRSE}: Percent RSE calculated based upon the raw (asymptotically normally distributed) 
#'    estimate and corresponding se from the covariance step.  I.e., this is always 
#'    \code{thetase}/\code{theta}, \code{omegase}/\code{omega}, \code{sigmase}/\code{sigma} times 100
#'   \item \code{CI (95\%)}:  \code{95\%} CI, calculated using transformations to estimates and se indicated in \code{details}
#'   \item \code{Units}: Units / labels for \code{Parameter}
#' }
#' 
#' @examples 
#' require(tidynm)
#' 
#' nbl <- nibble(project = system.file('extdata',package = 'tidynm'),
#' run = c('510'),include_tabs = TRUE)
#'
#' nbl$ctl_raw[[1]] %>% writeLines
#'    
#' nbl$PARAMTBL[[1]]%>%nm_tbl(returndf = TRUE)
#' 
#' if(interactive())
#'  nbl$PARAMTBL[[1]]%>%nm_tbl()
#' 
#' @seealso 
#'  \code{\link[texPreview]{texPreview}}
#' @rdname nm_tbl
#' @export 
#' @importFrom texPreview texPreview
nm_tbl <- function(paramtbl,
                   tableobj = NULL,
                   stem = "nm_tbl",
                   unTransform = TRUE,
                   Sig = 3,
                   ConfInt = 0.95,
                   OffDiagonals = TRUE,
                   removeFixed = FALSE,
                   returndf = FALSE,
                   bound = FALSE,
                   
                   table_opts = mrgtable_opts$get(),
                   texp_opts = tex_opts$get()) {
  
  if(!inherits(paramtbl,'nibble_param'))
    message('the input object does not inherit "nibble_param"')
  
  paramtbl <- check_group(paramtbl)
  
  if (is.null(tableobj)) {
    tableobj <-
      nm_create(paramtbl, ConfInt=ConfInt, unTransform=unTransform, bound=bound) %>%
      nm_format(Sig=Sig, ConfInt=ConfInt, removeFixed=removeFixed, OffDiagonals=OffDiagonals)
  }
  
  if (returndf) {
    return(tableobj)
  }
  
  tex <- tableobj%>%
    nm_tex()%>%
    preview_tex(stem = stem,
                sanitize.math = FALSE,
                table_opts = table_opts,
                texp_opts = texp_opts)
  
  if(table_opts$returnType=='html'){
    tex
  }else{
    return(invisible(tex))
  }
}
