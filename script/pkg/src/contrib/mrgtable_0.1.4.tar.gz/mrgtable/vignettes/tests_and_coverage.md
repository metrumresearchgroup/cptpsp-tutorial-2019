---
title: "Tests and Coverage"
date: "09 October, 2018 11:38:26"
output: rmarkdown::html_vignette
vignette: >
  %\VignetteIndexEntry{Vignette Title}
  %\VignetteEngine{knitr::rmarkdown}
  %\VignetteEncoding{UTF-8}
---
  


<!--- Placeholder for tests/README.md Do Not Edit--->
This output is created by
[covrpage](https://github.com/yonicd/covrpage).

## Coverage

Coverage summary is created using the
[covr](https://github.com/r-lib/covr) package.

| Object                                     | Coverage (%) |
| :----------------------------------------- | :----------: |
| mrgtable                                   |    67.99     |
| [R/opts\_complete.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/R/opts_complete.R) |     0.00     |
| [R/utils\_Hmisc.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/R/utils_Hmisc.R)     |    23.72     |
| [R/utils\_latex.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/R/utils_latex.R)     |    43.84     |
| [R/opts.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/R/opts.R)                    |    44.74     |
| [R/zzz.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/R/zzz.R)                      |    54.55     |
| [R/utils\_format.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/R/utils_format.R)   |    77.27     |
| [R/nm\_create.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/R/nm_create.R)         |    80.58     |
| [R/nm\_tbl.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/R/nm_tbl.R)               |    88.89     |
| [R/utils.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/R/utils.R)                  |    92.00     |
| [R/mrg\_footnote.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/R/mrg_footnote.R)   |    92.86     |
| [R/preview\_tex.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/R/preview_tex.R)     |    95.24     |
| [R/cat\_tbl.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/R/cat_tbl.R)             |    96.43     |
| [R/cont\_tbl.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/R/cont_tbl.R)           |    98.00     |
| [R/nm\_format.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/R/nm_format.R)         |    98.33     |
| [R/count\_tbl.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/R/count_tbl.R)         |    98.41     |
| [R/cat\_whole.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/R/cat_whole.R)         |    98.46     |
| [R/cat\_long.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/R/cat_long.R)           |    100.00    |
| [R/cat\_wide.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/R/cat_wide.R)           |    100.00    |
| [R/create\_yml.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/R/create_yml.R)       |    100.00    |
| [R/nm\_tex.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/R/nm_tex.R)               |    100.00    |
| [R/tbl\_form.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/R/tbl_form.R)           |    100.00    |

<br>

## Unit Tests

Unit Test summary is created using the
[testthat](https://github.com/r-lib/testthat)
package.

| file                                           |  n |  time | error | failed | skipped | warning |
| :--------------------------------------------- | -: | ----: | ----: | -----: | ------: | ------: |
| [test-cat\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-cat_tab.R)     | 19 | 0.094 |     0 |      0 |       0 |       0 |
| [test-cont\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-cont_tab.R)   | 21 | 0.026 |     0 |      0 |       0 |       0 |
| [test-count\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-count_tab.R) |  5 | 0.055 |     0 |      0 |       0 |       0 |
| [test-general.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-general.R)      |  8 | 1.088 |     0 |      0 |       0 |       0 |
| [test-input.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-input.R)          |  4 | 0.007 |     0 |      0 |       0 |       0 |
| [test-nm\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-nm_tab.R)       | 10 | 0.013 |     0 |      0 |       0 |       0 |
| [test-output.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-output.R)        | 13 | 0.988 |     0 |      0 |       0 |       0 |
| [test-tbl\_form.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-tbl_form.R)   | 18 | 0.087 |     0 |      0 |       0 |       0 |

<details closed>

<summary> Show Detailed Test Results
</summary>

| file                                                   | context             | test                                                             | status | n |  time |
| :----------------------------------------------------- | :------------------ | :--------------------------------------------------------------- | :----- | -: | ----: |
| [test-cat\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-cat_tab.R#L15)         | Categorical table   | wide table with stratification and marginal totals: class        | PASS   | 1 | 0.013 |
| [test-cat\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-cat_tab.R#L18)         | Categorical table   | wide table with stratification and marginal totals: dimension    | PASS   | 1 | 0.003 |
| [test-cat\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-cat_tab.R#L29_L30)     | Categorical table   | wide table with stratification and marginal totals: value        | PASS   | 4 | 0.012 |
| [test-cat\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-cat_tab.R#L53)         | Categorical table   | long table with no marginal totals: class                        | PASS   | 1 | 0.001 |
| [test-cat\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-cat_tab.R#L56)         | Categorical table   | long table with no marginal totals: dimension                    | PASS   | 1 | 0.002 |
| [test-cat\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-cat_tab.R#L66)         | Categorical table   | long table with no marginal totals: value                        | PASS   | 1 | 0.016 |
| [test-cat\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-cat_tab.R#L82)         | Categorical table   | long table with no stratification: class                         | PASS   | 1 | 0.001 |
| [test-cat\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-cat_tab.R#L86)         | Categorical table   | long table with no stratification: dimension                     | PASS   | 2 | 0.002 |
| [test-cat\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-cat_tab.R#L113)        | Categorical table   | long table with no stratification: value                         | PASS   | 2 | 0.020 |
| [test-cat\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-cat_tab.R#L130)        | Categorical table   | long table with stratification: class                            | PASS   | 1 | 0.001 |
| [test-cat\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-cat_tab.R#L134)        | Categorical table   | long table with stratification: dimension                        | PASS   | 2 | 0.002 |
| [test-cat\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-cat_tab.R#L156)        | Categorical table   | long table with stratification: value                            | PASS   | 2 | 0.021 |
| [test-cont\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-cont_tab.R#L23)       | Continuous table    | wide tables: class                                               | PASS   | 1 | 0.001 |
| [test-cont\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-cont_tab.R#L26)       | Continuous table    | wide tables: dimension                                           | PASS   | 1 | 0.001 |
| [test-cont\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-cont_tab.R#L29)       | Continuous table    | wide tables: value                                               | PASS   | 2 | 0.002 |
| [test-cont\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-cont_tab.R#L41)       | Continuous table    | wide tables: no N                                                | PASS   | 1 | 0.002 |
| [test-cont\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-cont_tab.R#L62)       | Continuous table    | wide tables: summary statistic template                          | PASS   | 1 | 0.002 |
| [test-cont\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-cont_tab.R#L86)       | Continuous table    | long tables: class                                               | PASS   | 1 | 0.001 |
| [test-cont\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-cont_tab.R#L89)       | Continuous table    | long tables: dimension                                           | PASS   | 1 | 0.001 |
| [test-cont\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-cont_tab.R#L92)       | Continuous table    | long tables: value                                               | PASS   | 2 | 0.003 |
| [test-cont\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-cont_tab.R#L114)      | Continuous table    | wide no stratification: class                                    | PASS   | 1 | 0.001 |
| [test-cont\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-cont_tab.R#L117)      | Continuous table    | wide no stratification: dimension                                | PASS   | 1 | 0.001 |
| [test-cont\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-cont_tab.R#L120)      | Continuous table    | wide no stratification: value                                    | PASS   | 2 | 0.002 |
| [test-cont\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-cont_tab.R#L143)      | Continuous table    | long no stratification: class                                    | PASS   | 1 | 0.001 |
| [test-cont\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-cont_tab.R#L146)      | Continuous table    | long no stratification: dimension                                | PASS   | 1 | 0.001 |
| [test-cont\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-cont_tab.R#L149)      | Continuous table    | long no stratification: value                                    | PASS   | 2 | 0.002 |
| [test-cont\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-cont_tab.R#L179)      | Continuous table    | user supplied summary statistics: dimension                      | PASS   | 1 | 0.002 |
| [test-cont\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-cont_tab.R#L182)      | Continuous table    | user supplied summary statistics: value                          | PASS   | 2 | 0.003 |
| [test-count\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-count_tab.R#L25)     | Count table         | count\_tbl: class                                                | PASS   | 1 | 0.002 |
| [test-count\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-count_tab.R#L28)     | Count table         | count\_tbl: dimension                                            | PASS   | 1 | 0.001 |
| [test-count\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-count_tab.R#L31)     | Count table         | count\_tbl: no dose value                                        | PASS   | 1 | 0.002 |
| [test-count\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-count_tab.R#L41)     | Count table         | count\_tbl: value                                                | PASS   | 1 | 0.011 |
| [test-count\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-count_tab.R#L61_L63) | Count table         | warnings: nonzero EVID warning                                   | PASS   | 1 | 0.039 |
| [test-general.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-general.R#L6)           | General             | significant digits: default                                      | PASS   | 1 | 0.002 |
| [test-general.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-general.R#L10)          | General             | significant digits: digits                                       | PASS   | 1 | 0.001 |
| [test-general.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-general.R#L14)          | General             | significant digits: max exponent                                 | PASS   | 1 | 0.001 |
| [test-general.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-general.R#L21_L28)      | General             | layout: categorical wide                                         | PASS   | 1 | 0.134 |
| [test-general.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-general.R#L31_L39)      | General             | layout: ccategorical long                                        | PASS   | 1 | 0.151 |
| [test-general.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-general.R#L43_L48)      | General             | layout: continuous wide                                          | PASS   | 1 | 0.391 |
| [test-general.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-general.R#L51_L57)      | General             | layout: continuous long                                          | PASS   | 1 | 0.407 |
| [test-general.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-general.R#L71)          | General             | yml: yml exists                                                  | PASS   | 1 | 0.001 |
| [test-input.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-input.R#L6)               | Input objects       | check inherit function: data.frame                               | PASS   | 1 | 0.002 |
| [test-input.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-input.R#L10)              | Input objects       | check inherit function: tbl\_df                                  | PASS   | 1 | 0.001 |
| [test-input.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-input.R#L16)              | Input objects       | check inherit function: nibble                                   | PASS   | 1 | 0.002 |
| [test-input.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-input.R#L20)              | Input objects       | check inherit function: wrong class                              | PASS   | 1 | 0.002 |
| [test-nm\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-nm_tab.R#L16)           | NONMEM table        | invalid input: input non nibble                                  | PASS   | 1 | 0.002 |
| [test-nm\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-nm_tab.R#L24)           | NONMEM table        | default nm\_tbl: class                                           | PASS   | 1 | 0.001 |
| [test-nm\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-nm_tab.R#L27)           | NONMEM table        | default nm\_tbl: dimension                                       | PASS   | 1 | 0.001 |
| [test-nm\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-nm_tab.R#L41)           | NONMEM table        | change confidence interval size: validate confidence interval    | PASS   | 1 | 0.001 |
| [test-nm\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-nm_tab.R#L55)           | NONMEM table        | remove diagonal from covariance matrix: validate baseline values | PASS   | 1 | 0.001 |
| [test-nm\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-nm_tab.R#L72)           | NONMEM table        | remove FIXED attribute: no FIXED counterfactual                  | PASS   | 1 | 0.001 |
| [test-nm\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-nm_tab.R#L76)           | NONMEM table        | remove FIXED attribute: FIXED with non-zero estimates remain     | PASS   | 1 | 0.001 |
| [test-nm\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-nm_tab.R#L90)           | NONMEM table        | LOGD transform: log transform                                    | PASS   | 1 | 0.003 |
| [test-nm\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-nm_tab.R#L94)           | NONMEM table        | LOGD transform: LOGD comment removed                             | PASS   | 1 | 0.000 |
| [test-nm\_tab.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-nm_tab.R#L112)          | NONMEM table        | Boundaries: Set negative boundary to 0                           | PASS   | 1 | 0.002 |
| [test-output.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-output.R#L14_L19)        | Output objects      | tex path warning: redirecting to working directory               | PASS   | 1 | 0.970 |
| [test-output.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-output.R#L38)            | Output objects      | html output: create magick image for html                        | PASS   | 1 | 0.002 |
| [test-output.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-output.R#L68)            | Output objects      | wide continuous table: validate benchmark                        | PASS   | 1 | 0.002 |
| [test-output.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-output.R#L94)            | Output objects      | continuous table long: validate benchmark                        | PASS   | 1 | 0.002 |
| [test-output.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-output.R#L120)           | Output objects      | categorical table wide: validate benchmark                       | PASS   | 1 | 0.002 |
| [test-output.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-output.R#L149)           | Output objects      | categorical table long: validate benchmark                       | PASS   | 1 | 0.002 |
| [test-output.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-output.R#L189)           | Output objects      | count table: validate benchmark                                  | PASS   | 1 | 0.001 |
| [test-output.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-output.R#L217)           | Output objects      | NONMEM table: validate benchmark                                 | PASS   | 1 | 0.002 |
| [test-output.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-output.R#L227)           | Output objects      | test defaults: output class                                      | PASS   | 1 | 0.001 |
| [test-output.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-output.R#L241)           | Output objects      | categorical table data.frame output: class                       | PASS   | 1 | 0.001 |
| [test-output.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-output.R#L257)           | Output objects      | continuous table data.frame output: class                        | PASS   | 1 | 0.001 |
| [test-output.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-output.R#L272)           | Output objects      | count table data.frame output: class                             | PASS   | 1 | 0.001 |
| [test-output.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-output.R#L286)           | Output objects      | NONMEM table data.frame output: class                            | PASS   | 1 | 0.001 |
| [test-tbl\_form.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-tbl_form.R#L13)       | Table formula input | single category no stratification: class                         | PASS   | 1 | 0.001 |
| [test-tbl\_form.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-tbl_form.R#L17)       | Table formula input | single category no stratification: variable names                | PASS   | 3 | 0.002 |
| [test-tbl\_form.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-tbl_form.R#L23)       | Table formula input | single category no stratification: variable labels               | PASS   | 3 | 0.003 |
| [test-tbl\_form.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-tbl_form.R#L35)       | Table formula input | multiple categories no stratification: variable names            | PASS   | 1 | 0.001 |
| [test-tbl\_form.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-tbl_form.R#L38)       | Table formula input | multiple categories no stratification: variable labels           | PASS   | 1 | 0.001 |
| [test-tbl\_form.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-tbl_form.R#L48)       | Table formula input | single category with stratification: variable names              | PASS   | 2 | 0.002 |
| [test-tbl\_form.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-tbl_form.R#L53)       | Table formula input | single category with stratification: variable labels             | PASS   | 2 | 0.002 |
| [test-tbl\_form.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-tbl_form.R#L66)       | Table formula input | parameter labels: labels for group and category                  | PASS   | 2 | 0.002 |
| [test-tbl\_form.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-tbl_form.R#L81)       | Table formula input | partial parameter labels: labels for group only                  | PASS   | 1 | 0.001 |
| [test-tbl\_form.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-tbl_form.R#L95)       | Table formula input | invalid object names: variable name is ‘variable’                | PASS   | 1 | 0.001 |
| [test-tbl\_form.R](https://ghe.metrumrg.com/software/mrgtable/tree/toggle_verbatim/tests/testthat/test-tbl_form.R#L102_L106) | Table formula input | ungrouping input data: message for intervention                  | PASS   | 1 | 0.071 |

</details>

<details>

<summary> Session Info </summary>

| Field    | Value                               |
| :------- | :---------------------------------- |
| Version  | R version 3.5.1 (2018-07-02)        |
| Platform | x86\_64-apple-darwin15.6.0 (64-bit) |
| Running  | macOS High Sierra 10.13.6           |
| Language | en\_US                              |
| Timezone | America/New\_York                   |

| Package  | Version    |
| :------- | :--------- |
| testthat | 2.0.0.9000 |
| covr     | 3.2.0      |
| covrpage | 0.0.60     |

</details>

<!--- Final Status : pass --->
