#' @keywords internal
#' @import rlang
#' @importFrom purrr map reduce compact
"_PACKAGE"
