`logName` <-
function(directory=logRoot())file.path(absDir(directory),"QClog.csv")

