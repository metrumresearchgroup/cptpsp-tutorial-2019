`gmt` <-
function()paste(as.character(as.POSIXlt(Sys.time(), "GMT")),"GMT")
