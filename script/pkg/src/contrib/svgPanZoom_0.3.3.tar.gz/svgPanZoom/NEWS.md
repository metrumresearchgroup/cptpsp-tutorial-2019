svgPanZoom 0.3.3
------------------------------------------------------------------------

* fix bug in zoom controls when using with `svglite`

svgPanZoom 0.3.2
------------------------------------------------------------------------

* remove `SVGAnnotation` in examples in favor of `svglite`
* Upgrade to svg-pan-zoom.js v3.2.6

svgPanZoom 0.3.1
------------------------------------------------------------------------

* Add viewBox argument to disable "smart" viewBox

svgPanZoom 0.3
------------------------------------------------------------------------

* Upgrade to svg-pan-zoom.js v3.2.3
* Adds touch support with hammer.js
* Internally add better sizing to fit the htmlwidget container
* Add the ability to incorporate tasks on the JavaScript side
* Work well with xml2

svgPanZoom 0.2
------------------------------------------------------------------------

* Initial release to CRAN
