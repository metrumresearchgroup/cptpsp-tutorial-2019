percent <-
function(x,digits=3,...)signif(x,digits=digits)*100

